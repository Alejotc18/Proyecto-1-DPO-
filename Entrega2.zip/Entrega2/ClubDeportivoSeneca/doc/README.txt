================================================================
  CLUB DEPORTIVO SENECA - Proyecto 1, Entrega 2
  ISIS-1226 Diseno y Programacion Orientada a Objetos
  Diseno e implementacion del modelo
================================================================

QUE CONTIENE ESTA ENTREGA
-------------------------
El modelo completo del sistema: clases, herencias, relaciones, atributos y
metodos. El proyecto compila sin errores.

Esta entrega NO incluye programas de prueba ni pruebas unitarias: esas
corresponden a la siguiente entrega del proyecto. Por eso el proyecto todavia
no tiene ninguna clase con metodo main.

COMO ABRIR EL PROYECTO EN ECLIPSE
---------------------------------
1. File -> Import -> General -> Existing Projects into Workspace
2. Seleccionar la carpeta "ClubDeportivoSeneca"
3. Finish

No usa librerias externas: solo necesita un JDK 8 o superior.

COMO COMPILAR DESDE LA LINEA DE COMANDOS
----------------------------------------
Lo recomendado es importar el proyecto en Eclipse, que compila solo. Si se
quiere verificar desde la terminal, el comando depende del sistema, porque la
forma de listar los archivos .java no es la misma en todos:

  Windows (PowerShell), desde la carpeta ClubDeportivoSeneca:
      javac -encoding UTF-8 -d bin (Get-ChildItem -Recurse -Filter *.java src).FullName

  Windows (simbolo del sistema, cmd):
      dir /s /b src\*.java > fuentes.txt
      javac -encoding UTF-8 -d bin @fuentes.txt

  Linux o macOS:
      javac -encoding UTF-8 -d bin $(find src -name "*.java")

La forma con @fuentes.txt es la portable: javac acepta un archivo con la lista
de fuentes, y cada sistema solo tiene que saber como generar esa lista.

ESTRUCTURA DE CARPETAS
----------------------
src/    codigo fuente, organizado en paquetes
data/   archivos de datos de ejemplo (fuera de la carpeta del codigo, como
        exige el enunciado). Sirven para ver el formato de persistencia y
        para alimentar las pruebas de la siguiente entrega
bin/    clases compiladas
doc/    este archivo

PAQUETES
--------
uniandes.dpoo.cds.modelo.personas        jerarquia de Persona
uniandes.dpoo.cds.modelo.deportes        equipos, partidos, estadisticas
uniandes.dpoo.cds.modelo.competencias    circuitos externos y nominas
uniandes.dpoo.cds.modelo.academias       disciplinas individuales e instalaciones
uniandes.dpoo.cds.modelo.entrenamiento   sesiones, convocatorias y turnos
uniandes.dpoo.cds.modelo.tienda          productos y ventas
uniandes.dpoo.cds.reglas                 reglas de cada deporte y disciplina
uniandes.dpoo.cds.logica                 fachada del club
uniandes.dpoo.cds.persistencia           lectura y escritura de archivos
uniandes.dpoo.cds.excepciones            errores del dominio

FORMATO DE LOS ARCHIVOS DE DATOS
--------------------------------
Son archivos planos separados por punto y coma, uno por entidad. Las lineas que
empiezan por # son encabezados que explican las columnas y se ignoran al leer.

    club.txt            configuracion general del club
    personas.txt        afiliados, empleados y administrador
    equipos.txt         equipos de deportes de conjunto
    inscripciones.txt   vinculo jugador-equipo
    academias.txt       vinculo afiliado-disciplina
    instalaciones.txt   canchas y mesas
    productos.txt       articulos, bebidas y snacks

PATRONES DE DISENO APLICADOS
----------------------------
Strategy        ReglasDeporte, ReglasDisciplina, FormatoCompetencia
Factory Method  crearEstadistica dentro de las interfaces de reglas
Template Method Venta.liquidar y ReglasRaquetaBase.calcularNuevoPuntaje
DAO             RepositorioClub con dos implementaciones
Fachada         la clase Club

La justificacion de cada uno esta en el documento
"Documentacion Proyecto DPO Entrega 2.pdf".
