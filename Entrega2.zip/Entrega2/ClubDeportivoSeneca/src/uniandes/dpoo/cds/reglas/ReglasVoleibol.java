package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaVoleibol;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DEL VOLEIBOL
 *
 * Minimo 6 jugadores, no hay empate y el marcador se lleva por sets, que es lo
 * que lo hace distinto de los otros dos.
 */
public class ReglasVoleibol implements ReglasDeporte
{
	public static final String NOMBRE = "Voleibol";

	@Override
	public String getNombre( )
	{
		return NOMBRE;
	}

	@Override
	public int getMinimoJugadores( )
	{
		return 6;
	}

	@Override
	public int getPuntosPorVictoria( )
	{
		return 3;
	}

	@Override
	public int getPuntosPorEmpate( )
	{
		return 0;
	}

	@Override
	public boolean permiteEmpate( )
	{
		return false;
	}

	@Override
	public boolean manejaTarjetas( )
	{
		return false;
	}

	@Override
	public boolean usaSets( )
	{
		return true;
	}

	@Override
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido )
	{
		return new EstadisticaVoleibol( jugador, partido );
	}
}
