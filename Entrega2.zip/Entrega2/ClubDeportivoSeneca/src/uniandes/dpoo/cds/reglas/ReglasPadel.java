package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaRaqueta;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DEL PADEL
 *
 * Esta es la unica que dice que no a los sencillos, pues el padel siempre se
 * juega de a cuatro.
 */
public class ReglasPadel extends ReglasRaquetaBase
{
	public static final String NOMBRE = "Padel";

	@Override
	public String getNombre( )
	{
		return NOMBRE;
	}

	@Override
	public boolean admiteSencillos( )
	{
		return false;
	}

	@Override
	public boolean admiteDobles( )
	{
		return true;
	}

	@Override
	protected double getFactorAjuste( )
	{
		return 32.0;
	}

	@Override
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido )
	{
		return new EstadisticaRaqueta( jugador, partido );
	}
}
