package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DE UNA DISCIPLINA INDIVIDUAL, PATRON STRATEGY
 *
 * Es lo mismo que ReglasDeporte pero para las de raqueta.
 *
 * Tenis, padel y ping pong comparten la estructura, o sea inscripcion, cancha,
 * reserva y partido de practica, pero cambian en cuantos caben en la cancha, en
 * si admiten sencillos o solo dobles, y en que estadistica producen.
 *
 * Aqui ademas va el calculo del ranking, pues el factor de ajuste puede ser
 * distinto en cada disciplina y asi.
 */
public interface ReglasDisciplina extends java.io.Serializable
{
	/**
	 * COMO SE LLAMA LA DISCIPLINA
	 *
	 * @return el nombre de la disciplina
	 */
	public String getNombre( );

	/**
	 * REVISAR SI ADMITE SENCILLOS
	 *
	 * El padel dice que no, pues ese siempre se juega en dobles.
	 *
	 * @return true si la disciplina admite partidos de a dos jugadores
	 */
	public boolean admiteSencillos( );

	/**
	 * REVISAR SI ADMITE DOBLES
	 *
	 * @return true si la disciplina admite partidos de a cuatro jugadores
	 */
	public boolean admiteDobles( );

	/**
	 * REVISAR SI ESA CANTIDAD DE JUGADORES SIRVE
	 *
	 * Junta las dos preguntas de arriba, entonces si son dos mira si admite
	 * sencillos y si son cuatro mira si admite dobles, y cualquier otro numero
	 * no sirve.
	 *
	 * @param numeroJugadores la cantidad de jugadores que se quiere inscribir
	 * @return true si la cantidad es admitida
	 */
	public boolean esNumeroJugadoresValido( int numeroJugadores );

	/**
	 * CON CUANTO PUNTAJE ARRANCA UN JUGADOR NUEVO
	 *
	 * @return el puntaje de ranking con el que entra un jugador recien inscrito
	 */
	public double getPuntajeInicial( );

	/**
	 * CALCULAR EL NUEVO PUNTAJE DESPUES DE UN PARTIDO
	 *
	 * Usamos una version sencilla del ELO, que es el sistema del ajedrez. La
	 * idea es que cuanto suba o baje depende de la diferencia entre los dos,
	 * entonces ganarle a alguien mejor que uno da mas puntos que ganarle a
	 * alguien peor y asi.
	 *
	 * @param puntajeJugador el puntaje actual del jugador
	 * @param puntajeRival el puntaje actual del rival
	 * @param gano true si el jugador gano el partido
	 * @return el nuevo puntaje
	 */
	public double calcularNuevoPuntaje( double puntajeJugador, double puntajeRival, boolean gano );

	/**
	 * CREAR LA ESTADISTICA DE LA DISCIPLINA
	 *
	 * Otro factory method, igual que en ReglasDeporte.
	 *
	 * @param jugador el afiliado que participo en el partido
	 * @param partido el partido de practica que se esta registrando
	 * @return una estadistica vacia del tipo adecuado
	 */
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido );
}
