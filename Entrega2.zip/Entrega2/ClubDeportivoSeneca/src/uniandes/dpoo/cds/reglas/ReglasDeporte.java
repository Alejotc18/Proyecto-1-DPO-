package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DE UN DEPORTE DE CONJUNTO, PATRON STRATEGY
 *
 * Aqui dice que tiene que saber responder cualquier deporte de conjunto.
 *
 * Futbol, baloncesto y voleibol se parecen en la estructura, o sea los tres
 * tienen equipos, partidos y estadisticas, pero cambian en las reglas: cuantos
 * jugadores minimos, cuantos puntos da ganar, si hay empate y si hay tarjetas.
 *
 * Entonces en vez de llenar Equipo y Partido de ifs tipo "si el deporte es
 * futbol haga esto, si no si es baloncesto haga esto otro", cada juego de
 * reglas es su propia clase y el equipo simplemente le pregunta a la suya.
 *
 * Lo bueno es que si manana el club mete un cuarto deporte pues solo se escribe
 * otra clase que implemente esta interfaz, y ni Equipo ni Partido se tocan.
 *
 * PATRON FACTORY METHOD
 * El metodo crearEstadistica es aparte: cada deporte sabe que tipo de
 * estadistica produce, entonces el que registra el partido no tiene que saber
 * si construye una EstadisticaFutbol o una EstadisticaVoleibol, solo pide y le
 * llega la que es y asi.
 */
public interface ReglasDeporte extends java.io.Serializable
{
	/**
	 * COMO SE LLAMA EL DEPORTE
	 *
	 * @return el nombre del deporte
	 */
	public String getNombre( );

	/**
	 * CUANTOS JUGADORES MINIMO
	 *
	 * En futbol son 7 y en baloncesto 5, entonces cada uno responde lo suyo.
	 *
	 * @return la cantidad minima de jugadores habilitados que debe presentar un equipo para poder disputar un partido
	 */
	public int getMinimoJugadores( );

	/**
	 * CUANTOS PUNTOS DA GANAR
	 *
	 * @return los puntos que otorga una victoria en los formatos de liga
	 */
	public int getPuntosPorVictoria( );

	/**
	 * CUANTOS PUNTOS DA EMPATAR
	 *
	 * @return los puntos que otorga un empate en los formatos de liga
	 */
	public int getPuntosPorEmpate( );

	/**
	 * REVISAR SI EL DEPORTE PERMITE EMPATE
	 *
	 * En futbol si pero en baloncesto y voleibol no, pues ahi alguien tiene que
	 * ganar si o si.
	 *
	 * @return true si el deporte admite que un partido termine en empate
	 */
	public boolean permiteEmpate( );

	/**
	 * REVISAR SI EL DEPORTE TIENE TARJETAS
	 *
	 * Solo el futbol, entonces de esto depende si se crean sanciones o no.
	 *
	 * @return true si en el deporte se registran tarjetas amarillas y rojas
	 */
	public boolean manejaTarjetas( );

	/**
	 * REVISAR SI EL MARCADOR ES POR SETS
	 *
	 * @return true si el marcador del deporte se lleva por sets
	 */
	public boolean usaSets( );

	/**
	 * CREAR LA ESTADISTICA DEL DEPORTE
	 *
	 * Este es el factory method: cada deporte devuelve la estadistica que le
	 * toca y el que llama ni se entera de cual es.
	 *
	 * @param jugador el afiliado que participo en el partido
	 * @param partido el partido que se esta registrando
	 * @return una estadistica vacia del tipo adecuado
	 */
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido );
}
