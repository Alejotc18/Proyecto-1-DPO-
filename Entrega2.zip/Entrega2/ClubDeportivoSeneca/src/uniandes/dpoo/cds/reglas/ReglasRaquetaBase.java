package uniandes.dpoo.cds.reglas;

/**
 * BASE DE LAS DISCIPLINAS DE RAQUETA, PATRON TEMPLATE METHOD
 *
 * Aqui va lo que las tres disciplinas de raqueta hacen igual.
 *
 * La cuenta del ELO es la misma para todas, entonces la escribimos una sola vez
 * aca y no la repetimos tres veces. Lo unico que cambia entre ellas es el factor
 * de ajuste, o sea que tan rapido se mueve el ranking, y eso si lo pone cada
 * subclase en getFactorAjuste.
 *
 * Es el mismo truco de Venta.liquidar: el procedimiento vive en el papa y las
 * subclases solo llenan el huequito y asi.
 */
public abstract class ReglasRaquetaBase implements ReglasDisciplina
{
	public static final double PUNTAJE_INICIAL = 1000.0;

	@Override
	public double getPuntajeInicial( )
	{
		return PUNTAJE_INICIAL;
	}

	/**
	 * EL FACTOR DE AJUSTE
	 *
	 * Este es el hueco que llena cada disciplina. Entre mas grande el numero,
	 * mas brusco se mueve el ranking despues de cada partido.
	 *
	 * @return el factor que determina que tan rapido se mueve el ranking de la disciplina
	 */
	protected abstract double getFactorAjuste( );

	@Override
	public double calcularNuevoPuntaje( double puntajeJugador, double puntajeRival, boolean gano )
	{
		double esperado = 1.0 / ( 1.0 + Math.pow( 10.0, ( puntajeRival - puntajeJugador ) / 400.0 ) );
		double resultado = 0.0;
		if( gano )
		{
			resultado = 1.0;
		}
		double nuevo = puntajeJugador + getFactorAjuste( ) * ( resultado - esperado );
		return Math.round( nuevo * 100.0 ) / 100.0;
	}

	@Override
	public boolean esNumeroJugadoresValido( int numeroJugadores )
	{
		if( numeroJugadores == 2 )
		{
			return admiteSencillos( );
		}
		if( numeroJugadores == 4 )
		{
			return admiteDobles( );
		}
		return false;
	}
}
