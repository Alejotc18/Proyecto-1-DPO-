package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaFutbol;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DEL FUTBOL
 *
 * Minimo 7 jugadores, ganar vale 3 puntos y empatar 1, si hay empate y si hay
 * tarjetas. Es el unico deporte del club con tarjetas, entonces es el unico que
 * genera sanciones y asi.
 */
public class ReglasFutbol implements ReglasDeporte
{
	public static final String NOMBRE = "Futbol";

	@Override
	public String getNombre( )
	{
		return NOMBRE;
	}

	@Override
	public int getMinimoJugadores( )
	{
		return 7;
	}

	@Override
	public int getPuntosPorVictoria( )
	{
		return 3;
	}

	@Override
	public int getPuntosPorEmpate( )
	{
		return 1;
	}

	@Override
	public boolean permiteEmpate( )
	{
		return true;
	}

	@Override
	public boolean manejaTarjetas( )
	{
		return true;
	}

	@Override
	public boolean usaSets( )
	{
		return false;
	}

	@Override
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido )
	{
		return new EstadisticaFutbol( jugador, partido );
	}
}
