package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaRaqueta;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DEL TENIS
 *
 * Admite sencillos y dobles, o sea de a dos o de a cuatro.
 */
public class ReglasTenis extends ReglasRaquetaBase
{
	public static final String NOMBRE = "Tenis";

	@Override
	public String getNombre( )
	{
		return NOMBRE;
	}

	@Override
	public boolean admiteSencillos( )
	{
		return true;
	}

	@Override
	public boolean admiteDobles( )
	{
		return true;
	}

	@Override
	protected double getFactorAjuste( )
	{
		return 32.0;
	}

	@Override
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido )
	{
		return new EstadisticaRaqueta( jugador, partido );
	}
}
