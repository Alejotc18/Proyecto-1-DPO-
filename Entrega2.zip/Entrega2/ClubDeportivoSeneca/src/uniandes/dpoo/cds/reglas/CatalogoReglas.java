package uniandes.dpoo.cds.reglas;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * CATALOGO DE REGLAS
 *
 * Es el unico sitio desde donde se piden las reglas de un deporte o de una
 * disciplina, dandole el nombre.
 *
 * Sirve sobre todo para la persistencia: en los archivos solo queda guardado el
 * nombre del deporte como texto, entonces al cargar hay que volver a conectar
 * cada equipo con su objeto de reglas. Sin este catalogo le tocaria a la clase
 * que lee los archivos armarlas con un monton de ifs y asi.
 *
 * Las reglas no guardan datos propios, o sea son siempre iguales, entonces con
 * una sola de cada una alcanza y se comparte entre todos los equipos del club.
 */
public class CatalogoReglas
{
	// nota: esto de aqui abajo es un Map y nosotros no lo vimos en clase.
	// Lo sugirio Claude como forma de implementarlo para que el codigo no
	// estalle, y lo dejamos porque si funciona.
	//
	// Un Map es como una lista pero en vez de buscar por posicion uno busca por
	// un nombre. Entonces aqui guardamos pares de "Futbol" -> el objeto de
	// reglas del futbol, y despues con get("Futbol") lo saca de una.
	//
	// Pues la alternativa era un if gigante preguntando si el texto es "Futbol",
	// si no si es "Baloncesto" y asi, y eso toca repetirlo en cada lado donde se
	// necesite y se nos olvida actualizarlo cuando agreguemos un deporte.
	//
	// El LinkedHashMap es un Map que ademas se acuerda del orden en que uno fue
	// metiendo las cosas, entonces los reportes salen siempre en el mismo orden
	// y no cambiando cada vez que se corre el programa.
	private static Map<String, ReglasDeporte> deportes;

	private static Map<String, ReglasDisciplina> disciplinas;

	// este bloque static se ejecuta una sola vez, cuando Java carga la clase, y
	// es donde dejamos armados los dos mapas con todo adentro
	static
	{
		deportes = new LinkedHashMap<String, ReglasDeporte>( );
		deportes.put( ReglasFutbol.NOMBRE, new ReglasFutbol( ) );
		deportes.put( ReglasBaloncesto.NOMBRE, new ReglasBaloncesto( ) );
		deportes.put( ReglasVoleibol.NOMBRE, new ReglasVoleibol( ) );

		disciplinas = new LinkedHashMap<String, ReglasDisciplina>( );
		disciplinas.put( ReglasTenis.NOMBRE, new ReglasTenis( ) );
		disciplinas.put( ReglasPadel.NOMBRE, new ReglasPadel( ) );
		disciplinas.put( ReglasTenisMesa.NOMBRE, new ReglasTenisMesa( ) );
	}

	/**
	 * BUSCAR LAS REGLAS DE UN DEPORTE
	 *
	 * Si le mandan un nombre que no existe entonces devuelve null, asi que toca
	 * revisarlo antes de usarlo o si no revienta mas adelante.
	 *
	 * @param nombre el nombre del deporte
	 * @return las reglas correspondientes, o null si el deporte no existe
	 */
	public static ReglasDeporte getDeporte( String nombre )
	{
		return deportes.get( nombre );
	}

	/**
	 * BUSCAR LAS REGLAS DE UNA DISCIPLINA
	 *
	 * Igual que el de arriba, si no existe devuelve null.
	 *
	 * @param nombre el nombre de la disciplina
	 * @return las reglas correspondientes, o null si la disciplina no existe
	 */
	public static ReglasDisciplina getDisciplina( String nombre )
	{
		return disciplinas.get( nombre );
	}

	public static Map<String, ReglasDeporte> getDeportes( )
	{
		return deportes;
	}

	public static Map<String, ReglasDisciplina> getDisciplinas( )
	{
		return disciplinas;
	}
}
