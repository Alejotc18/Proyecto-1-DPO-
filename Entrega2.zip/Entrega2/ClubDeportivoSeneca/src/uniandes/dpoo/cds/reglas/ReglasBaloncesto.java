package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaBaloncesto;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DEL BALONCESTO
 *
 * Minimo 5 jugadores, no hay empate pues siempre alguien gana, y no hay
 * tarjetas.
 */
public class ReglasBaloncesto implements ReglasDeporte
{
	public static final String NOMBRE = "Baloncesto";

	@Override
	public String getNombre( )
	{
		return NOMBRE;
	}

	@Override
	public int getMinimoJugadores( )
	{
		return 5;
	}

	@Override
	public int getPuntosPorVictoria( )
	{
		return 2;
	}

	@Override
	public int getPuntosPorEmpate( )
	{
		return 0;
	}

	@Override
	public boolean permiteEmpate( )
	{
		return false;
	}

	@Override
	public boolean manejaTarjetas( )
	{
		return false;
	}

	@Override
	public boolean usaSets( )
	{
		return false;
	}

	@Override
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido )
	{
		return new EstadisticaBaloncesto( jugador, partido );
	}
}
