package uniandes.dpoo.cds.reglas;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaTenisMesa;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * REGLAS DEL TENIS DE MESA
 *
 * Admite sencillos y dobles igual que el tenis, pero produce otra estadistica,
 * entonces por eso tiene su propia clase de estadistica y las otras dos si
 * comparten una.
 */
public class ReglasTenisMesa extends ReglasRaquetaBase
{
	public static final String NOMBRE = "Tenis de mesa";

	@Override
	public String getNombre( )
	{
		return NOMBRE;
	}

	@Override
	public boolean admiteSencillos( )
	{
		return true;
	}

	@Override
	public boolean admiteDobles( )
	{
		return true;
	}

	@Override
	protected double getFactorAjuste( )
	{
		return 24.0;
	}

	@Override
	public Estadistica crearEstadistica( Afiliado jugador, Partido partido )
	{
		return new EstadisticaTenisMesa( jugador, partido );
	}
}
