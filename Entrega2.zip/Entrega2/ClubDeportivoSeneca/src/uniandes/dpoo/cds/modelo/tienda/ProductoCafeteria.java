package uniandes.dpoo.cds.modelo.tienda;

/**
 * PRODUCTO DE CAFETERIA
 *
 * Es abstracta porque la cafeteria vende dos cosas con reglas distintas: las
 * bebidas, que pueden ser frias o calientes y tienen el lio de las canchas
 * techadas, y los snacks, que tienen que avisar sus alergenos.
 *
 * DECISION DE DISENO
 * En la Entrega 1 esto era una sola clase con un atributo tipoProducto y otro
 * de alergenos. Pero pues asi la mitad de los atributos quedaba siempre vacia,
 * o sea una bebida no tiene alergenos y un snack no tiene temperatura.
 * Entonces la partimos en dos subclases y cada una guarda solo lo suyo y asi.
 */
public abstract class ProductoCafeteria extends Producto
{
	private static final long serialVersionUID = 1L;

	public static final String RUBRO = "Cafeteria";

	public ProductoCafeteria( String codigo, String nombre, double precio, int cantidadDisponible )
	{
		super( codigo, nombre, precio, cantidadDisponible );
	}

	@Override
	public String getRubro( )
	{
		return RUBRO;
	}

	/**
	 * REVISAR SI SE PUEDE ENTREGAR EN UNA CANCHA TECHADA
	 *
	 * El snack siempre dice que si, la bebida depende de si esta caliente.
	 *
	 * @return true si no hay restriccion de seguridad
	 */
	public abstract boolean puedeEntregarseEnInstalacionTechada( );

	/**
	 * EL AVISO QUE HAY QUE MOSTRARLE AL COMPRADOR
	 *
	 * En el snack es la lista de alergenos y en la bebida es la advertencia de
	 * que esta caliente, entonces cada una arma lo suyo.
	 *
	 * @return el texto que debe mostrarse al afiliado antes de la compra
	 */
	public abstract String getAdvertencia( );
}
