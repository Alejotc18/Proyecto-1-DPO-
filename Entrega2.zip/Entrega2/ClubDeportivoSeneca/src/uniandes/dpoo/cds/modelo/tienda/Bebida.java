package uniandes.dpoo.cds.modelo.tienda;

/**
 * BEBIDA
 *
 * Es una bebida de la cafeteria, fria o caliente.
 *
 * Las calientes no se le pueden entregar a alguien que este metido en una
 * cancha de padel o en una mesa de ping pong techada, pues es una regla de
 * seguridad del club y asi.
 */
public class Bebida extends ProductoCafeteria
{
	private static final long serialVersionUID = 1L;

	private boolean caliente;

	private String tamanio;

	public Bebida( String codigo, String nombre, double precio, int cantidadDisponible, boolean caliente, String tamanio )
	{
		super( codigo, nombre, precio, cantidadDisponible );
		this.caliente = caliente;
		this.tamanio = tamanio;
	}

	/**
	 * REVISAR SI SE PUEDE ENTREGAR EN UNA CANCHA TECHADA
	 *
	 * la parte del codigo que puede hacerlo estallar es: aqui vive la restriccion
	 * de seguridad del enunciado, entonces si alguien le cambia el signo a esta
	 * comparacion se le entregan bebidas calientes a todo el mundo y nadie se da
	 * cuenta hasta que pase algo.
	 */
	@Override
	public boolean puedeEntregarseEnInstalacionTechada( )
	{
		return !caliente;
	}

	@Override
	public String getAdvertencia( )
	{
		if( caliente )
		{
			return "Bebida caliente: no se permite su ingreso a canchas de padel ni a mesas techadas";
		}
		return "";
	}

	public boolean isCaliente( )
	{
		return caliente;
	}

	public void setCaliente( boolean caliente )
	{
		this.caliente = caliente;
	}

	public String getTamanio( )
	{
		return tamanio;
	}

	public void setTamanio( String tamanio )
	{
		this.tamanio = tamanio;
	}
}
