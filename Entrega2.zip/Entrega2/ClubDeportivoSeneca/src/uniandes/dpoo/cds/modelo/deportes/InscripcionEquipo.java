package uniandes.dpoo.cds.modelo.deportes;

import java.io.Serializable;
import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;

/**
 * INSCRIPCION DE UN JUGADOR A UN EQUIPO
 *
 * Conecta al jugador con su equipo y guarda el numero de camiseta y la posicion.
 *
 * Existe como clase aparte porque esos dos datos no son del jugador ni del
 * equipo por separado: el mismo man puede llevar la 10 en futbol y la 7 en
 * voleibol, y un equipo tiene muchas camisetas. Entonces son datos de la union
 * de los dos y asi. A esto le dicen clase asociacion.
 */
public class InscripcionEquipo implements Serializable
{
	private static final long serialVersionUID = 1L;

	private AfiliadoConjunto jugador;

	private Equipo equipo;

	private int numeroCamiseta;

	private String posicion;

	private LocalDate fechaInscripcion;

	private boolean activa;

	public InscripcionEquipo( AfiliadoConjunto jugador, Equipo equipo, int numeroCamiseta, String posicion, LocalDate fechaInscripcion )
	{
		this.jugador = jugador;
		this.equipo = equipo;
		this.numeroCamiseta = numeroCamiseta;
		this.posicion = posicion;
		this.fechaInscripcion = fechaInscripcion;
		this.activa = true;
	}

	public AfiliadoConjunto getJugador( )
	{
		return jugador;
	}

	public void setJugador( AfiliadoConjunto jugador )
	{
		this.jugador = jugador;
	}

	public Equipo getEquipo( )
	{
		return equipo;
	}

	public void setEquipo( Equipo equipo )
	{
		this.equipo = equipo;
	}

	public int getNumeroCamiseta( )
	{
		return numeroCamiseta;
	}

	public void setNumeroCamiseta( int numeroCamiseta )
	{
		this.numeroCamiseta = numeroCamiseta;
	}

	public String getPosicion( )
	{
		return posicion;
	}

	public void setPosicion( String posicion )
	{
		this.posicion = posicion;
	}

	public LocalDate getFechaInscripcion( )
	{
		return fechaInscripcion;
	}

	public void setFechaInscripcion( LocalDate fechaInscripcion )
	{
		this.fechaInscripcion = fechaInscripcion;
	}

	public boolean isActiva( )
	{
		return activa;
	}

	public void setActiva( boolean activa )
	{
		this.activa = activa;
	}

	@Override
	public String toString( )
	{
		return jugador.getNombreCompleto( ) + " - " + equipo.getNombre( ) + " - camiseta " + numeroCamiseta + " (" + posicion + ")";
	}
}
