package uniandes.dpoo.cds.modelo.tienda;

import java.io.Serializable;

import uniandes.dpoo.cds.excepciones.InventarioInsuficienteException;

/**
 * PRODUCTO
 *
 * Es cualquier cosa que el club venda, de la tienda o de la cafeteria.
 *
 * Es abstracta pues nadie vende "un producto" asi en abstracto: vende una
 * raqueta, un cafe o unas galletas. Entonces aca arriba queda lo que todos
 * tienen, o sea el codigo, el nombre, el precio y cuantas unidades quedan.
 */
public abstract class Producto implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private String nombre;

	private double precio;

	private int cantidadDisponible;

	private boolean activo;

	public Producto( String codigo, String nombre, double precio, int cantidadDisponible )
	{
		this.codigo = codigo;
		this.nombre = nombre;
		this.precio = precio;
		this.cantidadDisponible = cantidadDisponible;
		this.activo = true;
	}

	/**
	 * A QUE RUBRO PERTENECE
	 *
	 * Sirve pues para los reportes de ventas, que van separados por tienda y
	 * cafeteria.
	 *
	 * @return el rubro contable al que pertenece el producto
	 */
	public abstract String getRubro( );

	/**
	 * DESCONTAR UNIDADES DEL INVENTARIO
	 *
	 * la parte del codigo que puede hacerlo estallar es: evita que se vendan unidades que no existen.
	 *
	 * @param cantidad la cantidad que se quiere vender
	 * @throws InventarioInsuficienteException si no hay unidades suficientes
	 */
	public void descontarInventario( int cantidad ) throws InventarioInsuficienteException
	{
		if( !activo )
		{
			throw new InventarioInsuficienteException( "El producto " + nombre + " no esta activo" );
		}
		if( cantidad > cantidadDisponible )
		{
			throw new InventarioInsuficienteException( "Solo quedan " + cantidadDisponible + " unidades de " + nombre + " y se pidieron " + cantidad );
		}
		cantidadDisponible = cantidadDisponible - cantidad;
	}

	/**
	 * AGREGAR UNIDADES AL INVENTARIO
	 *
	 * Es cuando llega mercancia nueva al club.
	 *
	 * @param cantidad la cantidad que llega al club
	 */
	public void reabastecer( int cantidad )
	{
		if( cantidad > 0 )
		{
			cantidadDisponible = cantidadDisponible + cantidad;
		}
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public double getPrecio( )
	{
		return precio;
	}

	public void setPrecio( double precio )
	{
		this.precio = precio;
	}

	public int getCantidadDisponible( )
	{
		return cantidadDisponible;
	}

	public void setCantidadDisponible( int cantidadDisponible )
	{
		this.cantidadDisponible = cantidadDisponible;
	}

	public boolean isActivo( )
	{
		return activo;
	}

	public void setActivo( boolean activo )
	{
		this.activo = activo;
	}

	@Override
	public boolean equals( Object objeto )
	{
		if( this == objeto )
		{
			return true;
		}
		if( objeto == null || !( objeto instanceof Producto ) )
		{
			return false;
		}
		return codigo.equals( ( ( Producto ) objeto ).codigo );
	}

	@Override
	public int hashCode( )
	{
		return codigo.hashCode( );
	}

	@Override
	public String toString( )
	{
		return nombre + " ($" + precio + ", " + cantidadDisponible + " disponibles)";
	}
}
