package uniandes.dpoo.cds.modelo.academias;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;

/**
 * RESERVA DE UNA INSTALACION
 *
 * Es cuando un afiliado individual pide una cancha o una mesa para una fecha y
 * unas horas.
 *
 * CORRECCION DE LA ENTREGA 1
 * Antes el bloque horario era un solo texto tipo "6 a 8 pm" y asi no se podia
 * revisar si dos reservas se pisaban. Entonces lo partimos en hora de inicio y
 * hora de fin, que son dos LocalTime, y ahi si se pueden comparar de una.
 */
public class Reserva implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private AfiliadoIndividual afiliado;

	private Instalacion instalacion;

	private LocalDate fecha;

	private LocalTime horaInicio;

	private LocalTime horaFin;

	private int numeroJugadores;

	private String modalidad;

	private String estado;

	private String motivoRechazo;

	public static final String CONFIRMADA = "Confirmada";

	public static final String RECHAZADA = "Rechazada";

	public static final String CANCELADA = "Cancelada";

	public static final String CUMPLIDA = "Cumplida";

	public Reserva( String codigo, AfiliadoIndividual afiliado, Instalacion instalacion, LocalDate fecha, LocalTime horaInicio, LocalTime horaFin, int numeroJugadores, String modalidad )
	{
		this.codigo = codigo;
		this.afiliado = afiliado;
		this.instalacion = instalacion;
		this.fecha = fecha;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
		this.numeroJugadores = numeroJugadores;
		this.modalidad = modalidad;
		this.estado = CONFIRMADA;
		this.motivoRechazo = "";
	}

	public boolean estaConfirmada( )
	{
		return CONFIRMADA.equals( estado );
	}

	public void rechazar( String motivo )
	{
		this.estado = RECHAZADA;
		this.motivoRechazo = motivo;
	}

	public void cancelar( )
	{
		this.estado = CANCELADA;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public AfiliadoIndividual getAfiliado( )
	{
		return afiliado;
	}

	public void setAfiliado( AfiliadoIndividual afiliado )
	{
		this.afiliado = afiliado;
	}

	public Instalacion getInstalacion( )
	{
		return instalacion;
	}

	public void setInstalacion( Instalacion instalacion )
	{
		this.instalacion = instalacion;
	}

	public LocalDate getFecha( )
	{
		return fecha;
	}

	public void setFecha( LocalDate fecha )
	{
		this.fecha = fecha;
	}

	public LocalTime getHoraInicio( )
	{
		return horaInicio;
	}

	public void setHoraInicio( LocalTime horaInicio )
	{
		this.horaInicio = horaInicio;
	}

	public LocalTime getHoraFin( )
	{
		return horaFin;
	}

	public void setHoraFin( LocalTime horaFin )
	{
		this.horaFin = horaFin;
	}

	public int getNumeroJugadores( )
	{
		return numeroJugadores;
	}

	public void setNumeroJugadores( int numeroJugadores )
	{
		this.numeroJugadores = numeroJugadores;
	}

	public String getModalidad( )
	{
		return modalidad;
	}

	public void setModalidad( String modalidad )
	{
		this.modalidad = modalidad;
	}

	public String getEstado( )
	{
		return estado;
	}

	public void setEstado( String estado )
	{
		this.estado = estado;
	}

	public String getMotivoRechazo( )
	{
		return motivoRechazo;
	}

	public void setMotivoRechazo( String motivoRechazo )
	{
		this.motivoRechazo = motivoRechazo;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + instalacion.getNombre( ) + " | " + fecha + " " + horaInicio + "-" + horaFin + " | " + numeroJugadores + " jugadores | " + estado;
	}
}
