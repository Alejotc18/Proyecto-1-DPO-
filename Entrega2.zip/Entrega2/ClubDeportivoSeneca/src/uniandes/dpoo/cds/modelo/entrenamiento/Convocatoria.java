package uniandes.dpoo.cds.modelo.entrenamiento;

import java.io.Serializable;

import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * CONVOCATORIA
 *
 * Es cuando llaman a un afiliado a una sesion de entrenamiento.
 *
 * Existe como clase aparte pues la asistencia y la nota de desempeno no son del
 * jugador ni de la sesion: son de ese jugador en esa sesion especifica.
 * Entonces el mismo man puede faltar a una y sacar cinco en la siguiente, y eso
 * hay que guardarlo por separado y asi.
 */
public class Convocatoria implements Serializable
{
	private static final long serialVersionUID = 1L;

	private Afiliado jugador;

	private SesionEntrenamiento sesion;

	private String estadoAsistencia;

	private boolean registrada;

	private int nota;

	private String comentario;

	public static final String PENDIENTE = "Pendiente";

	public static final String ASISTIO = "Asistio";

	public static final String FALTO = "Falto";

	public static final String LLEGO_TARDE = "Llego tarde";

	public static final int NOTA_MINIMA = 1;

	public static final int NOTA_MAXIMA = 5;

	public Convocatoria( Afiliado jugador, SesionEntrenamiento sesion )
	{
		this.jugador = jugador;
		this.sesion = sesion;
		this.estadoAsistencia = PENDIENTE;
		this.registrada = false;
		this.nota = 0;
		this.comentario = "";
	}

	/**
	 * REGISTRAR LA ASISTENCIA
	 *
	 * Solo acepta tres valores: Asistio, Falto o Tarde. Si le mandan otra cosa
	 * entonces lanza excepcion, pues si no se nos llena de estados inventados y
	 * despues los reportes no cuadran.
	 *
	 * @param estado uno de los tres estados validos de asistencia
	 * @throws OperacionNoPermitidaException si el estado no es valido
	 */
	public void registrarAsistencia( String estado ) throws OperacionNoPermitidaException
	{
		if( !ASISTIO.equals( estado ) && !FALTO.equals( estado ) && !LLEGO_TARDE.equals( estado ) )
		{
			throw new OperacionNoPermitidaException( "El estado de asistencia '" + estado + "' no es valido" );
		}
		this.estadoAsistencia = estado;
		this.registrada = true;
	}

	/**
	 * REGISTRAR LA EVALUACION
	 *
	 * Es opcional, o sea el entrenador la pone si quiere. La nota tiene que estar
	 * entre 1 y 5 y si no, revienta.
	 *
	 * @param nota una calificacion entre 1 y 5
	 * @param comentario una observacion breve del entrenador
	 * @throws OperacionNoPermitidaException si la nota esta fuera del rango permitido
	 */
	public void registrarEvaluacion( int nota, String comentario ) throws OperacionNoPermitidaException
	{
		if( nota < NOTA_MINIMA || nota > NOTA_MAXIMA )
		{
			throw new OperacionNoPermitidaException( "La nota debe estar entre " + NOTA_MINIMA + " y " + NOTA_MAXIMA + ", y se recibio " + nota );
		}
		this.nota = nota;
		this.comentario = comentario;
	}

	public boolean tieneEvaluacion( )
	{
		return nota > 0;
	}

	public Afiliado getJugador( )
	{
		return jugador;
	}

	public void setJugador( Afiliado jugador )
	{
		this.jugador = jugador;
	}

	public SesionEntrenamiento getSesion( )
	{
		return sesion;
	}

	public void setSesion( SesionEntrenamiento sesion )
	{
		this.sesion = sesion;
	}

	public String getEstadoAsistencia( )
	{
		return estadoAsistencia;
	}

	public void setEstadoAsistencia( String estadoAsistencia )
	{
		this.estadoAsistencia = estadoAsistencia;
	}

	public boolean isRegistrada( )
	{
		return registrada;
	}

	public void setRegistrada( boolean registrada )
	{
		this.registrada = registrada;
	}

	public int getNota( )
	{
		return nota;
	}

	public void setNota( int nota )
	{
		this.nota = nota;
	}

	public String getComentario( )
	{
		return comentario;
	}

	public void setComentario( String comentario )
	{
		this.comentario = comentario;
	}

	@Override
	public String toString( )
	{
		String texto = jugador.getNombreCompleto( ) + ": " + estadoAsistencia;
		if( tieneEvaluacion( ) )
		{
			texto = texto + " | nota " + nota + " (" + comentario + ")";
		}
		return texto;
	}
}
