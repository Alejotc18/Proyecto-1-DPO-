package uniandes.dpoo.cds.modelo.deportes;

import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * ESTADISTICA DE TENIS DE MESA
 *
 * Esta si va aparte de tenis y padel, pues el ping pong cuenta puntos por set de
 * otra manera y entonces no se podia meter en la misma clase.
 */
public class EstadisticaTenisMesa extends Estadistica
{
	private static final long serialVersionUID = 1L;

	private int setsGanados;

	private int puntosTotales;

	public EstadisticaTenisMesa( Afiliado jugador, Partido partido )
	{
		super( jugador, partido );
		this.setsGanados = 0;
		this.puntosTotales = 0;
	}

	@Override
	public int getValorPrincipal( )
	{
		return setsGanados;
	}

	@Override
	public String getNombreValorPrincipal( )
	{
		return "Sets ganados";
	}

	@Override
	public String getResumen( )
	{
		return setsGanados + " sets, " + puntosTotales + " puntos";
	}

	public int getSetsGanados( )
	{
		return setsGanados;
	}

	public void setSetsGanados( int setsGanados )
	{
		this.setsGanados = setsGanados;
	}

	public int getPuntosTotales( )
	{
		return puntosTotales;
	}

	public void setPuntosTotales( int puntosTotales )
	{
		this.puntosTotales = puntosTotales;
	}
}
