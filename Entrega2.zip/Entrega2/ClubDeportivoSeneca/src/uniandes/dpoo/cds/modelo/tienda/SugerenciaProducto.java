package uniandes.dpoo.cds.modelo.tienda;

import java.io.Serializable;
import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.personas.Administrador;
import uniandes.dpoo.cds.modelo.personas.Empleado;

/**
 * SUGERENCIA DE PRODUCTO
 *
 * Es cuando un empleado propone que el club empiece a vender algo nuevo.
 * Queda pendiente hasta que el administrador la apruebe o la rechace, pues el
 * empleado no puede meter productos por su cuenta y asi.
 */
public class SugerenciaProducto implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private String nombrePropuesto;

	private String descripcion;

	private Empleado proponente;

	private LocalDate fecha;

	private String estado;

	private Administrador aprobador;

	private String motivoDecision;

	public static final String PENDIENTE = "Pendiente";

	public static final String APROBADA = "Aprobada";

	public static final String RECHAZADA = "Rechazada";

	public SugerenciaProducto( String codigo, String nombrePropuesto, String descripcion, Empleado proponente, LocalDate fecha )
	{
		this.codigo = codigo;
		this.nombrePropuesto = nombrePropuesto;
		this.descripcion = descripcion;
		this.proponente = proponente;
		this.fecha = fecha;
		this.estado = PENDIENTE;
		this.motivoDecision = "";
	}

	public boolean estaPendiente( )
	{
		return PENDIENTE.equals( estado );
	}

	public void aprobar( Administrador administrador )
	{
		this.estado = APROBADA;
		this.aprobador = administrador;
		this.motivoDecision = "Aprobada por el administrador";
	}

	public void rechazar( Administrador administrador, String motivo )
	{
		this.estado = RECHAZADA;
		this.aprobador = administrador;
		this.motivoDecision = motivo;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public String getNombrePropuesto( )
	{
		return nombrePropuesto;
	}

	public void setNombrePropuesto( String nombrePropuesto )
	{
		this.nombrePropuesto = nombrePropuesto;
	}

	public String getDescripcion( )
	{
		return descripcion;
	}

	public void setDescripcion( String descripcion )
	{
		this.descripcion = descripcion;
	}

	public Empleado getProponente( )
	{
		return proponente;
	}

	public void setProponente( Empleado proponente )
	{
		this.proponente = proponente;
	}

	public LocalDate getFecha( )
	{
		return fecha;
	}

	public void setFecha( LocalDate fecha )
	{
		this.fecha = fecha;
	}

	public String getEstado( )
	{
		return estado;
	}

	public void setEstado( String estado )
	{
		this.estado = estado;
	}

	public Administrador getAprobador( )
	{
		return aprobador;
	}

	public String getMotivoDecision( )
	{
		return motivoDecision;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + nombrePropuesto + " | propuesta por " + proponente.getNombreCompleto( ) + " | " + estado;
	}
}
