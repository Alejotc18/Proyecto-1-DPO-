package uniandes.dpoo.cds.modelo.deportes;

import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * ESTADISTICA DE VOLEIBOL
 *
 * Guarda puntos, bloqueos, saques y recepciones, que es lo que mide el voleibol.
 * Este deporte lleva el marcador por sets entonces no se parece a los otros dos.
 */
public class EstadisticaVoleibol extends Estadistica
{
	private static final long serialVersionUID = 1L;

	private int aces;

	private int bloqueos;

	public EstadisticaVoleibol( Afiliado jugador, Partido partido )
	{
		super( jugador, partido );
		this.aces = 0;
		this.bloqueos = 0;
	}

	@Override
	public int getValorPrincipal( )
	{
		return aces;
	}

	@Override
	public String getNombreValorPrincipal( )
	{
		return "Aces";
	}

	@Override
	public String getResumen( )
	{
		return aces + " aces, " + bloqueos + " bloqueos";
	}

	public int getAces( )
	{
		return aces;
	}

	public void setAces( int aces )
	{
		this.aces = aces;
	}

	public int getBloqueos( )
	{
		return bloqueos;
	}

	public void setBloqueos( int bloqueos )
	{
		this.bloqueos = bloqueos;
	}
}
