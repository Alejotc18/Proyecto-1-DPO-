package uniandes.dpoo.cds.modelo.entrenamiento;

import java.io.Serializable;
import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.personas.Administrador;
import uniandes.dpoo.cds.modelo.personas.Empleado;

/**
 * SOLICITUD DE CAMBIO DE TURNO
 *
 * Es cuando un empleado pide que le muevan uno de sus turnos.
 *
 * Queda pendiente hasta que el administrador diga si o no. Y solo se puede
 * aprobar si despues del cambio el club igual conserva la cobertura minima de
 * personal, pero esa cuenta no se hace aqui sino en la clase Club, pues toca
 * mirar los turnos de todo el mundo y no solo este.
 */
public class SolicitudCambioTurno implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private Empleado solicitante;

	private Turno turno;

	private LocalDate fechaSolicitud;

	private String motivo;

	private String estado;

	private Administrador aprobador;

	private LocalDate fechaDecision;

	private String observacionDecision;

	public static final String PENDIENTE = "Pendiente";

	public static final String APROBADA = "Aprobada";

	public static final String RECHAZADA = "Rechazada";

	public SolicitudCambioTurno( String codigo, Empleado solicitante, Turno turno, LocalDate fechaSolicitud, String motivo )
	{
		this.codigo = codigo;
		this.solicitante = solicitante;
		this.turno = turno;
		this.fechaSolicitud = fechaSolicitud;
		this.motivo = motivo;
		this.estado = PENDIENTE;
		this.observacionDecision = "";
	}

	public boolean estaPendiente( )
	{
		return PENDIENTE.equals( estado );
	}

	/**
	 * APROBAR LA SOLICITUD
	 *
	 * Guarda quien la aprobo y cuando, pues despues alguien va a preguntar y hay
	 * que poder responder.
	 *
	 * @param administrador el administrador que aprueba
	 * @param fecha la fecha de la decision
	 */
	public void aprobar( Administrador administrador, LocalDate fecha )
	{
		this.estado = APROBADA;
		this.aprobador = administrador;
		this.fechaDecision = fecha;
		this.observacionDecision = "Aprobada sin afectar la cobertura minima";
	}

	/**
	 * RECHAZAR LA SOLICITUD
	 *
	 * Ademas de rechazarla guarda el motivo, entonces el empleado sabe por que le
	 * dijeron que no y asi.
	 *
	 * @param administrador el administrador que rechaza
	 * @param fecha la fecha de la decision
	 * @param observacion la razon del rechazo
	 */
	public void rechazar( Administrador administrador, LocalDate fecha, String observacion )
	{
		this.estado = RECHAZADA;
		this.aprobador = administrador;
		this.fechaDecision = fecha;
		this.observacionDecision = observacion;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public Empleado getSolicitante( )
	{
		return solicitante;
	}

	public void setSolicitante( Empleado solicitante )
	{
		this.solicitante = solicitante;
	}

	public Turno getTurno( )
	{
		return turno;
	}

	public void setTurno( Turno turno )
	{
		this.turno = turno;
	}

	public LocalDate getFechaSolicitud( )
	{
		return fechaSolicitud;
	}

	public void setFechaSolicitud( LocalDate fechaSolicitud )
	{
		this.fechaSolicitud = fechaSolicitud;
	}

	public String getMotivo( )
	{
		return motivo;
	}

	public void setMotivo( String motivo )
	{
		this.motivo = motivo;
	}

	public String getEstado( )
	{
		return estado;
	}

	public void setEstado( String estado )
	{
		this.estado = estado;
	}

	public Administrador getAprobador( )
	{
		return aprobador;
	}

	public void setAprobador( Administrador aprobador )
	{
		this.aprobador = aprobador;
	}

	public LocalDate getFechaDecision( )
	{
		return fechaDecision;
	}

	public void setFechaDecision( LocalDate fechaDecision )
	{
		this.fechaDecision = fechaDecision;
	}

	public String getObservacionDecision( )
	{
		return observacionDecision;
	}

	public void setObservacionDecision( String observacionDecision )
	{
		this.observacionDecision = observacionDecision;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + solicitante.getNombreCompleto( ) + " | turno " + turno.getCodigo( ) + " | " + estado;
	}
}
