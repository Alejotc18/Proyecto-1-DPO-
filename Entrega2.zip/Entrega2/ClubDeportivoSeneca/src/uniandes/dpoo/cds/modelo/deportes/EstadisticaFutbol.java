package uniandes.dpoo.cds.modelo.deportes;

import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * ESTADISTICA DE FUTBOL
 *
 * Es la unica que lleva tarjetas, pues en baloncesto y voleibol no hay.
 *
 * Las tarjetas las guardamos como dos contadores aparte, uno de amarillas y
 * otro de rojas, y no como un texto. Entonces aplicar la regla de la suspension
 * es solo mirar los numeros, en vez de andar leyendo una cadena a ver que dice
 * y asi.
 */
public class EstadisticaFutbol extends Estadistica
{
	private static final long serialVersionUID = 1L;

	private int goles;

	private int asistencias;

	private int amarillas;

	private int rojas;

	private int faltasCometidas;

	public EstadisticaFutbol( Afiliado jugador, Partido partido )
	{
		super( jugador, partido );
		this.goles = 0;
		this.asistencias = 0;
		this.amarillas = 0;
		this.rojas = 0;
		this.faltasCometidas = 0;
	}

	/**
	 * REVISAR SI EL JUGADOR QUEDA SUSPENDIDO
	 *
	 * La regla del club es que dos amarillas o una roja lo dejan por fuera del
	 * siguiente partido de su equipo.
	 *
	 * la parte del codigo que puede hacerlo estallar es: de este metodo depende la creacion automatica de sanciones.
	 *
	 * @return true si el jugador queda suspendido
	 */
	public boolean generaSuspension( )
	{
		return amarillas >= 2 || rojas >= 1;
	}

	/**
	 * POR QUE QUEDO SUSPENDIDO
	 *
	 * Devuelve el motivo escrito, pues la sancion se guarda con la razon para que
	 * despues uno sepa de donde salio.
	 *
	 * @return el motivo por el que el jugador quedo suspendido
	 */
	public String getMotivoSuspension( )
	{
		if( rojas >= 1 )
		{
			return "Tarjeta roja";
		}
		if( amarillas >= 2 )
		{
			return "Acumulacion de dos tarjetas amarillas";
		}
		return "";
	}

	@Override
	public int getValorPrincipal( )
	{
		return goles;
	}

	@Override
	public String getNombreValorPrincipal( )
	{
		return "Goles";
	}

	@Override
	public String getResumen( )
	{
		return goles + " goles, " + asistencias + " asistencias, " + amarillas + " amarillas, " + rojas + " rojas";
	}

	public int getGoles( )
	{
		return goles;
	}

	public void setGoles( int goles )
	{
		this.goles = goles;
	}

	public int getAsistencias( )
	{
		return asistencias;
	}

	public void setAsistencias( int asistencias )
	{
		this.asistencias = asistencias;
	}

	public int getAmarillas( )
	{
		return amarillas;
	}

	public void setAmarillas( int amarillas )
	{
		this.amarillas = amarillas;
	}

	public int getRojas( )
	{
		return rojas;
	}

	public void setRojas( int rojas )
	{
		this.rojas = rojas;
	}

	public int getFaltasCometidas( )
	{
		return faltasCometidas;
	}

	public void setFaltasCometidas( int faltasCometidas )
	{
		this.faltasCometidas = faltasCometidas;
	}
}
