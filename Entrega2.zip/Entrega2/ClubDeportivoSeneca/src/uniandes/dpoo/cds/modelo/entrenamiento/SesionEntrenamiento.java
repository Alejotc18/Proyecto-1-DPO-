package uniandes.dpoo.cds.modelo.entrenamiento;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Instalacion;
import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.personas.Afiliado;
import uniandes.dpoo.cds.modelo.personas.Entrenador;

/**
 * SESION DE ENTRENAMIENTO
 *
 * Es un entrenamiento que arma un entrenador.
 *
 * Puede ser para un equipo completo o para un grupito de una academia de
 * raqueta. Por eso el equipo aqui es opcional, o sea puede quedar en null:
 * entonces cuando la sesion es de una academia la lista de convocados se va
 * armando persona por persona y asi.
 */
public class SesionEntrenamiento implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private LocalDate fecha;

	private LocalTime hora;

	private int duracionMinutos;

	private String objetivo;

	private Entrenador entrenador;

	private Instalacion instalacion;

	private Equipo equipo;

	private List<Convocatoria> convocatorias;

	private boolean finalizada;

	public SesionEntrenamiento( String codigo, LocalDate fecha, LocalTime hora, int duracionMinutos, String objetivo, Entrenador entrenador, Instalacion instalacion )
	{
		this.codigo = codigo;
		this.fecha = fecha;
		this.hora = hora;
		this.duracionMinutos = duracionMinutos;
		this.objetivo = objetivo;
		this.entrenador = entrenador;
		this.instalacion = instalacion;
		this.convocatorias = new ArrayList<Convocatoria>( );
		this.finalizada = false;
	}

	/**
	 * CONVOCAR A UN AFILIADO
	 *
	 * Le crea su convocatoria y la mete a la lista de la sesion.
	 *
	 * @param jugador el afiliado que se quiere convocar
	 * @return la convocatoria creada
	 */
	public Convocatoria convocar( Afiliado jugador )
	{
		Convocatoria convocatoria = new Convocatoria( jugador, this );
		convocatorias.add( convocatoria );
		return convocatoria;
	}

	/**
	 * CONVOCAR A TODO UN EQUIPO
	 *
	 * Es el atajo para no tener que llamar uno por uno, entonces recorre las
	 * inscripciones activas del equipo y convoca a cada jugador.
	 *
	 * @param equipo el equipo que se va a entrenar
	 */
	public void convocarEquipo( Equipo equipo )
	{
		this.equipo = equipo;
		for( uniandes.dpoo.cds.modelo.deportes.InscripcionEquipo inscripcion : equipo.getInscripciones( ) )
		{
			if( inscripcion.isActiva( ) )
			{
				convocar( inscripcion.getJugador( ) );
			}
		}
	}

	/**
	 * BUSCAR LA CONVOCATORIA DE UN JUGADOR
	 *
	 * Si el jugador no fue convocado entonces aqui lanzamos excepcion en vez de
	 * devolver null. Pues ponerle asistencia a alguien que nadie llamo no es un
	 * caso normal, es un error, y es mejor que reviente ahi mismo a que se
	 * guarde un dato raro sin que nadie se entere.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es la validacion de la historia de usuario HU-04.
	 *
	 * @param jugador el afiliado que se esta buscando
	 * @return la convocatoria correspondiente
	 * @throws OperacionNoPermitidaException si el jugador no fue convocado
	 */
	public Convocatoria buscarConvocatoria( Afiliado jugador ) throws OperacionNoPermitidaException
	{
		for( Convocatoria convocatoria : convocatorias )
		{
			if( convocatoria.getJugador( ).equals( jugador ) )
			{
				return convocatoria;
			}
		}
		throw new OperacionNoPermitidaException( "El jugador " + jugador.getNombreCompleto( ) + " no pertenece a la convocatoria de la sesion " + codigo );
	}

	/**
	 * CUANTOS ASISTIERON
	 *
	 * @return la cantidad de convocados que asistieron a la sesion
	 */
	public int contarAsistentes( )
	{
		int total = 0;
		for( Convocatoria convocatoria : convocatorias )
		{
			if( Convocatoria.ASISTIO.equals( convocatoria.getEstadoAsistencia( ) ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	/**
	 * PORCENTAJE DE ASISTENCIA
	 *
	 * Ojo que si no hay nadie convocado esto seria dividir entre cero, entonces
	 * toca revisarlo antes o si no revienta.
	 *
	 * @return el porcentaje de asistencia de la sesion
	 */
	public double getPorcentajeAsistencia( )
	{
		if( convocatorias.isEmpty( ) )
		{
			return 0.0;
		}
		return ( contarAsistentes( ) * 100.0 ) / convocatorias.size( );
	}

	public void finalizar( )
	{
		this.finalizada = true;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public LocalDate getFecha( )
	{
		return fecha;
	}

	public void setFecha( LocalDate fecha )
	{
		this.fecha = fecha;
	}

	public LocalTime getHora( )
	{
		return hora;
	}

	public void setHora( LocalTime hora )
	{
		this.hora = hora;
	}

	public int getDuracionMinutos( )
	{
		return duracionMinutos;
	}

	public void setDuracionMinutos( int duracionMinutos )
	{
		this.duracionMinutos = duracionMinutos;
	}

	public String getObjetivo( )
	{
		return objetivo;
	}

	public void setObjetivo( String objetivo )
	{
		this.objetivo = objetivo;
	}

	public Entrenador getEntrenador( )
	{
		return entrenador;
	}

	public void setEntrenador( Entrenador entrenador )
	{
		this.entrenador = entrenador;
	}

	public Instalacion getInstalacion( )
	{
		return instalacion;
	}

	public void setInstalacion( Instalacion instalacion )
	{
		this.instalacion = instalacion;
	}

	public Equipo getEquipo( )
	{
		return equipo;
	}

	public void setEquipo( Equipo equipo )
	{
		this.equipo = equipo;
	}

	public List<Convocatoria> getConvocatorias( )
	{
		return convocatorias;
	}

	public boolean isFinalizada( )
	{
		return finalizada;
	}

	public void setFinalizada( boolean finalizada )
	{
		this.finalizada = finalizada;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + fecha + " " + hora + " | " + objetivo + " | " + convocatorias.size( ) + " convocados";
	}
}
