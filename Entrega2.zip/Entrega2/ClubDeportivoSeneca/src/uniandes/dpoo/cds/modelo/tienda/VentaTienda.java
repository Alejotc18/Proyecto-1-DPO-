package uniandes.dpoo.cds.modelo.tienda;

import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * VENTA DE LA TIENDA
 *
 * Cobra IVA del 19% y no lleva propina.
 *
 * Por eso no redefine calcularValorAdicional: lo deja como viene del papa, que
 * devuelve cero. Entonces esta clase casi no tiene codigo propio y eso es justo
 * lo bueno del metodo plantilla y asi.
 */
public class VentaTienda extends Venta
{
	private static final long serialVersionUID = 1L;

	public static final double IVA = 0.19;

	public VentaTienda( String codigo, LocalDate fecha, Persona comprador )
	{
		super( codigo, fecha, comprador );
	}

	@Override
	public double getPorcentajeImpuesto( )
	{
		return IVA;
	}

	@Override
	public String getNombreImpuesto( )
	{
		return "IVA (19%)       ";
	}

	@Override
	public String getRubro( )
	{
		return ArticuloDeportivo.RUBRO;
	}
}
