package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.deportes.InscripcionEquipo;
import uniandes.dpoo.cds.modelo.deportes.Sancion;

/**
 * AFILIADO DE DEPORTES DE CONJUNTO
 *
 * Es el socio que juega futbol, baloncesto o voleibol, o sea en equipo.
 *
 * Ojo con algo: este jugador no apunta directo al equipo sino que pasa por una
 * InscripcionEquipo. Pues el numero de camiseta y la posicion no son del
 * jugador ni del equipo por aparte, son de la union de los dos, entonces toca
 * una clase en la mitad que los guarde y asi.
 */
public class AfiliadoConjunto extends Afiliado
{
	private static final long serialVersionUID = 1L;

	private List<InscripcionEquipo> inscripciones;

	private List<Sancion> sanciones;

	public AfiliadoConjunto( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoAfiliado, LocalDate fechaAfiliacion )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password, codigoAfiliado, fechaAfiliacion );
		this.inscripciones = new ArrayList<InscripcionEquipo>( );
		this.sanciones = new ArrayList<Sancion>( );
	}

	/**
	 * REVISAR SI EL JUGADOR PUEDE JUGAR
	 *
	 * El jugador queda por fuera mientras tenga aunque sea una sancion con
	 * partidos sin cumplir en ese equipo, entonces hasta que no la termine de
	 * pagar no lo pueden alinear.
	 *
	 * la parte del codigo que puede hacerlo estallar es: esta es la regla que responde la historia de usuario HU-02.
	 *
	 * @param equipo el equipo en el que se quiere alinear al jugador
	 * @return true si el jugador esta habilitado
	 */
	public boolean estaHabilitado( Equipo equipo )
	{
		if( !isActivo( ) )
		{
			return false;
		}
		if( buscarInscripcion( equipo ) == null )
		{
			return false;
		}
		for( Sancion sancion : sanciones )
		{
			if( sancion.estaVigente( ) && sancion.getEquipo( ).equals( equipo ) )
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * BUSCAR LA INSCRIPCION EN UN EQUIPO
	 *
	 * Recorre las inscripciones del jugador y devuelve la de ese equipo. Si no
	 * esta en ese equipo entonces devuelve null y el que llame tiene que
	 * revisarlo, pues si no se le revienta despues.
	 *
	 * @param equipo el equipo que se esta buscando
	 * @return la inscripcion correspondiente, o null si el jugador no pertenece al equipo
	 */
	public InscripcionEquipo buscarInscripcion( Equipo equipo )
	{
		for( InscripcionEquipo inscripcion : inscripciones )
		{
			if( inscripcion.isActiva( ) && inscripcion.getEquipo( ).equals( equipo ) )
			{
				return inscripcion;
			}
		}
		return null;
	}

	/**
	 * REVISAR SI YA JUEGA ESE DEPORTE
	 *
	 * La regla del club es que uno solo puede estar en un equipo por deporte,
	 * pero si puede estar en varios deportes al tiempo. Entonces alguien puede
	 * jugar futbol y baloncesto, pero no en dos equipos de futbol y asi.
	 *
	 * @param nombreDeporte el nombre del deporte que se quiere revisar
	 * @return true si ya tiene una inscripcion activa en ese deporte
	 */
	public boolean yaJuegaDeporte( String nombreDeporte )
	{
		for( InscripcionEquipo inscripcion : inscripciones )
		{
			if( inscripcion.isActiva( ) && inscripcion.getEquipo( ).getReglas( ).getNombre( ).equals( nombreDeporte ) )
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * SANCIONES QUE TODAVIA DEBE
	 *
	 * Filtra las sanciones y deja solo las que aun tienen partidos pendientes,
	 * pues las que ya pago no estorban.
	 *
	 * @return la lista de sanciones vigentes
	 */
	public List<Sancion> getSancionesVigentes( )
	{
		List<Sancion> vigentes = new ArrayList<Sancion>( );
		for( Sancion sancion : sanciones )
		{
			if( sancion.estaVigente( ) )
			{
				vigentes.add( sancion );
			}
		}
		return vigentes;
	}

	public void agregarInscripcion( InscripcionEquipo inscripcion )
	{
		inscripciones.add( inscripcion );
	}

	public void agregarSancion( Sancion sancion )
	{
		sanciones.add( sancion );
	}

	public List<InscripcionEquipo> getInscripciones( )
	{
		return inscripciones;
	}

	public List<Sancion> getSanciones( )
	{
		return sanciones;
	}

	@Override
	public String getRol( )
	{
		return "Afiliado de conjunto";
	}
}
