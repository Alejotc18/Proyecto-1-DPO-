package uniandes.dpoo.cds.modelo.deportes;

import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * ESTADISTICA DE TENIS Y DE PADEL
 *
 * Las dos disciplinas usan la misma clase pues miden exactamente lo mismo: sets
 * y games ganados, aces y errores no forzados.
 *
 * Hacer dos clases identicas solo para cambiarle el nombre no tendria sentido,
 * entonces la dejamos una sola. Ademas la disciplina igual se sabe por la
 * instalacion donde se jugo el partido y asi.
 */
public class EstadisticaRaqueta extends Estadistica
{
	private static final long serialVersionUID = 1L;

	private int setsGanados;

	private int gamesGanados;

	private int aces;

	private int erroresNoForzados;

	public EstadisticaRaqueta( Afiliado jugador, Partido partido )
	{
		super( jugador, partido );
		this.setsGanados = 0;
		this.gamesGanados = 0;
		this.aces = 0;
		this.erroresNoForzados = 0;
	}

	@Override
	public int getValorPrincipal( )
	{
		return setsGanados;
	}

	@Override
	public String getNombreValorPrincipal( )
	{
		return "Sets ganados";
	}

	@Override
	public String getResumen( )
	{
		return setsGanados + " sets, " + gamesGanados + " games, " + aces + " aces, " + erroresNoForzados + " errores no forzados";
	}

	public int getSetsGanados( )
	{
		return setsGanados;
	}

	public void setSetsGanados( int setsGanados )
	{
		this.setsGanados = setsGanados;
	}

	public int getGamesGanados( )
	{
		return gamesGanados;
	}

	public void setGamesGanados( int gamesGanados )
	{
		this.gamesGanados = gamesGanados;
	}

	public int getAces( )
	{
		return aces;
	}

	public void setAces( int aces )
	{
		this.aces = aces;
	}

	public int getErroresNoForzados( )
	{
		return erroresNoForzados;
	}

	public void setErroresNoForzados( int erroresNoForzados )
	{
		this.erroresNoForzados = erroresNoForzados;
	}
}
