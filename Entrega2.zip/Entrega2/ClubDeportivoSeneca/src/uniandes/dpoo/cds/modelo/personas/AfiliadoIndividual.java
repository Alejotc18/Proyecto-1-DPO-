package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.academias.InscripcionAcademia;

/**
 * AFILIADO DE DISCIPLINAS INDIVIDUALES
 *
 * Es el socio que practica tenis, padel o tenis de mesa, o sea solo.
 *
 * A diferencia del de conjunto este no pertenece a ningun equipo, entonces usa
 * las canchas por su cuenta y lo que manda es su nivel: segun el nivel puede o
 * no puede jugar contra alguien y asi.
 */
public class AfiliadoIndividual extends Afiliado
{
	private static final long serialVersionUID = 1L;

	private List<InscripcionAcademia> inscripciones;

	public AfiliadoIndividual( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoAfiliado, LocalDate fechaAfiliacion )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password, codigoAfiliado, fechaAfiliacion );
		this.inscripciones = new ArrayList<InscripcionAcademia>( );
	}

	/**
	 * BUSCAR LA INSCRIPCION EN UNA DISCIPLINA
	 *
	 * Si no esta inscrito en esa disciplina devuelve null, entonces toca
	 * revisarlo antes de usarlo.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return la inscripcion correspondiente, o null si no esta inscrito
	 */
	public InscripcionAcademia buscarInscripcion( String nombreDisciplina )
	{
		for( InscripcionAcademia inscripcion : inscripciones )
		{
			if( inscripcion.isActiva( ) && inscripcion.getReglas( ).getNombre( ).equals( nombreDisciplina ) )
			{
				return inscripcion;
			}
		}
		return null;
	}

	/**
	 * REVISAR SI PUEDE JUGAR CONTRA OTRO
	 *
	 * La regla del club es que solo se enfrentan jugadores del mismo nivel o de
	 * niveles seguidos, y ademas los dos tienen que estar inscritos en la misma
	 * disciplina. Pues un Principiante contra un Avanzado no tiene gracia.
	 *
	 * la parte del codigo que puede hacerlo estallar es: esta regla es la que valida el programa de prueba 5.
	 *
	 * @param rival el otro jugador
	 * @param nombreDisciplina la disciplina en la que se quiere jugar
	 * @return true si el emparejamiento esta permitido
	 */
	public boolean puedeJugarContra( AfiliadoIndividual rival, String nombreDisciplina )
	{
		InscripcionAcademia propia = buscarInscripcion( nombreDisciplina );
		InscripcionAcademia ajena = rival.buscarInscripcion( nombreDisciplina );
		if( propia == null || ajena == null )
		{
			return false;
		}
		int distancia = Math.abs( propia.getNivel( ).getOrden( ) - ajena.getNivel( ).getOrden( ) );
		return distancia <= 1;
	}

	public void agregarInscripcion( InscripcionAcademia inscripcion )
	{
		inscripciones.add( inscripcion );
	}

	public List<InscripcionAcademia> getInscripciones( )
	{
		return inscripciones;
	}

	@Override
	public String getRol( )
	{
		return "Afiliado individual";
	}
}
