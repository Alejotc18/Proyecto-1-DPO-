package uniandes.dpoo.cds.modelo.deportes;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * PARTIDO
 *
 * Es abstracta pues los tres tipos de partido se juegan contra cosas distintas:
 * el interno enfrenta a dos equipos del mismo club, el de competencia enfrenta
 * a un equipo de otra universidad, y el de practica enfrenta a afiliados
 * individuales en una cancha.
 *
 * Lo que los tres si comparten vive aca: la fecha, el marcador y las
 * estadisticas que produjo cada jugador que jugo.
 *
 * CORRECCION DE LA ENTREGA 1
 * Le quitamos el atributo tipo. Entonces el tipo ya se sabe por la clase que
 * es y por con quien se relaciona, asi que guardarlo ademas como texto era
 * tener el mismo dato dos veces y asi.
 */
public abstract class Partido implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private LocalDate fecha;

	private LocalTime hora;

	private int marcadorLocal;

	private int marcadorVisitante;

	private boolean jugado;

	private List<Estadistica> estadisticas;

	public Partido( String codigo, LocalDate fecha, LocalTime hora )
	{
		this.codigo = codigo;
		this.fecha = fecha;
		this.hora = hora;
		this.marcadorLocal = 0;
		this.marcadorVisitante = 0;
		this.jugado = false;
		this.estadisticas = new ArrayList<Estadistica>( );
	}

	/**
	 * REVISAR SI EL PARTIDO SE PUEDE JUGAR
	 *
	 * Este metodo esta vacio aqui a proposito, cada subclase lo llena con lo
	 * suyo. Pues el interno y el de competencia piden un minimo de jugadores
	 * habilitados, mientras que el de practica lo que pide es que los niveles
	 * sean compatibles, entonces no hay una sola respuesta que sirva para todos.
	 *
	 * @throws ClubException si alguna condicion no se cumple
	 */
	public abstract void validarPuedeJugarse( ) throws ClubException;

	/**
	 * QUIEN JUEGA CONTRA QUIEN
	 *
	 * Tambien lo llena cada subclase, pues en uno son dos equipos del club, en
	 * otro es el club contra una universidad y en otro son personas sueltas.
	 *
	 * @return una descripcion legible de quienes se enfrentan en el partido
	 */
	public abstract String getDescripcionRivales( );

	/**
	 * GUARDAR LA ESTADISTICA DE UN JUGADOR
	 *
	 * La estadistica ya viene armada desde el objeto de reglas del deporte,
	 * entonces aqui solo se guarda y este metodo ni se entera de que deporte es.
	 *
	 * @param estadistica la estadistica del jugador
	 */
	public void agregarEstadistica( Estadistica estadistica )
	{
		estadisticas.add( estadistica );
		Afiliado jugador = estadistica.getJugador( );
		jugador.agregarEstadistica( estadistica );
	}

	/**
	 * BUSCAR LA ESTADISTICA DE UN JUGADOR
	 *
	 * Si el jugador no jugo este partido entonces devuelve null, asi que toca
	 * revisarlo antes de usarlo.
	 *
	 * @param jugador el afiliado que se esta buscando
	 * @return la estadistica correspondiente, o null si el jugador no participo
	 */
	public Estadistica buscarEstadistica( Afiliado jugador )
	{
		for( Estadistica estadistica : estadisticas )
		{
			if( estadistica.getJugador( ).equals( jugador ) )
			{
				return estadistica;
			}
		}
		return null;
	}

	/**
	 * GUARDAR EL MARCADOR FINAL
	 *
	 * Ademas de guardar los goles marca el partido como ya jugado, pues de ahi en
	 * adelante ya cuenta para la clasificacion y para las sanciones y asi.
	 *
	 * @param marcadorLocal los tantos del local
	 * @param marcadorVisitante los tantos del visitante
	 */
	public void registrarMarcador( int marcadorLocal, int marcadorVisitante )
	{
		this.marcadorLocal = marcadorLocal;
		this.marcadorVisitante = marcadorVisitante;
		this.jugado = true;
	}

	/**
	 * COMO TERMINO EL PARTIDO PARA EL LOCAL
	 *
	 * Devuelve un numerito en vez de un texto, entonces el que lo use puede
	 * compararlo facil sin tener que leer cadenas.
	 *
	 * @return 1 si gano el local, 0 si empataron y -1 si gano el visitante
	 */
	public int getResultadoLocal( )
	{
		if( marcadorLocal > marcadorVisitante )
		{
			return 1;
		}
		if( marcadorLocal < marcadorVisitante )
		{
			return -1;
		}
		return 0;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public LocalDate getFecha( )
	{
		return fecha;
	}

	public void setFecha( LocalDate fecha )
	{
		this.fecha = fecha;
	}

	public LocalTime getHora( )
	{
		return hora;
	}

	public void setHora( LocalTime hora )
	{
		this.hora = hora;
	}

	public int getMarcadorLocal( )
	{
		return marcadorLocal;
	}

	public void setMarcadorLocal( int marcadorLocal )
	{
		this.marcadorLocal = marcadorLocal;
	}

	public int getMarcadorVisitante( )
	{
		return marcadorVisitante;
	}

	public void setMarcadorVisitante( int marcadorVisitante )
	{
		this.marcadorVisitante = marcadorVisitante;
	}

	public boolean isJugado( )
	{
		return jugado;
	}

	public void setJugado( boolean jugado )
	{
		this.jugado = jugado;
	}

	public List<Estadistica> getEstadisticas( )
	{
		return estadisticas;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + fecha + " | " + getDescripcionRivales( ) + " | " + marcadorLocal + "-" + marcadorVisitante;
	}
}
