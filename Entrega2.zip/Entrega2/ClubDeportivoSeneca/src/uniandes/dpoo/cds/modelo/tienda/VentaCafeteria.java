package uniandes.dpoo.cds.modelo.tienda;

import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * VENTA DE LA CAFETERIA
 *
 * Cobra impuesto al consumo del 8%, que es distinto del IVA de la tienda, y
 * ademas sugiere una propina del 10% que el afiliado puede cambiar.
 *
 * La propina la mete redefiniendo calcularValorAdicional, que es el huequito
 * que le deja el metodo plantilla de Venta, entonces no le toca reescribir todo
 * el procedimiento de liquidar y asi.
 */
public class VentaCafeteria extends Venta
{
	private static final long serialVersionUID = 1L;

	public static final double IMPUESTO_CONSUMO = 0.08;

	public static final double PROPINA_SUGERIDA = 0.10;

	private double porcentajePropina;

	public VentaCafeteria( String codigo, LocalDate fecha, Persona comprador )
	{
		super( codigo, fecha, comprador );
		this.porcentajePropina = PROPINA_SUGERIDA;
	}

	@Override
	public double getPorcentajeImpuesto( )
	{
		return IMPUESTO_CONSUMO;
	}

	@Override
	public String getNombreImpuesto( )
	{
		return "Imp. consumo (8%)";
	}

	@Override
	public String getRubro( )
	{
		return ProductoCafeteria.RUBRO;
	}

	/**
	 * CALCULAR LA PROPINA
	 *
	 * Este es el huequito que deja el metodo plantilla. La tienda lo deja en cero
	 * y la cafeteria pues lo usa para la propina.
	 */
	@Override
	protected double calcularValorAdicional( double base )
	{
		return base * porcentajePropina;
	}

	/**
	 * CAMBIAR EL PORCENTAJE DE PROPINA
	 *
	 * El 10% es solo una sugerencia, entonces el afiliado puede subirlo, bajarlo
	 * o dejarlo en cero.
	 *
	 * @param porcentajePropina el nuevo porcentaje, entre 0 y 1
	 */
	public void setPorcentajePropina( double porcentajePropina )
	{
		if( porcentajePropina >= 0.0 && porcentajePropina <= 1.0 )
		{
			this.porcentajePropina = porcentajePropina;
		}
	}

	public double getPorcentajePropina( )
	{
		return porcentajePropina;
	}
}
