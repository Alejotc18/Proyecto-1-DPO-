package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.entrenamiento.Turno;
import uniandes.dpoo.cds.modelo.tienda.CodigoDescuento;

/**
 * EMPLEADO, O SEA ALGUIEN QUE TRABAJA EN EL CLUB
 *
 * Es abstracta porque todo empleado es entrenador o fisioterapeuta.
 *
 * Los separamos pues el club pide minimos distintos de cada uno, o sea dos
 * entrenadores y un fisioterapeuta, entonces si los dejamos todos como
 * "empleado" no podriamos contar por aparte y la validacion no saldria.
 */
public abstract class Empleado extends Persona
{
	private static final long serialVersionUID = 1L;

	private String codigoEmpleado;

	private LocalDate fechaContratacion;

	private boolean activo;

	private CodigoDescuento codigoDescuento;

	private List<Turno> turnos;

	public Empleado( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoEmpleado, LocalDate fechaContratacion )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password );
		this.codigoEmpleado = codigoEmpleado;
		this.fechaContratacion = fechaContratacion;
		this.activo = true;
		this.turnos = new ArrayList<Turno>( );
	}

	/**
	 * REVISAR SI TIENE UNA SOLICITUD SIN RESPONDER
	 *
	 * La regla del club es que uno no puede tener dos solicitudes de cambio de
	 * turno pendientes al tiempo, entonces hay que revisar esto antes de dejarlo
	 * pedir otra.
	 *
	 * @return true si existe al menos una solicitud pendiente
	 */
	public boolean tieneSolicitudPendiente( )
	{
		for( Turno turno : turnos )
		{
			if( turno.tieneSolicitudPendiente( ) )
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * CONTAR LOS TURNOS DE UN DIA
	 *
	 * Sirve pues para saber cuanta gente hay cubriendo ese dia, que es lo que
	 * despues usa el club para revisar la cobertura minima.
	 *
	 * @param diaSemana el dia que se quiere revisar
	 * @param semana el identificador de la semana
	 * @return la cantidad de turnos vigentes
	 */
	public int contarTurnos( String diaSemana, String semana )
	{
		int total = 0;
		for( Turno turno : turnos )
		{
			if( turno.isVigente( ) && turno.getDiaSemana( ).equals( diaSemana ) && turno.getSemana( ).equals( semana ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	public void agregarTurno( Turno turno )
	{
		turnos.add( turno );
	}

	public String getCodigoEmpleado( )
	{
		return codigoEmpleado;
	}

	public void setCodigoEmpleado( String codigoEmpleado )
	{
		this.codigoEmpleado = codigoEmpleado;
	}

	public LocalDate getFechaContratacion( )
	{
		return fechaContratacion;
	}

	public void setFechaContratacion( LocalDate fechaContratacion )
	{
		this.fechaContratacion = fechaContratacion;
	}

	public boolean isActivo( )
	{
		return activo;
	}

	public void setActivo( boolean activo )
	{
		this.activo = activo;
	}

	public CodigoDescuento getCodigoDescuento( )
	{
		return codigoDescuento;
	}

	public void setCodigoDescuento( CodigoDescuento codigoDescuento )
	{
		this.codigoDescuento = codigoDescuento;
	}

	public List<Turno> getTurnos( )
	{
		return turnos;
	}
}
