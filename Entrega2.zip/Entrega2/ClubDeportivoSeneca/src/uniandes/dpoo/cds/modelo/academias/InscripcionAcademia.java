package uniandes.dpoo.cds.modelo.academias;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;
import uniandes.dpoo.cds.reglas.ReglasDisciplina;

/**
 * INSCRIPCION A UNA ACADEMIA
 *
 * Conecta a un afiliado individual con una disciplina, o sea con tenis, padel o
 * ping pong.
 *
 * Existe como clase aparte pues el nivel y el puntaje de ranking no son del
 * afiliado ni de la disciplina por separado: uno puede ser Avanzado en tenis y
 * Principiante en padel al mismo tiempo, entonces esos datos tienen que vivir en
 * la union de los dos y asi. A esto le dicen clase asociacion.
 *
 * CORRECCION DE LA ENTREGA 1
 * Antes la disciplina era un texto guardado dentro de AfiliadoIndividual, lo que
 * la monitora nos marco como atributo y relacion a la vez. Ahora es la relacion
 * de verdad con el objeto de reglas, que es lo que esta clase mantiene.
 */
public class InscripcionAcademia implements Serializable
{
	private static final long serialVersionUID = 1L;

	private AfiliadoIndividual afiliado;

	private ReglasDisciplina reglas;

	private Nivel nivel;

	private double puntajeRanking;

	private LocalDate fechaInscripcion;

	private boolean activa;

	private List<Double> historialRanking;

	public InscripcionAcademia( AfiliadoIndividual afiliado, ReglasDisciplina reglas, Nivel nivel, LocalDate fechaInscripcion )
	{
		this.afiliado = afiliado;
		this.reglas = reglas;
		this.nivel = nivel;
		this.fechaInscripcion = fechaInscripcion;
		this.puntajeRanking = reglas.getPuntajeInicial( );
		this.activa = true;
		this.historialRanking = new ArrayList<Double>( );
		this.historialRanking.add( this.puntajeRanking );
	}

	/**
	 * GUARDAR UN PUNTAJE NUEVO
	 *
	 * Le pone el puntaje nuevo pero tambien lo va guardando en una lista, pues
	 * para el Proyecto 3 toca mostrar como fue evolucionando el jugador y si solo
	 * guardamos el ultimo entonces perdemos toda la historia.
	 *
	 * @param nuevoPuntaje el puntaje despues del ultimo partido
	 */
	public void registrarCambioRanking( double nuevoPuntaje )
	{
		this.puntajeRanking = nuevoPuntaje;
		this.historialRanking.add( nuevoPuntaje );
	}

	/**
	 * CUANTO SE MOVIO EL RANKING
	 *
	 * Resta el puntaje de ahora contra el que tenia al principio, entonces si da
	 * positivo es que mejoro y si da negativo pues empeoro.
	 *
	 * @return cuanto se movio el ranking desde la inscripcion
	 */
	public double getVariacionTotal( )
	{
		return puntajeRanking - reglas.getPuntajeInicial( );
	}

	public AfiliadoIndividual getAfiliado( )
	{
		return afiliado;
	}

	public void setAfiliado( AfiliadoIndividual afiliado )
	{
		this.afiliado = afiliado;
	}

	public ReglasDisciplina getReglas( )
	{
		return reglas;
	}

	public void setReglas( ReglasDisciplina reglas )
	{
		this.reglas = reglas;
	}

	public Nivel getNivel( )
	{
		return nivel;
	}

	public void setNivel( Nivel nivel )
	{
		this.nivel = nivel;
	}

	public double getPuntajeRanking( )
	{
		return puntajeRanking;
	}

	public void setPuntajeRanking( double puntajeRanking )
	{
		this.puntajeRanking = puntajeRanking;
	}

	public LocalDate getFechaInscripcion( )
	{
		return fechaInscripcion;
	}

	public void setFechaInscripcion( LocalDate fechaInscripcion )
	{
		this.fechaInscripcion = fechaInscripcion;
	}

	public boolean isActiva( )
	{
		return activa;
	}

	public void setActiva( boolean activa )
	{
		this.activa = activa;
	}

	public List<Double> getHistorialRanking( )
	{
		return historialRanking;
	}

	@Override
	public String toString( )
	{
		return afiliado.getNombreCompleto( ) + " - " + reglas.getNombre( ) + " - " + nivel.getNombre( ) + " - ranking " + puntajeRanking;
	}
}
