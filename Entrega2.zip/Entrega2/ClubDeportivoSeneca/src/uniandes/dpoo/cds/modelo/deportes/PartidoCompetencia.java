package uniandes.dpoo.cds.modelo.deportes;

import java.time.LocalDate;
import java.time.LocalTime;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.EquipoIncompletoException;
import uniandes.dpoo.cds.modelo.competencias.Nomina;
import uniandes.dpoo.cds.reglas.ReglasDeporte;

/**
 * PARTIDO DE COMPETENCIA
 *
 * Es el partido oficial que juega un equipo del club en un torneo contra otra
 * universidad.
 *
 * Ojo con esto: aqui no apuntamos al Equipo sino a su Nomina. Pues solo los
 * jugadores que quedaron inscritos en la nomina de ese torneo pueden jugar los
 * partidos oficiales, entonces si apuntaramos al equipo completo esa regla
 * quedaria por fuera y tocaria validarla a mano en cada lado y asi.
 */
public class PartidoCompetencia extends Partido
{
	private static final long serialVersionUID = 1L;

	private Nomina nomina;

	private String institucionRival;

	private String escenario;

	private int jornada;

	private boolean local;

	public PartidoCompetencia( String codigo, LocalDate fecha, LocalTime hora, Nomina nomina, String institucionRival, String escenario, int jornada, boolean local )
	{
		super( codigo, fecha, hora );
		this.nomina = nomina;
		this.institucionRival = institucionRival;
		this.escenario = escenario;
		this.jornada = jornada;
		this.local = local;
	}

	/**
	 * REVISAR SI EL EQUIPO SE PUEDE PRESENTAR
	 *
	 * Mira que la nomina todavia tenga el minimo de jugadores habilitados que
	 * pide el torneo, pues si se sancionaron varios entonces ya no alcanza.
	 */
	@Override
	public void validarPuedeJugarse( ) throws ClubException
	{
		int habilitados = nomina.contarJugadoresHabilitados( );
		int minimo = nomina.getCompetencia( ).getNominaMinima( );
		if( habilitados < minimo )
		{
			throw new EquipoIncompletoException( "La nomina de " + nomina.getEquipo( ).getNombre( ) + " tiene " + habilitados + " jugadores habilitados y la competencia exige " + minimo );
		}
	}

	@Override
	public String getDescripcionRivales( )
	{
		if( local )
		{
			return nomina.getEquipo( ).getNombre( ) + " vs " + institucionRival;
		}
		return institucionRival + " vs " + nomina.getEquipo( ).getNombre( );
	}

	/**
	 * LAS REGLAS DEL DEPORTE
	 *
	 * Se las pide a la competencia, que es la que sabe de que deporte es.
	 *
	 * @return las reglas del deporte de la competencia
	 */
	public ReglasDeporte getReglas( )
	{
		return nomina.getEquipo( ).getReglas( );
	}

	/**
	 * COMO TERMINO PARA EL CLUB
	 *
	 * Lo que cambia frente al partido normal es que aqui el club puede ser local
	 * o visitante, entonces toca mirar de que lado quedo antes de responder.
	 *
	 * @return 1 si gano, 0 si empato y -1 si perdio
	 */
	public int getResultadoClub( )
	{
		if( local )
		{
			return getResultadoLocal( );
		}
		return -getResultadoLocal( );
	}

	public Nomina getNomina( )
	{
		return nomina;
	}

	public void setNomina( Nomina nomina )
	{
		this.nomina = nomina;
	}

	public String getInstitucionRival( )
	{
		return institucionRival;
	}

	public void setInstitucionRival( String institucionRival )
	{
		this.institucionRival = institucionRival;
	}

	public String getEscenario( )
	{
		return escenario;
	}

	public void setEscenario( String escenario )
	{
		this.escenario = escenario;
	}

	public int getJornada( )
	{
		return jornada;
	}

	public void setJornada( int jornada )
	{
		this.jornada = jornada;
	}

	public boolean isLocal( )
	{
		return local;
	}

	public void setLocal( boolean local )
	{
		this.local = local;
	}
}
