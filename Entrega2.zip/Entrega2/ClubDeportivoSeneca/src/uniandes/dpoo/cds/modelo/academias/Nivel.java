package uniandes.dpoo.cds.modelo.academias;

/**
 * NIVEL DE JUEGO
 *
 * Es el nivel que tiene un afiliado en una academia: Principiante, Intermedio o
 * Avanzado.
 *
 * nota: esto es un enum y tampoco lo vimos en clase. Un enum es una lista
 * cerrada de valores posibles, o sea solo existen esos tres y no se pueden
 * inventar mas. Por dentro funciona como una clase normal, lo que pasa es que
 * sus objetos ya vienen creados de una vez.
 *
 * Lo hicimos asi pues cada nivel lleva un numero de orden y entonces podemos
 * preguntar que tan lejos esta un nivel de otro, que es justo lo que pide la
 * regla de los partidos de practica. Si fuera un texto normal tocaria andar
 * comparando cadenas y un "principiante" con minuscula ya danaria todo.
 */
public enum Nivel
{
	PRINCIPIANTE( "Principiante", 1 ),
	INTERMEDIO( "Intermedio", 2 ),
	AVANZADO( "Avanzado", 3 );

	private String nombre;

	private int orden;

	private Nivel( String nombre, int orden )
	{
		this.nombre = nombre;
		this.orden = orden;
	}

	/**
	 * REVISAR SI DOS NIVELES SON COMPATIBLES
	 *
	 * Resta los ordenes y mira si la diferencia es maximo de uno, entonces
	 * Intermedio si puede contra Principiante y contra Avanzado, pero
	 * Principiante contra Avanzado no.
	 *
	 * @param otro el nivel con el que se compara
	 * @return true si la diferencia entre los dos niveles no supera un escalon
	 */
	public boolean esAdyacente( Nivel otro )
	{
		return Math.abs( orden - otro.orden ) <= 1;
	}

	/**
	 * BUSCAR UN NIVEL POR SU NOMBRE
	 *
	 * Sirve pues cuando leemos los archivos de datos, porque ahi el nivel viene
	 * escrito como texto y toca convertirlo al valor del enum.
	 *
	 * @param nombre el nombre del nivel
	 * @return el nivel correspondiente, o null si no existe
	 */
	public static Nivel porNombre( String nombre )
	{
		for( Nivel nivel : values( ) )
		{
			if( nivel.nombre.equalsIgnoreCase( nombre ) )
			{
				return nivel;
			}
		}
		return null;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public int getOrden( )
	{
		return orden;
	}

	@Override
	public String toString( )
	{
		return nombre;
	}
}
