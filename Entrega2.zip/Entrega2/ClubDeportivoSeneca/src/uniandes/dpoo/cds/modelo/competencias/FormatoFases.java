package uniandes.dpoo.cds.modelo.competencias;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import uniandes.dpoo.cds.modelo.deportes.PartidoCompetencia;
import uniandes.dpoo.cds.reglas.ReglasDeporte;

/**
 * FORMATO POR FASES
 *
 * Es el de ASCUN: primero una fase de grupos donde se suman puntos, y despues
 * eliminacion directa donde el que pierde se va para la casa.
 *
 * En la fase de grupos se porta igualito a una liga. En la eliminacion los
 * puntos ya no importan y lo unico que se guarda es si la nomina sigue viva o
 * ya quedo eliminada, entonces es como si fueran dos formatos en uno.
 */
public class FormatoFases implements FormatoCompetencia
{
	private static final long serialVersionUID = 1L;

	private int numeroGrupos;

	private int clasificadosPorGrupo;

	private String faseActual;

	public static final String FASE_GRUPOS = "Fase de grupos";

	public static final String FASE_ELIMINACION = "Eliminacion directa";

	public FormatoFases( int numeroGrupos, int clasificadosPorGrupo )
	{
		this.numeroGrupos = numeroGrupos;
		this.clasificadosPorGrupo = clasificadosPorGrupo;
		this.faseActual = FASE_GRUPOS;
	}

	@Override
	public String getNombre( )
	{
		return "Fase de grupos mas eliminacion directa";
	}

	/**
	 * REGISTRAR EL RESULTADO SEGUN LA FASE
	 *
	 * la parte del codigo que puede hacerlo estallar es: implementa la diferencia de comportamiento entre las dos
	 * fases de la competencia.
	 */
	@Override
	public void registrarResultado( PartidoCompetencia partido )
	{
		Nomina nomina = partido.getNomina( );
		int resultado = partido.getResultadoClub( );

		if( FASE_ELIMINACION.equals( faseActual ) )
		{
			if( resultado <= 0 )
			{
				nomina.setEliminada( true );
			}
			return;
		}

		ReglasDeporte reglas = partido.getReglas( );
		if( resultado > 0 )
		{
			nomina.registrarVictoria( reglas.getPuntosPorVictoria( ) );
		}
		else if( resultado == 0 && reglas.permiteEmpate( ) )
		{
			nomina.registrarEmpate( reglas.getPuntosPorEmpate( ) );
		}
		else
		{
			nomina.registrarDerrota( );
		}

		int aFavor = partido.getMarcadorLocal( );
		int enContra = partido.getMarcadorVisitante( );
		if( !partido.isLocal( ) )
		{
			aFavor = partido.getMarcadorVisitante( );
			enContra = partido.getMarcadorLocal( );
		}
		nomina.acumularAnotaciones( aFavor, enContra );
	}

	/**
	 * ORDENAR DEJANDO ADELANTE A LAS QUE SIGUEN VIVAS
	 *
	 * Primero van las que no han sido eliminadas y despues las otras, pues en un
	 * torneo de eliminacion seguir en carrera vale mas que los puntos.
	 */
	@Override
	public List<Nomina> calcularTabla( List<Nomina> nominas )
	{
		List<Nomina> tabla = new ArrayList<Nomina>( nominas );
		Collections.sort( tabla, new Comparator<Nomina>( )
		{
			@Override
			public int compare( Nomina una, Nomina otra )
			{
				if( una.isEliminada( ) != otra.isEliminada( ) )
				{
					if( una.isEliminada( ) )
					{
						return 1;
					}
					return -1;
				}
				if( una.getPuntos( ) != otra.getPuntos( ) )
				{
					return otra.getPuntos( ) - una.getPuntos( );
				}
				return otra.getDiferencia( ) - una.getDiferencia( );
			}
		} );
		return tabla;
	}

	public void avanzarAEliminacion( )
	{
		this.faseActual = FASE_ELIMINACION;
	}

	public String getFaseActual( )
	{
		return faseActual;
	}

	public void setFaseActual( String faseActual )
	{
		this.faseActual = faseActual;
	}

	public int getNumeroGrupos( )
	{
		return numeroGrupos;
	}

	public void setNumeroGrupos( int numeroGrupos )
	{
		this.numeroGrupos = numeroGrupos;
	}

	public int getClasificadosPorGrupo( )
	{
		return clasificadosPorGrupo;
	}

	public void setClasificadosPorGrupo( int clasificadosPorGrupo )
	{
		this.clasificadosPorGrupo = clasificadosPorGrupo;
	}
}
