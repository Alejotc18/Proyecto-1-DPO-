package uniandes.dpoo.cds.modelo.deportes;

import java.io.Serializable;
import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;

/**
 * SANCION
 *
 * Es el castigo que deja a un jugador por fuera de los proximos partidos de su
 * equipo.
 *
 * No se crea a mano sino que sale sola de las tarjetas que quedaron en la
 * EstadisticaFutbol. Lleva la cuenta de cuantos partidos le faltan por pagar,
 * entonces se va descontando a medida que el equipo juega y asi.
 */
public class Sancion implements Serializable
{
	private static final long serialVersionUID = 1L;

	private AfiliadoConjunto jugador;

	private Equipo equipo;

	private String motivo;

	private LocalDate fechaInicio;

	private int partidosPendientes;

	private boolean cumplida;

	public Sancion( AfiliadoConjunto jugador, Equipo equipo, String motivo, LocalDate fechaInicio, int partidosPendientes )
	{
		this.jugador = jugador;
		this.equipo = equipo;
		this.motivo = motivo;
		this.fechaInicio = fechaInicio;
		this.partidosPendientes = partidosPendientes;
		this.cumplida = false;
	}

	/**
	 * REVISAR SI LA SANCION TODAVIA PESA
	 *
	 * Mientras le queden partidos por pagar el jugador no puede ser alineado.
	 *
	 * @return true si quedan partidos por cumplir
	 */
	public boolean estaVigente( )
	{
		return !cumplida && partidosPendientes > 0;
	}

	/**
	 * DESCONTAR UN PARTIDO
	 *
	 * Se llama cuando el equipo del jugador acaba de jugar, entonces le baja uno
	 * a los partidos pendientes y cuando llega a cero la marca como cumplida.
	 */
	public void descontarPartido( )
	{
		if( partidosPendientes > 0 )
		{
			partidosPendientes = partidosPendientes - 1;
		}
		if( partidosPendientes == 0 )
		{
			cumplida = true;
		}
	}

	public AfiliadoConjunto getJugador( )
	{
		return jugador;
	}

	public void setJugador( AfiliadoConjunto jugador )
	{
		this.jugador = jugador;
	}

	public Equipo getEquipo( )
	{
		return equipo;
	}

	public void setEquipo( Equipo equipo )
	{
		this.equipo = equipo;
	}

	public String getMotivo( )
	{
		return motivo;
	}

	public void setMotivo( String motivo )
	{
		this.motivo = motivo;
	}

	public LocalDate getFechaInicio( )
	{
		return fechaInicio;
	}

	public void setFechaInicio( LocalDate fechaInicio )
	{
		this.fechaInicio = fechaInicio;
	}

	public int getPartidosPendientes( )
	{
		return partidosPendientes;
	}

	public void setPartidosPendientes( int partidosPendientes )
	{
		this.partidosPendientes = partidosPendientes;
	}

	public boolean isCumplida( )
	{
		return cumplida;
	}

	public void setCumplida( boolean cumplida )
	{
		this.cumplida = cumplida;
	}

	@Override
	public String toString( )
	{
		return motivo + " - " + partidosPendientes + " partido(s) pendiente(s) en " + equipo.getNombre( );
	}
}
