package uniandes.dpoo.cds.modelo.academias;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.reglas.ReglasDisciplina;

/**
 * INSTALACION, O SEA UNA CANCHA O UNA MESA
 *
 * Es el espacio donde se juegan los partidos de practica y se hacen los
 * entrenamientos: una cancha de tenis, una de padel o una mesa de ping pong.
 *
 * Ojo con el atributo techada, que no esta de adorno: es el que prende la regla
 * de que no se pueden entregar bebidas calientes adentro, entonces si uno lo
 * quita se cae esa validacion y asi.
 */
public class Instalacion implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private String nombre;

	private ReglasDisciplina reglas;

	private int capacidadMaxima;

	private boolean techada;

	private boolean disponible;

	private List<Reserva> reservas;

	public Instalacion( String codigo, String nombre, ReglasDisciplina reglas, int capacidadMaxima, boolean techada )
	{
		this.codigo = codigo;
		this.nombre = nombre;
		this.reglas = reglas;
		this.capacidadMaxima = capacidadMaxima;
		this.techada = techada;
		this.disponible = true;
		this.reservas = new ArrayList<Reserva>( );
	}

	/**
	 * REVISAR SI LA INSTALACION ESTA LIBRE
	 *
	 * La idea es sencilla: dos franjas se pisan si una arranca antes de que la
	 * otra termine, entonces con comparar las puntas de cada una ya basta y no
	 * hay que hacer nada raro.
	 *
	 * nota: aqui usamos LocalTime, que es de java.time y no lo vimos en clase.
	 * LocalTime guarda una hora del dia tipo 18:30, sin fecha ni nada mas, y trae
	 * isBefore() y isAfter() que son los que dicen cual hora va primero. Si las
	 * horas fueran numeros normales nos tocaria inventarnos si contamos minutos
	 * desde media noche o que, y pues se vuelve un enredo.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es la validacion central de la historia de usuario HU-03.
	 *
	 * @param fecha la fecha que se quiere reservar
	 * @param inicio la hora de inicio
	 * @param fin la hora de finalizacion
	 * @return true si no hay ninguna reserva confirmada que se cruce
	 */
	public boolean estaLibre( LocalDate fecha, LocalTime inicio, LocalTime fin )
	{
		if( !disponible )
		{
			return false;
		}
		for( Reserva reserva : reservas )
		{
			if( reserva.estaConfirmada( ) && reserva.getFecha( ).equals( fecha ) )
			{
				boolean seCruzan = inicio.isBefore( reserva.getHoraFin( ) ) && reserva.getHoraInicio( ).isBefore( fin );
				if( seCruzan )
				{
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * REVISAR SI ADMITE BEBIDAS CALIENTES
	 *
	 * Es una regla de seguridad del club: en las canchas de padel y en las mesas
	 * de ping pong techadas no se pueden meter bebidas calientes, pues alguien se
	 * puede quemar.
	 *
	 * @return true si la instalacion admite bebidas calientes
	 */
	public boolean admiteBebidaCaliente( )
	{
		return !techada;
	}

	public void agregarReserva( Reserva reserva )
	{
		reservas.add( reserva );
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public ReglasDisciplina getReglas( )
	{
		return reglas;
	}

	public void setReglas( ReglasDisciplina reglas )
	{
		this.reglas = reglas;
	}

	public int getCapacidadMaxima( )
	{
		return capacidadMaxima;
	}

	public void setCapacidadMaxima( int capacidadMaxima )
	{
		this.capacidadMaxima = capacidadMaxima;
	}

	public boolean isTechada( )
	{
		return techada;
	}

	public void setTechada( boolean techada )
	{
		this.techada = techada;
	}

	public boolean isDisponible( )
	{
		return disponible;
	}

	public void setDisponible( boolean disponible )
	{
		this.disponible = disponible;
	}

	public List<Reserva> getReservas( )
	{
		return reservas;
	}

	@Override
	public boolean equals( Object objeto )
	{
		if( this == objeto )
		{
			return true;
		}
		if( objeto == null || !( objeto instanceof Instalacion ) )
		{
			return false;
		}
		return codigo.equals( ( ( Instalacion ) objeto ).codigo );
	}

	@Override
	public int hashCode( )
	{
		return codigo.hashCode( );
	}

	@Override
	public String toString( )
	{
		return nombre + " (" + reglas.getNombre( ) + ", capacidad " + capacidadMaxima + ")";
	}
}
