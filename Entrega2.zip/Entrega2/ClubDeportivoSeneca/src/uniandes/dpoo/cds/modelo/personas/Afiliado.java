package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.deportes.Estadistica;

/**
 * AFILIADO, O SEA UN SOCIO DEL CLUB
 *
 * Es abstracta pues todo afiliado o juega un deporte de conjunto o practica una
 * disciplina individual, nadie es "afiliado" a secas. Aqui dejamos lo que los
 * dos tipos comparten: el codigo, si esta activo, los puntos de fidelidad y las
 * estadisticas.
 *
 * CORRECCION DE LA ENTREGA 1
 * La monitora nos dijo que las estadisticas no estaban conectadas con el
 * afiliado individual. Entonces las subimos aca al papa, porque los partidos de
 * practica de las academias tambien generan estadisticas y asi quedan cubiertos
 * los dos casos de una.
 */
public abstract class Afiliado extends Persona
{
	private static final long serialVersionUID = 1L;

	private String codigoAfiliado;

	private LocalDate fechaAfiliacion;

	private boolean activo;

	private int puntosFidelidad;

	private List<Estadistica> estadisticas;

	public Afiliado( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoAfiliado, LocalDate fechaAfiliacion )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password );
		this.codigoAfiliado = codigoAfiliado;
		this.fechaAfiliacion = fechaAfiliacion;
		this.activo = true;
		this.puntosFidelidad = 0;
		this.estadisticas = new ArrayList<Estadistica>( );
	}

	/**
	 * ACUMULAR PUNTOS DE FIDELIDAD
	 *
	 * La regla del club es que toda compra le devuelve al afiliado el 2% de lo
	 * que gasto en puntos, y un punto vale un peso entonces es facil de entender.
	 *
	 * @param valorVenta el valor total de la compra
	 * @return la cantidad de puntos que se acumularon
	 */
	public int acumularPuntos( double valorVenta )
	{
		int puntos = ( int ) Math.floor( valorVenta * PORCENTAJE_FIDELIDAD );
		puntosFidelidad = puntosFidelidad + puntos;
		return puntos;
	}

	/**
	 * GASTAR PUNTOS DE FIDELIDAD
	 *
	 * Primero revisa que si tenga suficientes, pues si no le alcanza no se le
	 * descuenta nada y devuelve false para avisar que no se pudo.
	 *
	 * @param puntos la cantidad de puntos que se quieren redimir
	 * @return true si el afiliado tenia saldo suficiente y los puntos se descontaron
	 */
	public boolean redimirPuntos( int puntos )
	{
		if( puntos <= 0 || puntos > puntosFidelidad )
		{
			return false;
		}
		puntosFidelidad = puntosFidelidad - puntos;
		return true;
	}

	/**
	 * GUARDAR UNA ESTADISTICA
	 *
	 * Cada vez que el afiliado juega un partido le queda una estadistica y
	 * entonces se la vamos metiendo a su historial.
	 *
	 * @param estadistica la estadistica que produjo el afiliado en un partido
	 */
	public void agregarEstadistica( Estadistica estadistica )
	{
		estadisticas.add( estadistica );
	}

	/**
	 * SUMAR EL VALOR PRINCIPAL DE TODAS LAS ESTADISTICAS
	 *
	 * Sirve pues para armar tablas tipo el goleador del torneo. Lo bueno es que
	 * cada estadistica ya sabe cual es su valor principal segun el deporte, o sea
	 * goles en futbol, puntos en baloncesto y asi, entonces este metodo funciona
	 * igual para un futbolista que para un tenista sin cambiarle nada.
	 *
	 * @return la suma de los valores principales
	 */
	public int getTotalValorPrincipal( )
	{
		int total = 0;
		for( Estadistica estadistica : estadisticas )
		{
			total = total + estadistica.getValorPrincipal( );
		}
		return total;
	}

	public static final double PORCENTAJE_FIDELIDAD = 0.02;

	public String getCodigoAfiliado( )
	{
		return codigoAfiliado;
	}

	public void setCodigoAfiliado( String codigoAfiliado )
	{
		this.codigoAfiliado = codigoAfiliado;
	}

	public LocalDate getFechaAfiliacion( )
	{
		return fechaAfiliacion;
	}

	public void setFechaAfiliacion( LocalDate fechaAfiliacion )
	{
		this.fechaAfiliacion = fechaAfiliacion;
	}

	public boolean isActivo( )
	{
		return activo;
	}

	public void setActivo( boolean activo )
	{
		this.activo = activo;
	}

	public int getPuntosFidelidad( )
	{
		return puntosFidelidad;
	}

	public void setPuntosFidelidad( int puntosFidelidad )
	{
		this.puntosFidelidad = puntosFidelidad;
	}

	public List<Estadistica> getEstadisticas( )
	{
		return estadisticas;
	}
}
