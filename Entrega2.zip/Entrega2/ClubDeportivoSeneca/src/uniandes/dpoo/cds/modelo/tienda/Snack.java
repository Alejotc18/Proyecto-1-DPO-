package uniandes.dpoo.cds.modelo.tienda;

import java.util.ArrayList;
import java.util.List;

/**
 * SNACK
 *
 * Es la comida empacada de la cafeteria.
 *
 * Todo snack tiene que declarar sus alergenos, y eso hay que mostrarselo al
 * afiliado ANTES de que confirme la compra, no despues.
 */
public class Snack extends ProductoCafeteria
{
	private static final long serialVersionUID = 1L;

	private int gramaje;

	private List<Alergeno> alergenos;

	public Snack( String codigo, String nombre, double precio, int cantidadDisponible, int gramaje )
	{
		super( codigo, nombre, precio, cantidadDisponible );
		this.gramaje = gramaje;
		this.alergenos = new ArrayList<Alergeno>( );
	}

	@Override
	public boolean puedeEntregarseEnInstalacionTechada( )
	{
		return true;
	}

	/**
	 * ARMAR EL AVISO DE ALERGENOS
	 *
	 * la parte del codigo que puede hacerlo estallar es: cumple la obligacion de informar los alergenos antes de la compra.
	 */
	@Override
	public String getAdvertencia( )
	{
		if( alergenos.isEmpty( ) )
		{
			return "Sin alergenos declarados";
		}
		StringBuilder texto = new StringBuilder( "Contiene: " );
		for( int i = 0; i < alergenos.size( ); i++ )
		{
			if( i > 0 )
			{
				texto.append( ", " );
			}
			texto.append( alergenos.get( i ).getNombre( ) );
		}
		return texto.toString( );
	}

	public void agregarAlergeno( Alergeno alergeno )
	{
		if( !alergenos.contains( alergeno ) )
		{
			alergenos.add( alergeno );
		}
	}

	public int getGramaje( )
	{
		return gramaje;
	}

	public void setGramaje( int gramaje )
	{
		this.gramaje = gramaje;
	}

	public List<Alergeno> getAlergenos( )
	{
		return alergenos;
	}
}
