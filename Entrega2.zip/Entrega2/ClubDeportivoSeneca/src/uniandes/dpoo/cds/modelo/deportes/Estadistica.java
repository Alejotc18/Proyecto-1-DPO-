package uniandes.dpoo.cds.modelo.deportes;

import java.io.Serializable;

import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * ESTADISTICA DE UN JUGADOR EN UN PARTIDO
 *
 * Es abstracta pues cada deporte mide cosas distintas: en futbol goles y
 * asistencias, en baloncesto puntos y rebotes, en raqueta sets y games. Lo unico
 * que todas tienen en comun es que son de un jugador y de un partido, entonces
 * eso es lo que va aca arriba.
 *
 * CORRECCION DE LA ENTREGA 1
 * La monitora nos dijo que estadistica no conectaba con el afiliado individual.
 * Entonces ahora apunta a Afiliado, que es el papa de los dos, y asi los
 * partidos de practica de las academias tambien quedan cubiertos.
 */
public abstract class Estadistica implements Serializable
{
	private static final long serialVersionUID = 1L;

	private Afiliado jugador;

	private Partido partido;

	private int minutosJugados;

	public Estadistica( Afiliado jugador, Partido partido )
	{
		this.jugador = jugador;
		this.partido = partido;
		this.minutosJugados = 0;
	}

	/**
	 * EL DATO MAS IMPORTANTE DEL DEPORTE
	 *
	 * En futbol son los goles, en baloncesto los puntos y en raqueta los sets
	 * ganados. Cada subclase responde lo suyo, entonces uno puede armar una tabla
	 * de clasificacion sin preguntar de que deporte es cada estadistica y asi.
	 *
	 * @return el valor principal de la estadistica
	 */
	public abstract int getValorPrincipal( );

	/**
	 * COMO SE LLAMA ESE DATO
	 *
	 * Pues es para los reportes, para poder escribir "Goles" o "Puntos" al lado
	 * del numero en vez de dejarlo suelto.
	 *
	 * @return el nombre de la medida principal, para mostrarla en los reportes
	 */
	public abstract String getNombreValorPrincipal( );

	/**
	 * RESUMEN EN TEXTO
	 *
	 * Arma una linea que se pueda leer con todo lo que hizo el jugador.
	 *
	 * @return una linea legible con el detalle de la actuacion del jugador
	 */
	public abstract String getResumen( );

	public Afiliado getJugador( )
	{
		return jugador;
	}

	public void setJugador( Afiliado jugador )
	{
		this.jugador = jugador;
	}

	public Partido getPartido( )
	{
		return partido;
	}

	public void setPartido( Partido partido )
	{
		this.partido = partido;
	}

	public int getMinutosJugados( )
	{
		return minutosJugados;
	}

	public void setMinutosJugados( int minutosJugados )
	{
		this.minutosJugados = minutosJugados;
	}

	@Override
	public String toString( )
	{
		return jugador.getNombreCompleto( ) + ": " + getResumen( );
	}
}
