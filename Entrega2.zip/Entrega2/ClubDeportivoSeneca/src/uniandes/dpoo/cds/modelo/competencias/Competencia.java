package uniandes.dpoo.cds.modelo.competencias;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.CategoriaInvalidaException;
import uniandes.dpoo.cds.excepciones.EquipoIncompletoException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.deportes.PartidoCompetencia;
import uniandes.dpoo.cds.reglas.ReglasDeporte;

/**
 * COMPETENCIA
 *
 * Es un torneo de afuera donde el club mete equipos, o sea el Torneo de los
 * Cerros o los Juegos ASCUN.
 *
 * Lo interesante es que la competencia NO sabe como se calcula su tabla de
 * posiciones: eso se lo pregunta a su FormatoCompetencia. Entonces si manana
 * aparece un torneo con otro sistema pues se escribe otro formato y esta clase
 * no se toca. Eso es el patron Strategy.
 */
public class Competencia implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private String nombre;

	private String entidadOrganizadora;

	private String temporada;

	private ReglasDeporte reglas;

	private Categoria categoriaHabilitada;

	private int nominaMinima;

	private FormatoCompetencia formato;

	private List<Nomina> nominas;

	private List<PartidoCompetencia> partidos;

	public Competencia( String codigo, String nombre, String entidadOrganizadora, String temporada, ReglasDeporte reglas, Categoria categoriaHabilitada, int nominaMinima, FormatoCompetencia formato )
	{
		this.codigo = codigo;
		this.nombre = nombre;
		this.entidadOrganizadora = entidadOrganizadora;
		this.temporada = temporada;
		this.reglas = reglas;
		this.categoriaHabilitada = categoriaHabilitada;
		this.nominaMinima = nominaMinima;
		this.formato = formato;
		this.nominas = new ArrayList<Nomina>( );
		this.partidos = new ArrayList<PartidoCompetencia>( );
	}

	/**
	 * INSCRIBIR UN EQUIPO EN LA COMPETENCIA
	 *
	 * Revisa las tres cosas que pide el torneo: que el equipo si juegue ese
	 * deporte, que sea de la categoria que el torneo acepta, y que junte la
	 * nomina minima de jugadores habilitados.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es la regla que demuestra el programa de prueba 9.
	 *
	 * @param equipo el equipo que se quiere inscribir
	 * @param fecha la fecha de la inscripcion
	 * @return la nomina creada
	 * @throws OperacionNoPermitidaException si el deporte no corresponde o el equipo ya esta inscrito
	 * @throws CategoriaInvalidaException si la categoria del equipo no esta habilitada
	 * @throws EquipoIncompletoException si no alcanza la nomina minima
	 */
	public Nomina inscribirEquipo( Equipo equipo, LocalDate fecha ) throws OperacionNoPermitidaException, CategoriaInvalidaException, EquipoIncompletoException
	{
		if( !equipo.getReglas( ).getNombre( ).equals( reglas.getNombre( ) ) )
		{
			throw new OperacionNoPermitidaException( "La competencia " + nombre + " es de " + reglas.getNombre( ) + " y el equipo " + equipo.getNombre( ) + " practica " + equipo.getReglas( ).getNombre( ) );
		}
		if( !equipo.getCategoria( ).equals( categoriaHabilitada ) )
		{
			throw new CategoriaInvalidaException( "La competencia " + nombre + " solo habilita la categoria " + categoriaHabilitada.getNombre( ) + " y el equipo es " + equipo.getCategoria( ).getNombre( ) );
		}
		if( buscarNomina( equipo ) != null )
		{
			throw new OperacionNoPermitidaException( "El equipo " + equipo.getNombre( ) + " ya esta inscrito en " + nombre );
		}
		int habilitados = equipo.getJugadoresHabilitados( ).size( );
		if( habilitados < nominaMinima )
		{
			throw new EquipoIncompletoException( "El equipo " + equipo.getNombre( ) + " tiene " + habilitados + " jugadores habilitados y la competencia exige una nomina minima de " + nominaMinima );
		}

		Nomina nomina = new Nomina( equipo, this, fecha );
		nomina.cargarJugadoresHabilitados( );
		nominas.add( nomina );
		return nomina;
	}

	/**
	 * REGISTRAR UN PARTIDO OFICIAL
	 *
	 * Guarda el partido y despues le pide al formato que actualice la tabla,
	 * pues es el formato el que sabe si eso suma puntos o si elimina a alguien.
	 *
	 * @param partido el partido que se jugo
	 */
	public void registrarPartido( PartidoCompetencia partido )
	{
		partidos.add( partido );
		if( partido.isJugado( ) )
		{
			formato.registrarResultado( partido );
		}
	}

	/**
	 * BUSCAR LA NOMINA DE UN EQUIPO
	 *
	 * Si el equipo no esta inscrito en este torneo entonces devuelve null.
	 *
	 * @param equipo el equipo que se esta buscando
	 * @return la nomina correspondiente, o null si el equipo no esta inscrito
	 */
	public Nomina buscarNomina( Equipo equipo )
	{
		for( Nomina nomina : nominas )
		{
			if( nomina.getEquipo( ).equals( equipo ) )
			{
				return nomina;
			}
		}
		return null;
	}

	/**
	 * LA TABLA DE POSICIONES
	 *
	 * Tampoco la arma ella, se la pide al formato y asi.
	 *
	 * @return las nominas ordenadas segun el formato de la competencia
	 */
	public List<Nomina> getTablaPosiciones( )
	{
		return formato.calcularTabla( nominas );
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public String getEntidadOrganizadora( )
	{
		return entidadOrganizadora;
	}

	public void setEntidadOrganizadora( String entidadOrganizadora )
	{
		this.entidadOrganizadora = entidadOrganizadora;
	}

	public String getTemporada( )
	{
		return temporada;
	}

	public void setTemporada( String temporada )
	{
		this.temporada = temporada;
	}

	public ReglasDeporte getReglas( )
	{
		return reglas;
	}

	public void setReglas( ReglasDeporte reglas )
	{
		this.reglas = reglas;
	}

	public Categoria getCategoriaHabilitada( )
	{
		return categoriaHabilitada;
	}

	public void setCategoriaHabilitada( Categoria categoriaHabilitada )
	{
		this.categoriaHabilitada = categoriaHabilitada;
	}

	public int getNominaMinima( )
	{
		return nominaMinima;
	}

	public void setNominaMinima( int nominaMinima )
	{
		this.nominaMinima = nominaMinima;
	}

	public FormatoCompetencia getFormato( )
	{
		return formato;
	}

	public void setFormato( FormatoCompetencia formato )
	{
		this.formato = formato;
	}

	public List<Nomina> getNominas( )
	{
		return nominas;
	}

	public List<PartidoCompetencia> getPartidos( )
	{
		return partidos;
	}

	@Override
	public String toString( )
	{
		return nombre + " " + temporada + " (" + entidadOrganizadora + ", " + reglas.getNombre( ) + " " + categoriaHabilitada.getNombre( ) + ")";
	}
}
