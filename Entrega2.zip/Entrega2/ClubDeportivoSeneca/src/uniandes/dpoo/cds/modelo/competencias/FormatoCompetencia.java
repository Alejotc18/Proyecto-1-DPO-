package uniandes.dpoo.cds.modelo.competencias;

import java.io.Serializable;
import java.util.List;

import uniandes.dpoo.cds.modelo.deportes.PartidoCompetencia;

/**
 * FORMATO DE LA COMPETENCIA, PATRON STRATEGY
 *
 * Esta interfaz dice como se calcula la clasificacion de un torneo.
 *
 * El club juega en dos circuitos que en el fondo son lo mismo, o sea equipos,
 * partidos y una tabla, pero que se resuelven distinto: el Torneo de los Cerros
 * es una liga de todos contra todos y ASCUN es fase de grupos y despues
 * eliminacion directa.
 *
 * Entonces en vez de meterle un if a Competencia preguntando de que tipo es,
 * cada formato es una clase aparte y la competencia le pregunta a la suya. Pues
 * si manana sale un tercer torneo con otro sistema solo se escribe otra clase y
 * a Competencia no hay que tocarla.
 */
public interface FormatoCompetencia extends Serializable
{
	/**
	 * COMO SE LLAMA EL FORMATO
	 *
	 * @return el nombre del formato
	 */
	public String getNombre( );

	/**
	 * ACTUALIZAR LA TABLA CON UN PARTIDO
	 *
	 * Cada formato lo hace a su manera, entonces la liga suma puntos y el de
	 * fases a veces suma y a veces elimina.
	 *
	 * @param partido el partido que acaba de jugarse
	 */
	public void registrarResultado( PartidoCompetencia partido );

	/**
	 * ARMAR LA TABLA DE POSICIONES
	 *
	 * @param nominas las nominas inscritas en la competencia
	 * @return las nominas ordenadas de mejor a peor posicion
	 */
	public List<Nomina> calcularTabla( List<Nomina> nominas );
}
