package uniandes.dpoo.cds.modelo.deportes;

import java.time.LocalDate;
import java.time.LocalTime;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.EquipoIncompletoException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.reglas.ReglasDeporte;

/**
 * PARTIDO INTERNO
 *
 * Es cuando dos equipos del mismo club juegan entre ellos, o sea para practicar
 * y para que los entrenadores vean como va la gente.
 */
public class PartidoInterno extends Partido
{
	private static final long serialVersionUID = 1L;

	private Equipo equipoLocal;

	private Equipo equipoVisitante;

	private String observaciones;

	public PartidoInterno( String codigo, LocalDate fecha, LocalTime hora, Equipo equipoLocal, Equipo equipoVisitante )
	{
		super( codigo, fecha, hora );
		this.equipoLocal = equipoLocal;
		this.equipoVisitante = equipoVisitante;
		this.observaciones = "";
	}

	/**
	 * REVISAR SI EL PARTIDO SE PUEDE JUGAR
	 *
	 * Pide tres cosas: que los dos equipos sean del mismo deporte, que sean de la
	 * misma categoria, y que los dos junten el minimo de jugadores habilitados.
	 * Pues no tiene sentido un partido de Mayores contra Infantil y asi.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es la regla que demuestra el programa de prueba 3.
	 */
	@Override
	public void validarPuedeJugarse( ) throws ClubException
	{
		if( !equipoLocal.getReglas( ).getNombre( ).equals( equipoVisitante.getReglas( ).getNombre( ) ) )
		{
			throw new OperacionNoPermitidaException( "Los dos equipos deben ser del mismo deporte" );
		}
		if( !equipoLocal.getCategoria( ).equals( equipoVisitante.getCategoria( ) ) )
		{
			throw new OperacionNoPermitidaException( "Los dos equipos deben ser de la misma categoria" );
		}
		ReglasDeporte reglas = equipoLocal.getReglas( );
		if( !equipoLocal.puedeDisputarPartido( ) )
		{
			throw new EquipoIncompletoException( "El equipo " + equipoLocal.getNombre( ) + " presenta " + equipoLocal.getJugadoresHabilitados( ).size( ) + " jugadores habilitados y " + reglas.getNombre( ) + " exige " + reglas.getMinimoJugadores( ) );
		}
		if( !equipoVisitante.puedeDisputarPartido( ) )
		{
			throw new EquipoIncompletoException( "El equipo " + equipoVisitante.getNombre( ) + " presenta " + equipoVisitante.getJugadoresHabilitados( ).size( ) + " jugadores habilitados y " + reglas.getNombre( ) + " exige " + reglas.getMinimoJugadores( ) );
		}
	}

	@Override
	public String getDescripcionRivales( )
	{
		return equipoLocal.getNombre( ) + " vs " + equipoVisitante.getNombre( );
	}

	/**
	 * LAS REGLAS DEL DEPORTE
	 *
	 * Se las pide al equipo local, entonces no hay que guardar el deporte otra
	 * vez aqui adentro.
	 *
	 * @return las reglas del deporte que se esta jugando
	 */
	public ReglasDeporte getReglas( )
	{
		return equipoLocal.getReglas( );
	}

	public Equipo getEquipoLocal( )
	{
		return equipoLocal;
	}

	public void setEquipoLocal( Equipo equipoLocal )
	{
		this.equipoLocal = equipoLocal;
	}

	public Equipo getEquipoVisitante( )
	{
		return equipoVisitante;
	}

	public void setEquipoVisitante( Equipo equipoVisitante )
	{
		this.equipoVisitante = equipoVisitante;
	}

	public String getObservaciones( )
	{
		return observaciones;
	}

	public void setObservaciones( String observaciones )
	{
		this.observaciones = observaciones;
	}
}
