package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;

/**
 * FISIOTERAPEUTA
 *
 * Es el empleado que atiende a los afiliados, y entra en los turnos igual que el
 * entrenador. Esta separado pues el club pide minimo un fisioterapeuta en el
 * horario de atencion y eso hay que poderlo contar aparte.
 */
public class Fisioterapeuta extends Empleado
{
	private static final long serialVersionUID = 1L;

	private String tarjetaProfesional;

	public Fisioterapeuta( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoEmpleado, LocalDate fechaContratacion, String tarjetaProfesional )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password, codigoEmpleado, fechaContratacion );
		this.tarjetaProfesional = tarjetaProfesional;
	}

	public String getTarjetaProfesional( )
	{
		return tarjetaProfesional;
	}

	public void setTarjetaProfesional( String tarjetaProfesional )
	{
		this.tarjetaProfesional = tarjetaProfesional;
	}

	@Override
	public String getRol( )
	{
		return "Fisioterapeuta";
	}
}
