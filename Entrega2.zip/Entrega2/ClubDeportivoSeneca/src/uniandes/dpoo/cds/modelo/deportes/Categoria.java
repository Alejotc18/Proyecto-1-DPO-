package uniandes.dpoo.cds.modelo.deportes;

/**
 * CATEGORIA POR EDAD
 *
 * Es la franja de edad que le permite a un jugador estar en un equipo.
 *
 * nota: esto es un enum y no lo vimos en clase. Un enum es una lista cerrada de
 * valores, o sea el club tiene exactamente estas cuatro categorias y no hay mas.
 * Por dentro es como una clase normal pero con sus objetos ya creados.
 *
 * Lo usamos pues cada categoria carga su propio rango de edad y sabe responder
 * si una edad le sirve o no. Si fuera texto entonces tocaria repetir los rangos
 * en cada validacion, y ademas alguien escribe "juvenil" en minuscula y ya se
 * dano todo sin que nadie se de cuenta.
 */
public enum Categoria
{
	SUB_13( "Sub-13", 0, 13 ),
	SUB_15( "Sub-15", 14, 15 ),
	SUB_17( "Sub-17", 16, 17 ),
	MAYORES( "Mayores", 18, 120 );

	private String nombre;

	private int edadMinima;

	private int edadMaxima;

	private Categoria( String nombre, int edadMinima, int edadMaxima )
	{
		this.nombre = nombre;
		this.edadMinima = edadMinima;
		this.edadMaxima = edadMaxima;
	}

	/**
	 * REVISAR SI UNA EDAD CABE EN LA CATEGORIA
	 *
	 * Cada categoria ya sabe entre que edades va, entonces solo mira si la edad
	 * del jugador queda adentro y responde.
	 *
	 * @param edad la edad del jugador
	 * @return true si la edad corresponde a la categoria
	 */
	public boolean admiteEdad( int edad )
	{
		return edad >= edadMinima && edad <= edadMaxima;
	}

	/**
	 * BUSCAR UNA CATEGORIA POR SU NOMBRE
	 *
	 * Sirve para cuando leemos los archivos, pues ahi la categoria viene escrita
	 * como texto y toca pasarla al valor del enum.
	 *
	 * @param nombre el nombre de la categoria
	 * @return la categoria correspondiente, o null si no existe
	 */
	public static Categoria porNombre( String nombre )
	{
		for( Categoria categoria : values( ) )
		{
			if( categoria.nombre.equalsIgnoreCase( nombre ) )
			{
				return categoria;
			}
		}
		return null;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public int getEdadMinima( )
	{
		return edadMinima;
	}

	public int getEdadMaxima( )
	{
		return edadMaxima;
	}

	@Override
	public String toString( )
	{
		return nombre;
	}
}
