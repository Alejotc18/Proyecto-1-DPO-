package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.entrenamiento.SesionEntrenamiento;

/**
 * ENTRENADOR
 *
 * Es el empleado que arma las sesiones de entrenamiento, convoca jugadores y
 * les toma asistencia.
 *
 * Tambien puede jugar partidos de practica contra cualquier afiliado individual
 * sin importar el nivel, pues entra como comodin y entonces a el no se le aplica
 * la regla de los niveles seguidos.
 */
public class Entrenador extends Empleado
{
	private static final long serialVersionUID = 1L;

	private String especialidad;

	private int aniosExperiencia;

	private List<SesionEntrenamiento> sesiones;

	public Entrenador( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoEmpleado, LocalDate fechaContratacion, String especialidad, int aniosExperiencia )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password, codigoEmpleado, fechaContratacion );
		this.especialidad = especialidad;
		this.aniosExperiencia = aniosExperiencia;
		this.sesiones = new ArrayList<SesionEntrenamiento>( );
	}

	public void agregarSesion( SesionEntrenamiento sesion )
	{
		sesiones.add( sesion );
	}

	public List<SesionEntrenamiento> getSesiones( )
	{
		return sesiones;
	}

	public String getEspecialidad( )
	{
		return especialidad;
	}

	public void setEspecialidad( String especialidad )
	{
		this.especialidad = especialidad;
	}

	public int getAniosExperiencia( )
	{
		return aniosExperiencia;
	}

	public void setAniosExperiencia( int aniosExperiencia )
	{
		this.aniosExperiencia = aniosExperiencia;
	}

	@Override
	public String getRol( )
	{
		return "Entrenador";
	}
}
