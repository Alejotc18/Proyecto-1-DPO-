package uniandes.dpoo.cds.modelo.competencias;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;

/**
 * NOMINA
 *
 * Es la inscripcion de un equipo del club en un torneo.
 *
 * Existe como clase aparte pues los puntos, los partidos ganados y la lista de
 * jugadores no son del equipo ni del torneo por separado: el mismo equipo puede
 * estar en dos torneos y irle bien en uno y mal en el otro, entonces esos datos
 * van en la union de los dos y asi. Es otra clase asociacion.
 *
 * Y ojo, solo la gente que esta en esta lista puede jugar los partidos
 * oficiales de ese torneo, ni siquiera todo el equipo.
 */
public class Nomina implements Serializable
{
	private static final long serialVersionUID = 1L;

	private Equipo equipo;

	private Competencia competencia;

	private LocalDate fechaInscripcion;

	private List<AfiliadoConjunto> jugadores;

	private int puntos;

	private int jugados;

	private int ganados;

	private int empatados;

	private int perdidos;

	private int anotacionesAFavor;

	private int anotacionesEnContra;

	private boolean eliminada;

	public Nomina( Equipo equipo, Competencia competencia, LocalDate fechaInscripcion )
	{
		this.equipo = equipo;
		this.competencia = competencia;
		this.fechaInscripcion = fechaInscripcion;
		this.jugadores = new ArrayList<AfiliadoConjunto>( );
		this.puntos = 0;
		this.jugados = 0;
		this.ganados = 0;
		this.empatados = 0;
		this.perdidos = 0;
		this.anotacionesAFavor = 0;
		this.anotacionesEnContra = 0;
		this.eliminada = false;
	}

	/**
	 * COPIAR LOS JUGADORES DEL EQUIPO
	 *
	 * Se copian los que estaban habilitados el dia de la inscripcion, entonces es
	 * una foto de ese momento. Pues si despues alguien se retira del club la
	 * nomina igual queda con el registro de quien estaba inscrito y asi.
	 */
	public void cargarJugadoresHabilitados( )
	{
		jugadores.clear( );
		jugadores.addAll( equipo.getJugadoresHabilitados( ) );
	}

	/**
	 * REVISAR SI UN JUGADOR PUEDE SER ALINEADO
	 *
	 * Tiene que cumplir las dos cosas: estar en esta nomina y no deber ninguna
	 * sancion. Con una sola no basta.
	 *
	 * @param jugador el jugador que se quiere alinear
	 * @return true si el jugador puede jugar
	 */
	public boolean puedeAlinear( AfiliadoConjunto jugador )
	{
		return jugadores.contains( jugador ) && jugador.estaHabilitado( equipo );
	}

	/**
	 * CUANTOS JUGADORES ESTAN DISPONIBLES HOY
	 *
	 * Es la cuenta de ahorita, pues alguien que estaba bien la semana pasada
	 * puede estar sancionado hoy.
	 *
	 * @return la cantidad de jugadores de la nomina que estan habilitados hoy
	 */
	public int contarJugadoresHabilitados( )
	{
		int total = 0;
		for( AfiliadoConjunto jugador : jugadores )
		{
			if( jugador.estaHabilitado( equipo ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	public void registrarVictoria( int puntosPorVictoria )
	{
		puntos = puntos + puntosPorVictoria;
		jugados = jugados + 1;
		ganados = ganados + 1;
	}

	public void registrarEmpate( int puntosPorEmpate )
	{
		puntos = puntos + puntosPorEmpate;
		jugados = jugados + 1;
		empatados = empatados + 1;
	}

	public void registrarDerrota( )
	{
		jugados = jugados + 1;
		perdidos = perdidos + 1;
	}

	public void acumularAnotaciones( int aFavor, int enContra )
	{
		anotacionesAFavor = anotacionesAFavor + aFavor;
		anotacionesEnContra = anotacionesEnContra + enContra;
	}

	/**
	 * DIFERENCIA DE ANOTACIONES
	 *
	 * Sirve para desempatar en la tabla cuando dos equipos quedan con los mismos
	 * puntos.
	 *
	 * @return la diferencia entre anotaciones a favor y en contra
	 */
	public int getDiferencia( )
	{
		return anotacionesAFavor - anotacionesEnContra;
	}

	public void agregarJugador( AfiliadoConjunto jugador )
	{
		if( !jugadores.contains( jugador ) )
		{
			jugadores.add( jugador );
		}
	}

	public Equipo getEquipo( )
	{
		return equipo;
	}

	public void setEquipo( Equipo equipo )
	{
		this.equipo = equipo;
	}

	public Competencia getCompetencia( )
	{
		return competencia;
	}

	public void setCompetencia( Competencia competencia )
	{
		this.competencia = competencia;
	}

	public LocalDate getFechaInscripcion( )
	{
		return fechaInscripcion;
	}

	public void setFechaInscripcion( LocalDate fechaInscripcion )
	{
		this.fechaInscripcion = fechaInscripcion;
	}

	public List<AfiliadoConjunto> getJugadores( )
	{
		return jugadores;
	}

	public int getPuntos( )
	{
		return puntos;
	}

	public void setPuntos( int puntos )
	{
		this.puntos = puntos;
	}

	public int getJugados( )
	{
		return jugados;
	}

	public void setJugados( int jugados )
	{
		this.jugados = jugados;
	}

	public int getGanados( )
	{
		return ganados;
	}

	public void setGanados( int ganados )
	{
		this.ganados = ganados;
	}

	public int getEmpatados( )
	{
		return empatados;
	}

	public void setEmpatados( int empatados )
	{
		this.empatados = empatados;
	}

	public int getPerdidos( )
	{
		return perdidos;
	}

	public void setPerdidos( int perdidos )
	{
		this.perdidos = perdidos;
	}

	public int getAnotacionesAFavor( )
	{
		return anotacionesAFavor;
	}

	public void setAnotacionesAFavor( int anotacionesAFavor )
	{
		this.anotacionesAFavor = anotacionesAFavor;
	}

	public int getAnotacionesEnContra( )
	{
		return anotacionesEnContra;
	}

	public void setAnotacionesEnContra( int anotacionesEnContra )
	{
		this.anotacionesEnContra = anotacionesEnContra;
	}

	public boolean isEliminada( )
	{
		return eliminada;
	}

	public void setEliminada( boolean eliminada )
	{
		this.eliminada = eliminada;
	}

	@Override
	public String toString( )
	{
		return equipo.getNombre( ) + " | PJ " + jugados + " | G " + ganados + " | E " + empatados + " | P " + perdidos + " | Dif " + getDiferencia( ) + " | Pts " + puntos;
	}
}
