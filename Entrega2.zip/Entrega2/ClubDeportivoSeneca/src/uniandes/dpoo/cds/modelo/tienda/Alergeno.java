package uniandes.dpoo.cds.modelo.tienda;

import java.io.Serializable;

/**
 * ALERGENO
 *
 * Es una sustancia que le puede hacer dano a alguien alergico, tipo mani, leche
 * o gluten. Hay que avisarle al afiliado antes de que compre el snack y asi.
 */
public class Alergeno implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String nombre;

	private String descripcion;

	public Alergeno( String nombre, String descripcion )
	{
		this.nombre = nombre;
		this.descripcion = descripcion;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public String getDescripcion( )
	{
		return descripcion;
	}

	public void setDescripcion( String descripcion )
	{
		this.descripcion = descripcion;
	}

	@Override
	public boolean equals( Object objeto )
	{
		if( this == objeto )
		{
			return true;
		}
		if( objeto == null || !( objeto instanceof Alergeno ) )
		{
			return false;
		}
		return nombre.equalsIgnoreCase( ( ( Alergeno ) objeto ).nombre );
	}

	@Override
	public int hashCode( )
	{
		return nombre.toLowerCase( ).hashCode( );
	}

	@Override
	public String toString( )
	{
		return nombre;
	}
}
