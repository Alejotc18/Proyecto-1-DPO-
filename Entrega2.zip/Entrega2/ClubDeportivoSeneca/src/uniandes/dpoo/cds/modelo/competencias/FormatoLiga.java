package uniandes.dpoo.cds.modelo.competencias;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import uniandes.dpoo.cds.modelo.deportes.PartidoCompetencia;
import uniandes.dpoo.cds.reglas.ReglasDeporte;

/**
 * FORMATO DE LIGA
 *
 * Es el de todos contra todos, como el Torneo de los Cerros.
 *
 * Cada resultado da puntos pero el cuanto depende del deporte: en futbol ganar
 * vale tres y empatar vale uno, mientras que en baloncesto y voleibol ni
 * siquiera existe el empate. Entonces esta clase no se inventa los numeros sino
 * que se los pregunta a las reglas del deporte y asi.
 */
public class FormatoLiga implements FormatoCompetencia
{
	private static final long serialVersionUID = 1L;

	private int numeroVueltas;

	public FormatoLiga( int numeroVueltas )
	{
		this.numeroVueltas = numeroVueltas;
	}

	@Override
	public String getNombre( )
	{
		return "Liga de todos contra todos";
	}

	/**
	 * SUMAR LOS PUNTOS DEL PARTIDO
	 *
	 * la parte del codigo que puede hacerlo estallar es: aqui se aplica la puntuacion que depende del deporte.
	 */
	@Override
	public void registrarResultado( PartidoCompetencia partido )
	{
		Nomina nomina = partido.getNomina( );
		ReglasDeporte reglas = partido.getReglas( );
		int resultado = partido.getResultadoClub( );

		if( resultado > 0 )
		{
			nomina.registrarVictoria( reglas.getPuntosPorVictoria( ) );
		}
		else if( resultado == 0 && reglas.permiteEmpate( ) )
		{
			nomina.registrarEmpate( reglas.getPuntosPorEmpate( ) );
		}
		else
		{
			nomina.registrarDerrota( );
		}

		int aFavor = partido.getMarcadorLocal( );
		int enContra = partido.getMarcadorVisitante( );
		if( !partido.isLocal( ) )
		{
			aFavor = partido.getMarcadorVisitante( );
			enContra = partido.getMarcadorLocal( );
		}
		nomina.acumularAnotaciones( aFavor, enContra );
	}

	/**
	 * ORDENAR LA TABLA DE POSICIONES
	 *
	 * Primero por puntos. Si dos quedan empatados entonces desempata por
	 * diferencia de anotaciones, y si tambien empatan ahi pues por anotaciones a
	 * favor, que es como se hace en las ligas de verdad.
	 */
	@Override
	public List<Nomina> calcularTabla( List<Nomina> nominas )
	{
		List<Nomina> tabla = new ArrayList<Nomina>( nominas );
		Collections.sort( tabla, new Comparator<Nomina>( )
		{
			@Override
			public int compare( Nomina una, Nomina otra )
			{
				if( una.getPuntos( ) != otra.getPuntos( ) )
				{
					return otra.getPuntos( ) - una.getPuntos( );
				}
				if( una.getDiferencia( ) != otra.getDiferencia( ) )
				{
					return otra.getDiferencia( ) - una.getDiferencia( );
				}
				return otra.getAnotacionesAFavor( ) - una.getAnotacionesAFavor( );
			}
		} );
		return tabla;
	}

	public int getNumeroVueltas( )
	{
		return numeroVueltas;
	}

	public void setNumeroVueltas( int numeroVueltas )
	{
		this.numeroVueltas = numeroVueltas;
	}
}
