package uniandes.dpoo.cds.modelo.entrenamiento;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.personas.Empleado;

/**
 * TURNO
 *
 * Es el bloque de horas en que un empleado esta disponible dentro del horario
 * de atencion del club.
 *
 * CORRECCION DE LA ENTREGA 1
 * Antes un turno podia tener maximo una solicitud de cambio. Pero pues si a uno
 * le rechazan la solicitud entonces deberia poder volver a pedir, asi que lo
 * pasamos a muchas. La regla de que solo puede haber UNA pendiente al tiempo la
 * revisa el metodo tieneSolicitudPendiente, o sea la cuidamos con codigo y no
 * apretando la cardinalidad.
 */
public class Turno implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private Empleado empleado;

	private String diaSemana;

	private String semana;

	private LocalTime horaInicio;

	private LocalTime horaFin;

	private boolean vigente;

	private List<SolicitudCambioTurno> solicitudes;

	public Turno( String codigo, Empleado empleado, String diaSemana, String semana, LocalTime horaInicio, LocalTime horaFin )
	{
		this.codigo = codigo;
		this.empleado = empleado;
		this.diaSemana = diaSemana;
		this.semana = semana;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
		this.vigente = true;
		this.solicitudes = new ArrayList<SolicitudCambioTurno>( );
	}

	/**
	 * REVISAR SI HAY UNA SOLICITUD SIN RESPONDER
	 *
	 * @return true si existe una solicitud pendiente
	 */
	public boolean tieneSolicitudPendiente( )
	{
		for( SolicitudCambioTurno solicitud : solicitudes )
		{
			if( solicitud.estaPendiente( ) )
			{
				return true;
			}
		}
		return false;
	}

	public void agregarSolicitud( SolicitudCambioTurno solicitud )
	{
		solicitudes.add( solicitud );
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public Empleado getEmpleado( )
	{
		return empleado;
	}

	public void setEmpleado( Empleado empleado )
	{
		this.empleado = empleado;
	}

	public String getDiaSemana( )
	{
		return diaSemana;
	}

	public void setDiaSemana( String diaSemana )
	{
		this.diaSemana = diaSemana;
	}

	public String getSemana( )
	{
		return semana;
	}

	public void setSemana( String semana )
	{
		this.semana = semana;
	}

	public LocalTime getHoraInicio( )
	{
		return horaInicio;
	}

	public void setHoraInicio( LocalTime horaInicio )
	{
		this.horaInicio = horaInicio;
	}

	public LocalTime getHoraFin( )
	{
		return horaFin;
	}

	public void setHoraFin( LocalTime horaFin )
	{
		this.horaFin = horaFin;
	}

	public boolean isVigente( )
	{
		return vigente;
	}

	public void setVigente( boolean vigente )
	{
		this.vigente = vigente;
	}

	public List<SolicitudCambioTurno> getSolicitudes( )
	{
		return solicitudes;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + empleado.getNombreCompleto( ) + " | " + diaSemana + " " + semana + " | " + horaInicio + "-" + horaFin;
	}
}
