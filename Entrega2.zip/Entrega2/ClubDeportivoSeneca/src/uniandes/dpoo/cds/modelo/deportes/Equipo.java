package uniandes.dpoo.cds.modelo.deportes;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.CategoriaInvalidaException;
import uniandes.dpoo.cds.excepciones.CupoLlenoException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;
import uniandes.dpoo.cds.reglas.ReglasDeporte;

/**
 * EQUIPO DE UN DEPORTE DE CONJUNTO
 *
 * Es un equipo del club, o sea Leones FC, Titanes BC y asi.
 *
 * CORRECCION DE LA ENTREGA 1
 * Antes el deporte era un texto guardado aca adentro y al mismo tiempo mandaba
 * en como se comportaba el equipo, que es lo que la monitora nos marco como
 * atributo y relacion a la vez. Entonces ahora el equipo apunta a su objeto de
 * reglas y cuando necesita saber algo del deporte pues le pregunta, en vez de
 * tener el dato repetido en dos lados.
 */
public class Equipo implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private String nombre;

	private ReglasDeporte reglas;

	private Categoria categoria;

	private int cupoMaximo;

	private boolean activo;

	private List<InscripcionEquipo> inscripciones;

	public Equipo( String codigo, String nombre, ReglasDeporte reglas, Categoria categoria, int cupoMaximo )
	{
		this.codigo = codigo;
		this.nombre = nombre;
		this.reglas = reglas;
		this.categoria = categoria;
		this.cupoMaximo = cupoMaximo;
		this.activo = true;
		this.inscripciones = new ArrayList<InscripcionEquipo>( );
	}

	/**
	 * INSCRIBIR UN JUGADOR
	 *
	 * Antes de aceptarlo revisa las cuatro reglas del club: que la edad le de
	 * para la categoria, que quede cupo, que esa camiseta no la tenga otro, y que
	 * el jugador no este ya en otro equipo del mismo deporte.
	 *
	 * Las cuatro estan aqui juntas a proposito, pues si cada programa que
	 * inscribe jugadores tuviera que acordarse de revisarlas por su cuenta
	 * entonces alguna se le olvida y asi se cuelan datos malos.
	 *
	 * la parte del codigo que puede hacerlo estallar es: valida los requerimientos RF07 y las reglas de inscripcion.
	 *
	 * @param jugador el afiliado que se quiere inscribir
	 * @param numeroCamiseta el numero de camiseta solicitado
	 * @param posicion la posicion que jugara dentro del equipo
	 * @param fecha la fecha de la inscripcion
	 * @return la inscripcion creada
	 * @throws CategoriaInvalidaException si la edad no corresponde a la categoria
	 * @throws CupoLlenoException si el equipo ya esta lleno
	 * @throws OperacionNoPermitidaException si la camiseta esta ocupada o el jugador ya juega el deporte
	 */
	public InscripcionEquipo inscribirJugador( AfiliadoConjunto jugador, int numeroCamiseta, String posicion, LocalDate fecha ) throws CategoriaInvalidaException, CupoLlenoException, OperacionNoPermitidaException
	{
		if( !categoria.admiteEdad( jugador.getEdad( ) ) )
		{
			throw new CategoriaInvalidaException( "El jugador " + jugador.getNombreCompleto( ) + " tiene " + jugador.getEdad( ) + " anos y no corresponde a la categoria " + categoria.getNombre( ) );
		}
		if( getNumeroInscritos( ) >= cupoMaximo )
		{
			throw new CupoLlenoException( "El equipo " + nombre + " ya alcanzo su cupo maximo de " + cupoMaximo + " jugadores" );
		}
		if( estaCamisetaOcupada( numeroCamiseta ) )
		{
			throw new OperacionNoPermitidaException( "La camiseta numero " + numeroCamiseta + " ya esta ocupada en el equipo " + nombre );
		}
		if( jugador.yaJuegaDeporte( reglas.getNombre( ) ) )
		{
			throw new OperacionNoPermitidaException( "El jugador " + jugador.getNombreCompleto( ) + " ya pertenece a otro equipo de " + reglas.getNombre( ) );
		}

		InscripcionEquipo inscripcion = new InscripcionEquipo( jugador, this, numeroCamiseta, posicion, fecha );
		inscripciones.add( inscripcion );
		jugador.agregarInscripcion( inscripcion );
		return inscripcion;
	}

	/**
	 * JUGADORES QUE PUEDEN JUGAR AHORITA
	 *
	 * Deja por fuera a los que tienen una sancion sin pagar y a los que ya no
	 * estan activos en el club, entonces lo que queda es la gente que si puede
	 * salir a la cancha.
	 *
	 * @return la lista de jugadores habilitados
	 */
	public List<AfiliadoConjunto> getJugadoresHabilitados( )
	{
		List<AfiliadoConjunto> habilitados = new ArrayList<AfiliadoConjunto>( );
		for( InscripcionEquipo inscripcion : inscripciones )
		{
			if( inscripcion.isActiva( ) )
			{
				AfiliadoConjunto jugador = inscripcion.getJugador( );
				if( jugador.estaHabilitado( this ) )
				{
					habilitados.add( jugador );
				}
			}
		}
		return habilitados;
	}

	/**
	 * REVISAR SI EL EQUIPO PUEDE JUGAR
	 *
	 * Cuenta los jugadores habilitados y le pregunta a las reglas del deporte
	 * cuantos pide como minimo, pues no es el mismo numero en futbol que en
	 * voleibol y asi.
	 *
	 * la parte del codigo que puede hacerlo estallar es: de este metodo depende que un partido pueda disputarse.
	 *
	 * @return true si el equipo puede presentarse a jugar
	 */
	public boolean puedeDisputarPartido( )
	{
		return activo && getJugadoresHabilitados( ).size( ) >= reglas.getMinimoJugadores( );
	}

	/**
	 * DESCONTAR UN PARTIDO A LAS SANCIONES
	 *
	 * Se llama cuando el equipo acaba de jugar, entonces a cada sancion vigente
	 * le baja un partido y asi se van cumpliendo de a poquitos.
	 *
	 * Ojo con el orden: esto hay que hacerlo ANTES de crear las sanciones nuevas
	 * de ese mismo partido. Pues si se hace al reves entonces una tarjeta de hoy
	 * quedaria pagada con el partido de hoy, que es el que acaba de jugarse, y
	 * eso esta mal.
	 */
	public void descontarSanciones( )
	{
		for( InscripcionEquipo inscripcion : inscripciones )
		{
			for( Sancion sancion : inscripcion.getJugador( ).getSancionesVigentes( ) )
			{
				if( sancion.getEquipo( ).equals( this ) )
				{
					sancion.descontarPartido( );
				}
			}
		}
	}

	/**
	 * REVISAR SI UNA CAMISETA YA ESTA TOMADA
	 *
	 * Dentro de un mismo equipo no pueden haber dos camisetas iguales, entonces
	 * hay que mirar las inscripciones activas antes de asignarla.
	 *
	 * @param numeroCamiseta el numero que se quiere revisar
	 * @return true si el numero ya esta en uso
	 */
	public boolean estaCamisetaOcupada( int numeroCamiseta )
	{
		for( InscripcionEquipo inscripcion : inscripciones )
		{
			if( inscripcion.isActiva( ) && inscripcion.getNumeroCamiseta( ) == numeroCamiseta )
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * CUANTOS JUGADORES TIENE EL EQUIPO
	 *
	 * Cuenta solo los que tienen la inscripcion activa, pues los que se retiraron
	 * siguen en la lista pero ya no cuentan para el cupo.
	 *
	 * @return la cantidad de jugadores con inscripcion activa
	 */
	public int getNumeroInscritos( )
	{
		int total = 0;
		for( InscripcionEquipo inscripcion : inscripciones )
		{
			if( inscripcion.isActiva( ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public ReglasDeporte getReglas( )
	{
		return reglas;
	}

	public void setReglas( ReglasDeporte reglas )
	{
		this.reglas = reglas;
	}

	public Categoria getCategoria( )
	{
		return categoria;
	}

	public void setCategoria( Categoria categoria )
	{
		this.categoria = categoria;
	}

	public int getCupoMaximo( )
	{
		return cupoMaximo;
	}

	public void setCupoMaximo( int cupoMaximo )
	{
		this.cupoMaximo = cupoMaximo;
	}

	public boolean isActivo( )
	{
		return activo;
	}

	public void setActivo( boolean activo )
	{
		this.activo = activo;
	}

	public List<InscripcionEquipo> getInscripciones( )
	{
		return inscripciones;
	}

	@Override
	public boolean equals( Object objeto )
	{
		if( this == objeto )
		{
			return true;
		}
		if( objeto == null || !( objeto instanceof Equipo ) )
		{
			return false;
		}
		Equipo otro = ( Equipo ) objeto;
		return codigo.equals( otro.codigo );
	}

	@Override
	public int hashCode( )
	{
		return codigo.hashCode( );
	}

	@Override
	public String toString( )
	{
		return nombre + " (" + reglas.getNombre( ) + " " + categoria.getNombre( ) + ") - " + getNumeroInscritos( ) + "/" + cupoMaximo + " jugadores";
	}
}
