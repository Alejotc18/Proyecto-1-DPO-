package uniandes.dpoo.cds.modelo.tienda;

import java.io.Serializable;

/**
 * ITEM DE UNA VENTA
 *
 * Es un renglon del recibo: que producto, cuantos se llevo y a que precio.
 *
 * Fijese que el precio se guarda aqui y no se le pregunta al producto cada vez.
 * Pues si manana suben el precio de la raqueta, entonces las ventas viejas
 * tienen que seguir mostrando lo que se cobro ese dia y no el precio nuevo, si
 * no los recibos de antes cambiarian solos y eso esta mal.
 */
public class ItemVenta implements Serializable
{
	private static final long serialVersionUID = 1L;

	private Producto producto;

	private int cantidad;

	private double precioUnitario;

	public ItemVenta( Producto producto, int cantidad, double precioUnitario )
	{
		this.producto = producto;
		this.cantidad = cantidad;
		this.precioUnitario = precioUnitario;
	}

	/**
	 * CUANTO VALE ESTE RENGLON
	 *
	 * Es la cantidad por el precio unitario y ya.
	 *
	 * @return el valor de este renglon de la venta
	 */
	public double getSubtotal( )
	{
		return cantidad * precioUnitario;
	}

	public Producto getProducto( )
	{
		return producto;
	}

	public void setProducto( Producto producto )
	{
		this.producto = producto;
	}

	public int getCantidad( )
	{
		return cantidad;
	}

	public void setCantidad( int cantidad )
	{
		this.cantidad = cantidad;
	}

	public double getPrecioUnitario( )
	{
		return precioUnitario;
	}

	public void setPrecioUnitario( double precioUnitario )
	{
		this.precioUnitario = precioUnitario;
	}

	@Override
	public String toString( )
	{
		return cantidad + " x " + producto.getNombre( ) + " a " + String.format( "%.2f", precioUnitario ) + " = " + String.format( "%.2f", getSubtotal( ) );
	}
}
