package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;

/**
 * ADMINISTRADOR
 *
 * Es el que maneja la plata y la parte administrativa del club.
 *
 * DECISION DE DISENO
 * Lo hicimos heredar de Persona y no de Afiliado. Pues si heredara de Afiliado
 * entonces tendria los metodos para inscribirse a partidos y reservar canchas, y
 * nos tocaria ponerle un if en cada uno para bloquearlo, que es justo lo que uno
 * se olvida. Asi como quedo ni siquiera compila si alguien lo intenta, o sea la
 * restriccion la cuida Java y no nosotros.
 */
public class Administrador extends Persona
{
	private static final long serialVersionUID = 1L;

	private String codigoAdministrador;

	private LocalDate fechaAsignacion;

	public Administrador( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoAdministrador, LocalDate fechaAsignacion )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password );
		this.codigoAdministrador = codigoAdministrador;
		this.fechaAsignacion = fechaAsignacion;
	}

	public String getCodigoAdministrador( )
	{
		return codigoAdministrador;
	}

	public void setCodigoAdministrador( String codigoAdministrador )
	{
		this.codigoAdministrador = codigoAdministrador;
	}

	public LocalDate getFechaAsignacion( )
	{
		return fechaAsignacion;
	}

	public void setFechaAsignacion( LocalDate fechaAsignacion )
	{
		this.fechaAsignacion = fechaAsignacion;
	}

	@Override
	public String getRol( )
	{
		return "Administrador";
	}
}
