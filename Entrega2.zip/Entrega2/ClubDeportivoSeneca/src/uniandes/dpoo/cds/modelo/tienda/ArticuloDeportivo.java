package uniandes.dpoo.cds.modelo.tienda;

/**
 * ARTICULO DEPORTIVO
 *
 * Es lo que vende la tienda: raquetas, balones, mallas, uniformes y pelotas.
 * Este no tiene reglas raras como los de cafeteria, entonces es el mas sencillo
 * de todos.
 */
public class ArticuloDeportivo extends Producto
{
	private static final long serialVersionUID = 1L;

	private String categoria;

	private String marca;

	private String talla;

	public static final String RUBRO = "Tienda";

	public ArticuloDeportivo( String codigo, String nombre, double precio, int cantidadDisponible, String categoria, String marca, String talla )
	{
		super( codigo, nombre, precio, cantidadDisponible );
		this.categoria = categoria;
		this.marca = marca;
		this.talla = talla;
	}

	@Override
	public String getRubro( )
	{
		return RUBRO;
	}

	public String getCategoria( )
	{
		return categoria;
	}

	public void setCategoria( String categoria )
	{
		this.categoria = categoria;
	}

	public String getMarca( )
	{
		return marca;
	}

	public void setMarca( String marca )
	{
		this.marca = marca;
	}

	public String getTalla( )
	{
		return talla;
	}

	public void setTalla( String talla )
	{
		this.talla = talla;
	}
}
