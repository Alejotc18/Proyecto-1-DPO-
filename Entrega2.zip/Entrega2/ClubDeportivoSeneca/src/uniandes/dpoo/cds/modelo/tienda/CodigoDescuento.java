package uniandes.dpoo.cds.modelo.tienda;

import java.io.Serializable;

import uniandes.dpoo.cds.modelo.personas.Empleado;

/**
 * CODIGO DE DESCUENTO
 *
 * Es el codigo que el club le da a cada empleado.
 *
 * Si lo usa el mismo empleado descuenta 15%, y si se lo presta a un afiliado
 * entonces descuenta solo 8%. No se junta con otras promociones, o sea se
 * aplica uno solo y asi.
 */
public class CodigoDescuento implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private Empleado titular;

	private double porcentajeTitular;

	private double porcentajeCompartido;

	private boolean activo;

	public static final double PORCENTAJE_TITULAR = 0.15;

	public static final double PORCENTAJE_COMPARTIDO = 0.08;

	public CodigoDescuento( String codigo, Empleado titular )
	{
		this.codigo = codigo;
		this.titular = titular;
		this.porcentajeTitular = PORCENTAJE_TITULAR;
		this.porcentajeCompartido = PORCENTAJE_COMPARTIDO;
		this.activo = true;
	}

	/**
	 * QUE PORCENTAJE TOCA
	 *
	 * Depende de quien lo este usando, entonces el metodo necesita que le digan
	 * si es el duenno o no.
	 *
	 * @param esTitular true si lo usa el empleado duenno del codigo
	 * @return el porcentaje de descuento que debe aplicarse
	 */
	public double getPorcentajeAplicable( boolean esTitular )
	{
		if( esTitular )
		{
			return porcentajeTitular;
		}
		return porcentajeCompartido;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public Empleado getTitular( )
	{
		return titular;
	}

	public void setTitular( Empleado titular )
	{
		this.titular = titular;
	}

	public double getPorcentajeTitular( )
	{
		return porcentajeTitular;
	}

	public void setPorcentajeTitular( double porcentajeTitular )
	{
		this.porcentajeTitular = porcentajeTitular;
	}

	public double getPorcentajeCompartido( )
	{
		return porcentajeCompartido;
	}

	public void setPorcentajeCompartido( double porcentajeCompartido )
	{
		this.porcentajeCompartido = porcentajeCompartido;
	}

	public boolean isActivo( )
	{
		return activo;
	}

	public void setActivo( boolean activo )
	{
		this.activo = activo;
	}

	@Override
	public String toString( )
	{
		return codigo + " (titular " + titular.getNombreCompleto( ) + ")";
	}
}
