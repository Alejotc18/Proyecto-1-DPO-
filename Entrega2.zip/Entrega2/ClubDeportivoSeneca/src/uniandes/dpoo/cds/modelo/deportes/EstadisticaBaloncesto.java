package uniandes.dpoo.cds.modelo.deportes;

import uniandes.dpoo.cds.modelo.personas.Afiliado;

/**
 * ESTADISTICA DE BALONCESTO
 *
 * Guarda lo que mide el baloncesto: puntos, rebotes, asistencias y faltas. Aqui
 * no hay tarjetas pues en baloncesto no existen.
 */
public class EstadisticaBaloncesto extends Estadistica
{
	private static final long serialVersionUID = 1L;

	private int puntos;

	private int rebotes;

	public EstadisticaBaloncesto( Afiliado jugador, Partido partido )
	{
		super( jugador, partido );
		this.puntos = 0;
		this.rebotes = 0;
	}

	@Override
	public int getValorPrincipal( )
	{
		return puntos;
	}

	@Override
	public String getNombreValorPrincipal( )
	{
		return "Puntos";
	}

	@Override
	public String getResumen( )
	{
		return puntos + " puntos, " + rebotes + " rebotes";
	}

	public int getPuntos( )
	{
		return puntos;
	}

	public void setPuntos( int puntos )
	{
		this.puntos = puntos;
	}

	public int getRebotes( )
	{
		return rebotes;
	}

	public void setRebotes( int rebotes )
	{
		this.rebotes = rebotes;
	}
}
