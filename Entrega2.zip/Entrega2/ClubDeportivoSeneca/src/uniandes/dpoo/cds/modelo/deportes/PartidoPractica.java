package uniandes.dpoo.cds.modelo.deportes;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.NivelIncompatibleException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.InscripcionAcademia;
import uniandes.dpoo.cds.modelo.academias.Instalacion;
import uniandes.dpoo.cds.modelo.personas.Afiliado;
import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.reglas.ReglasDisciplina;

/**
 * PARTIDO DE PRACTICA
 *
 * Es un partido de tenis, padel o ping pong que se juega en una cancha del club.
 * Juegan entre dos y cuatro personas segun la modalidad, o sea sencillos o
 * dobles.
 *
 * Tambien puede entrar un entrenador, que es comodin: el enunciado lo deja
 * jugar contra cualquier nivel entonces a el no se le revisa esa regla.
 *
 * Fijese que los participantes estan guardados en dos listas separadas, una de
 * afiliados y otra de entrenadores. Pues en Java un Entrenador no es un
 * Afiliado, el hereda de Empleado, entonces no se pueden meter en la misma
 * lista y toca asi.
 */
public class PartidoPractica extends Partido
{
	private static final long serialVersionUID = 1L;

	private Instalacion instalacion;

	private String modalidad;

	private List<AfiliadoIndividual> participantes;

	private Entrenador entrenador;

	private List<AfiliadoIndividual> ganadores;

	public static final String SENCILLOS = "Sencillos";

	public static final String DOBLES = "Dobles";

	public PartidoPractica( String codigo, LocalDate fecha, LocalTime hora, Instalacion instalacion, String modalidad )
	{
		super( codigo, fecha, hora );
		this.instalacion = instalacion;
		this.modalidad = modalidad;
		this.participantes = new ArrayList<AfiliadoIndividual>( );
		this.ganadores = new ArrayList<AfiliadoIndividual>( );
	}

	/**
	 * REVISAR SI EL PARTIDO SE PUEDE JUGAR
	 *
	 * Primero mira que la cantidad de jugadores si le sirva a la disciplina, o
	 * sea dos para sencillos y cuatro para dobles. Despues revisa que todos los
	 * afiliados tengan niveles compatibles entre ellos.
	 *
	 * Entonces si hay un entrenador metido se salta la revision de niveles, pues
	 * el entra como comodin y puede contra cualquiera.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es la regla que demuestra el programa de prueba 5.
	 */
	@Override
	public void validarPuedeJugarse( ) throws ClubException
	{
		ReglasDisciplina reglas = instalacion.getReglas( );
		int totalJugadores = participantes.size( );
		if( entrenador != null )
		{
			totalJugadores = totalJugadores + 1;
		}
		if( !reglas.esNumeroJugadoresValido( totalJugadores ) )
		{
			throw new OperacionNoPermitidaException( "La disciplina " + reglas.getNombre( ) + " no admite partidos de " + totalJugadores + " jugadores" );
		}
		if( totalJugadores > instalacion.getCapacidadMaxima( ) )
		{
			throw new OperacionNoPermitidaException( "La instalacion " + instalacion.getNombre( ) + " admite maximo " + instalacion.getCapacidadMaxima( ) + " jugadores" );
		}
		if( entrenador != null )
		{
			return;
		}
		for( int i = 0; i < participantes.size( ); i++ )
		{
			for( int j = i + 1; j < participantes.size( ); j++ )
			{
				AfiliadoIndividual uno = participantes.get( i );
				AfiliadoIndividual otro = participantes.get( j );
				if( !uno.puedeJugarContra( otro, reglas.getNombre( ) ) )
				{
					throw new NivelIncompatibleException( "Los niveles de " + uno.getNombreCompleto( ) + " y " + otro.getNombreCompleto( ) + " no son compatibles para jugar " + reglas.getNombre( ) );
				}
			}
		}
	}

	/**
	 * ACTUALIZAR EL RANKING DESPUES DEL PARTIDO
	 *
	 * A cada jugador se le compara su puntaje contra el promedio de los otros y
	 * de ahi sale cuanto sube o baja, segun la formula de la disciplina.
	 *
	 * El entrenador no entra en esta cuenta pues el no esta inscrito en ninguna
	 * academia, entonces no tiene puntaje que mover.
	 *
	 * Ojo con el orden: los puntajes viejos hay que guardarlos ANTES de empezar a
	 * cambiarlos. Pues si uno le cambia el puntaje al primero y despues calcula
	 * el promedio para el segundo, entonces ese promedio ya salio con el valor
	 * nuevo y las cuentas quedan torcidas.
	 *
	 * la parte del codigo que puede hacerlo estallar es: implementa el sistema de ranking del enunciado.
	 */
	public void actualizarRankings( )
	{
		ReglasDisciplina reglas = instalacion.getReglas( );
		String disciplina = reglas.getNombre( );
		List<Double> puntajesPrevios = new ArrayList<Double>( );
		for( AfiliadoIndividual jugador : participantes )
		{
			InscripcionAcademia inscripcion = jugador.buscarInscripcion( disciplina );
			puntajesPrevios.add( inscripcion.getPuntajeRanking( ) );
		}

		for( int i = 0; i < participantes.size( ); i++ )
		{
			AfiliadoIndividual jugador = participantes.get( i );
			InscripcionAcademia inscripcion = jugador.buscarInscripcion( disciplina );
			double promedioRivales = calcularPromedioRivales( puntajesPrevios, i );
			boolean gano = ganadores.contains( jugador );
			double nuevo = reglas.calcularNuevoPuntaje( puntajesPrevios.get( i ), promedioRivales, gano );
			inscripcion.registrarCambioRanking( nuevo );
		}
	}

	/**
	 * PROMEDIO DE LOS RIVALES
	 *
	 * Suma los puntajes de todos menos el del jugador que se esta mirando y
	 * divide, entonces eso da contra que nivel jugo el.
	 *
	 * @param puntajes los puntajes de todos los participantes antes del partido
	 * @param indiceJugador la posicion del jugador dentro de la lista
	 * @return el promedio de los demas
	 */
	private double calcularPromedioRivales( List<Double> puntajes, int indiceJugador )
	{
		double suma = 0.0;
		int cantidad = 0;
		for( int i = 0; i < puntajes.size( ); i++ )
		{
			if( i != indiceJugador )
			{
				suma = suma + puntajes.get( i );
				cantidad = cantidad + 1;
			}
		}
		if( cantidad == 0 )
		{
			return puntajes.get( indiceJugador );
		}
		return suma / cantidad;
	}

	/**
	 * ARMAR LAS ESTADISTICAS DE TODOS
	 *
	 * No construye las estadisticas directamente sino que se las pide a las
	 * reglas de la disciplina, pues ellas son las que saben si toca una de tenis
	 * o una de ping pong. Entonces este metodo no tiene que saber nada de eso y
	 * asi, si manana agregan otra disciplina aqui no se toca nada.
	 */
	public void generarEstadisticas( )
	{
		ReglasDisciplina reglas = instalacion.getReglas( );
		for( Afiliado jugador : participantes )
		{
			agregarEstadistica( reglas.crearEstadistica( jugador, this ) );
		}
	}

	@Override
	public String getDescripcionRivales( )
	{
		StringBuilder texto = new StringBuilder( );
		for( int i = 0; i < participantes.size( ); i++ )
		{
			if( i > 0 )
			{
				texto.append( " / " );
			}
			texto.append( participantes.get( i ).getNombreCompleto( ) );
		}
		if( entrenador != null )
		{
			texto.append( " / " ).append( entrenador.getNombreCompleto( ) ).append( " (entrenador)" );
		}
		return texto.toString( );
	}

	public void agregarParticipante( AfiliadoIndividual jugador )
	{
		participantes.add( jugador );
	}

	public void marcarGanador( AfiliadoIndividual jugador )
	{
		if( !ganadores.contains( jugador ) )
		{
			ganadores.add( jugador );
		}
	}

	public Instalacion getInstalacion( )
	{
		return instalacion;
	}

	public void setInstalacion( Instalacion instalacion )
	{
		this.instalacion = instalacion;
	}

	public String getModalidad( )
	{
		return modalidad;
	}

	public void setModalidad( String modalidad )
	{
		this.modalidad = modalidad;
	}

	public List<AfiliadoIndividual> getParticipantes( )
	{
		return participantes;
	}

	public Entrenador getEntrenador( )
	{
		return entrenador;
	}

	public void setEntrenador( Entrenador entrenador )
	{
		this.entrenador = entrenador;
	}

	public List<AfiliadoIndividual> getGanadores( )
	{
		return ganadores;
	}
}
