package uniandes.dpoo.cds.persistencia;

/**
 * EXCEPCION DE PERSISTENCIA
 *
 * Agrupa los errores que salen al leer o escribir los archivos del club.
 *
 * Fijese que esta NO hereda de ClubException, y es a proposito: las otras son
 * errores de las reglas del club, o sea cupo lleno, jugador sancionado y asi.
 * Esta en cambio es de archivos, que es otra capa.
 *
 * Lo que hace entonces es envolver los errores feos de Java como IOException,
 * para que las clases del modelo no tengan que saber nada de archivos ni de
 * carpetas y asi.
 */
public class PersistenciaException extends Exception
{
	private static final long serialVersionUID = 1L;

	public PersistenciaException( String mensaje )
	{
		super( mensaje );
	}

	public PersistenciaException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
