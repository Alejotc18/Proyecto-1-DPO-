package uniandes.dpoo.cds.persistencia;

import uniandes.dpoo.cds.logica.Club;

/**
 * REPOSITORIO DEL CLUB, PATRON DAO
 *
 * Esta interfaz dice que se puede hacer con los datos del club, y son solo tres
 * cosas: guardar, cargar y decir que mecanismo es.
 *
 * La gracia es que las clases del modelo no saben si los datos terminan en
 * archivos de texto, en archivos binarios o en una base de datos. Ellas solo
 * saben que existe algo que guarda y carga, y ya.
 *
 * Entonces nosotros tenemos dos implementaciones y cambiar de una a la otra es
 * cambiar la linea donde se construye el repositorio, nada mas. Si en el
 * Proyecto 2 toca pasar a base de datos pues se escribe una tercera y el modelo
 * ni se entera y asi.
 */
public interface RepositorioClub
{
	/**
	 * GUARDAR EL CLUB
	 *
	 * @param club el club que se quiere guardar
	 * @throws PersistenciaException si ocurre un error de escritura
	 */
	public void guardar( Club club ) throws PersistenciaException;

	/**
	 * CARGAR EL CLUB
	 *
	 * @return el club cargado
	 * @throws PersistenciaException si ocurre un error de lectura o los datos estan corruptos
	 */
	public Club cargar( ) throws PersistenciaException;

	/**
	 * QUE MECANISMO ES
	 *
	 * Es solo para los reportes, para poder escribir si se guardo en texto o en
	 * binario.
	 *
	 * @return una descripcion del mecanismo de persistencia, para los reportes
	 */
	public String getDescripcion( );
}
