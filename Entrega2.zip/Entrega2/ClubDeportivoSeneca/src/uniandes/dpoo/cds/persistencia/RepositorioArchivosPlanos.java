package uniandes.dpoo.cds.persistencia;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.logica.Club;
import uniandes.dpoo.cds.modelo.academias.Instalacion;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.deportes.InscripcionEquipo;
import uniandes.dpoo.cds.modelo.personas.Administrador;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;
import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;
import uniandes.dpoo.cds.modelo.personas.Empleado;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.modelo.personas.Fisioterapeuta;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.modelo.tienda.Alergeno;
import uniandes.dpoo.cds.modelo.tienda.ArticuloDeportivo;
import uniandes.dpoo.cds.modelo.tienda.Bebida;
import uniandes.dpoo.cds.modelo.tienda.CodigoDescuento;
import uniandes.dpoo.cds.modelo.tienda.Snack;
import uniandes.dpoo.cds.reglas.CatalogoReglas;

/**
 * REPOSITORIO CON ARCHIVOS PLANOS
 *
 * Guarda y carga los datos del club en archivos de texto separados por punto y
 * coma, dentro de la carpeta de datos.
 *
 * Fijese que la ruta de esa carpeta no esta escrita aqui adentro sino que llega
 * por el constructor. Pues asi las pruebas de la siguiente entrega pueden
 * apuntar a su propia carpeta sin tocar esta clase y asi.
 *
 * DECISION DE DISENO SOBRE LOS ARCHIVOS
 * Usamos un archivo por entidad y no uno solo con todo. La razon es que las
 * entidades tienen columnas completamente distintas: una persona lleva
 * documento y fecha de nacimiento, un producto lleva precio y cantidad.
 * Entonces en un solo archivo casi todas las filas quedarian con la mitad de
 * las columnas vacias, y ademas tocaria poner un campo al principio de cada
 * linea diciendo de que tipo es. Asi como quedo cada archivo tiene su propio
 * encabezado y se puede abrir y editar a mano, que es justo lo que necesitamos
 * para armar los datos de los programas de prueba.
 *
 * POR QUE PUNTO Y COMA Y NO COMA
 * Porque varios textos del dominio ya traen comas adentro, tipo los nombres de
 * las competencias o los motivos de una sancion. Si el separador fuera la coma
 * entonces tocaria encerrar esos valores entre comillas y escribir un lector
 * que distinga cual coma separa y cual no, y pues no vale la pena.
 *
 * la parte del codigo que puede hacerlo estallar es: el orden de carga. Las
 * referencias entre entidades se guardan por codigo y no por objeto, entonces
 * hay que cargar primero las personas, despues los equipos y de ultimas las
 * inscripciones, que dependen de las dos anteriores. Si se invierte ese orden
 * las inscripciones buscan gente que todavia no existe y todo se cae.
 */
public class RepositorioArchivosPlanos implements RepositorioClub
{
	private File carpeta;

	public static final String SEPARADOR = ";";

	public static final String ARCHIVO_CLUB = "club.txt";

	public static final String ARCHIVO_PERSONAS = "personas.txt";

	public static final String ARCHIVO_EQUIPOS = "equipos.txt";

	public static final String ARCHIVO_INSCRIPCIONES = "inscripciones.txt";

	public static final String ARCHIVO_ACADEMIAS = "academias.txt";

	public static final String ARCHIVO_INSTALACIONES = "instalaciones.txt";

	public static final String ARCHIVO_PRODUCTOS = "productos.txt";

	public RepositorioArchivosPlanos( String rutaCarpeta )
	{
		this.carpeta = new File( rutaCarpeta );
		if( !carpeta.exists( ) )
		{
			carpeta.mkdirs( );
		}
	}

	// ESCRITURA

	@Override
	public void guardar( Club club ) throws PersistenciaException
	{
		guardarClub( club );
		guardarPersonas( club );
		guardarEquipos( club );
		guardarInscripciones( club );
		guardarAcademias( club );
		guardarInstalaciones( club );
		guardarProductos( club );
	}

	private void guardarClub( Club club ) throws PersistenciaException
	{
		PrintWriter salida = abrirEscritura( ARCHIVO_CLUB );
		try
		{
			salida.println( "# nombre;institucion;horaApertura;horaCierre;minEntrenadores;minFisioterapeutas;maxInstalacionesSimultaneas" );
			salida.println( club.getNombre( ) + SEPARADOR + club.getInstitucion( ) + SEPARADOR + club.getHoraApertura( ) + SEPARADOR + club.getHoraCierre( ) + SEPARADOR + club.getMinimoEntrenadores( ) + SEPARADOR + club.getMinimoFisioterapeutas( ) + SEPARADOR + club.getMaximoInstalacionesSimultaneas( ) );
		}
		finally
		{
			salida.close( );
		}
	}

	private void guardarPersonas( Club club ) throws PersistenciaException
	{
		PrintWriter salida = abrirEscritura( ARCHIVO_PERSONAS );
		try
		{
			salida.println( "# tipo;documento;nombre;apellido;fechaNacimiento;correo;telefono;login;password;codigo;fecha;extra1;extra2" );
			for( Persona persona : club.getPersonas( ).values( ) )
			{
				salida.println( convertirPersona( persona ) );
			}
		}
		finally
		{
			salida.close( );
		}
	}

	/**
	 * PASAR UNA PERSONA A UNA LINEA DE TEXTO
	 *
	 * El primer campo guarda el tipo a proposito. Pues una linea de texto no se
	 * acuerda de que clase era el objeto, entonces al cargar no sabriamos si
	 * construir un AfiliadoConjunto o un Entrenador y asi.
	 *
	 * nota: las fechas y las horas se escriben con toString, que las deja en
	 * formato ISO tipo 2026-03-15 y 18:30. Eso es de java.time y es lo mismo que
	 * LocalDate.parse y LocalTime.parse saben leer de vuelta, entonces no toca
	 * configurar ningun formato raro.
	 *
	 * @param persona la persona que se quiere escribir
	 * @return la linea lista para el archivo
	 */
	private String convertirPersona( Persona persona )
	{
		StringBuilder linea = new StringBuilder( );
		String tipo = "ADMIN";
		String codigo = "";
		String fecha = "";
		String extra1 = "";
		String extra2 = "";

		if( persona instanceof AfiliadoConjunto )
		{
			AfiliadoConjunto afiliado = ( AfiliadoConjunto ) persona;
			tipo = "AFIL_CONJUNTO";
			codigo = afiliado.getCodigoAfiliado( );
			fecha = String.valueOf( afiliado.getFechaAfiliacion( ) );
			extra1 = String.valueOf( afiliado.getPuntosFidelidad( ) );
		}
		else if( persona instanceof AfiliadoIndividual )
		{
			AfiliadoIndividual afiliado = ( AfiliadoIndividual ) persona;
			tipo = "AFIL_INDIVIDUAL";
			codigo = afiliado.getCodigoAfiliado( );
			fecha = String.valueOf( afiliado.getFechaAfiliacion( ) );
			extra1 = String.valueOf( afiliado.getPuntosFidelidad( ) );
		}
		else if( persona instanceof Entrenador )
		{
			Entrenador entrenador = ( Entrenador ) persona;
			tipo = "ENTRENADOR";
			codigo = entrenador.getCodigoEmpleado( );
			fecha = String.valueOf( entrenador.getFechaContratacion( ) );
			extra1 = entrenador.getEspecialidad( );
			extra2 = String.valueOf( entrenador.getAniosExperiencia( ) );
		}
		else if( persona instanceof Fisioterapeuta )
		{
			Fisioterapeuta fisioterapeuta = ( Fisioterapeuta ) persona;
			tipo = "FISIOTERAPEUTA";
			codigo = fisioterapeuta.getCodigoEmpleado( );
			fecha = String.valueOf( fisioterapeuta.getFechaContratacion( ) );
			extra1 = fisioterapeuta.getTarjetaProfesional( );
		}
		else if( persona instanceof Administrador )
		{
			Administrador administrador = ( Administrador ) persona;
			codigo = administrador.getCodigoAdministrador( );
			fecha = String.valueOf( administrador.getFechaAsignacion( ) );
		}

		linea.append( tipo ).append( SEPARADOR );
		linea.append( persona.getDocumento( ) ).append( SEPARADOR );
		linea.append( persona.getNombre( ) ).append( SEPARADOR );
		linea.append( persona.getApellido( ) ).append( SEPARADOR );
		linea.append( persona.getFechaNacimiento( ) ).append( SEPARADOR );
		linea.append( persona.getCorreo( ) ).append( SEPARADOR );
		linea.append( persona.getTelefono( ) ).append( SEPARADOR );
		linea.append( persona.getLogin( ) ).append( SEPARADOR );
		linea.append( persona.getPassword( ) ).append( SEPARADOR );
		linea.append( codigo ).append( SEPARADOR );
		linea.append( fecha ).append( SEPARADOR );
		linea.append( extra1 ).append( SEPARADOR );
		linea.append( extra2 );
		return linea.toString( );
	}

	private void guardarEquipos( Club club ) throws PersistenciaException
	{
		PrintWriter salida = abrirEscritura( ARCHIVO_EQUIPOS );
		try
		{
			salida.println( "# codigo;nombre;deporte;categoria;cupoMaximo;activo" );
			for( Equipo equipo : club.getEquipos( ).values( ) )
			{
				salida.println( equipo.getCodigo( ) + SEPARADOR + equipo.getNombre( ) + SEPARADOR + equipo.getReglas( ).getNombre( ) + SEPARADOR + equipo.getCategoria( ).getNombre( ) + SEPARADOR + equipo.getCupoMaximo( ) + SEPARADOR + equipo.isActivo( ) );
			}
		}
		finally
		{
			salida.close( );
		}
	}

	private void guardarInscripciones( Club club ) throws PersistenciaException
	{
		PrintWriter salida = abrirEscritura( ARCHIVO_INSCRIPCIONES );
		try
		{
			salida.println( "# documentoJugador;codigoEquipo;numeroCamiseta;posicion;fechaInscripcion;activa" );
			for( Equipo equipo : club.getEquipos( ).values( ) )
			{
				for( InscripcionEquipo inscripcion : equipo.getInscripciones( ) )
				{
					salida.println( inscripcion.getJugador( ).getDocumento( ) + SEPARADOR + equipo.getCodigo( ) + SEPARADOR + inscripcion.getNumeroCamiseta( ) + SEPARADOR + inscripcion.getPosicion( ) + SEPARADOR + inscripcion.getFechaInscripcion( ) + SEPARADOR + inscripcion.isActiva( ) );
				}
			}
		}
		finally
		{
			salida.close( );
		}
	}

	private void guardarAcademias( Club club ) throws PersistenciaException
	{
		PrintWriter salida = abrirEscritura( ARCHIVO_ACADEMIAS );
		try
		{
			salida.println( "# documentoAfiliado;disciplina;nivel;puntajeRanking;fechaInscripcion" );
			for( Persona persona : club.getPersonas( ).values( ) )
			{
				if( persona instanceof AfiliadoIndividual )
				{
					AfiliadoIndividual afiliado = ( AfiliadoIndividual ) persona;
					for( uniandes.dpoo.cds.modelo.academias.InscripcionAcademia inscripcion : afiliado.getInscripciones( ) )
					{
						salida.println( afiliado.getDocumento( ) + SEPARADOR + inscripcion.getReglas( ).getNombre( ) + SEPARADOR + inscripcion.getNivel( ).getNombre( ) + SEPARADOR + inscripcion.getPuntajeRanking( ) + SEPARADOR + inscripcion.getFechaInscripcion( ) );
					}
				}
			}
		}
		finally
		{
			salida.close( );
		}
	}

	private void guardarInstalaciones( Club club ) throws PersistenciaException
	{
		PrintWriter salida = abrirEscritura( ARCHIVO_INSTALACIONES );
		try
		{
			salida.println( "# codigo;nombre;disciplina;capacidadMaxima;techada;disponible" );
			for( Instalacion instalacion : club.getInstalaciones( ).values( ) )
			{
				salida.println( instalacion.getCodigo( ) + SEPARADOR + instalacion.getNombre( ) + SEPARADOR + instalacion.getReglas( ).getNombre( ) + SEPARADOR + instalacion.getCapacidadMaxima( ) + SEPARADOR + instalacion.isTechada( ) + SEPARADOR + instalacion.isDisponible( ) );
			}
		}
		finally
		{
			salida.close( );
		}
	}

	private void guardarProductos( Club club ) throws PersistenciaException
	{
		PrintWriter salida = abrirEscritura( ARCHIVO_PRODUCTOS );
		try
		{
			salida.println( "# tipo;codigo;nombre;precio;cantidad;extra1;extra2;alergenos" );
			for( uniandes.dpoo.cds.modelo.tienda.Producto producto : club.getProductos( ).values( ) )
			{
				if( producto instanceof ArticuloDeportivo )
				{
					ArticuloDeportivo articulo = ( ArticuloDeportivo ) producto;
					salida.println( "ARTICULO" + SEPARADOR + articulo.getCodigo( ) + SEPARADOR + articulo.getNombre( ) + SEPARADOR + articulo.getPrecio( ) + SEPARADOR + articulo.getCantidadDisponible( ) + SEPARADOR + articulo.getCategoria( ) + SEPARADOR + articulo.getMarca( ) + SEPARADOR + articulo.getTalla( ) );
				}
				else if( producto instanceof Bebida )
				{
					Bebida bebida = ( Bebida ) producto;
					salida.println( "BEBIDA" + SEPARADOR + bebida.getCodigo( ) + SEPARADOR + bebida.getNombre( ) + SEPARADOR + bebida.getPrecio( ) + SEPARADOR + bebida.getCantidadDisponible( ) + SEPARADOR + bebida.isCaliente( ) + SEPARADOR + bebida.getTamanio( ) + SEPARADOR );
				}
				else if( producto instanceof Snack )
				{
					Snack snack = ( Snack ) producto;
					StringBuilder alergenos = new StringBuilder( );
					for( int i = 0; i < snack.getAlergenos( ).size( ); i++ )
					{
						if( i > 0 )
						{
							alergenos.append( "," );
						}
						alergenos.append( snack.getAlergenos( ).get( i ).getNombre( ) );
					}
					salida.println( "SNACK" + SEPARADOR + snack.getCodigo( ) + SEPARADOR + snack.getNombre( ) + SEPARADOR + snack.getPrecio( ) + SEPARADOR + snack.getCantidadDisponible( ) + SEPARADOR + snack.getGramaje( ) + SEPARADOR + SEPARADOR + alergenos.toString( ) );
				}
			}
		}
		finally
		{
			salida.close( );
		}
	}

	// LECTURA

	@Override
	public Club cargar( ) throws PersistenciaException
	{
		Club club = cargarClub( );
		cargarPersonas( club );
		cargarEquipos( club );
		cargarInscripciones( club );
		cargarAcademias( club );
		cargarInstalaciones( club );
		cargarProductos( club );
		return club;
	}

	private Club cargarClub( ) throws PersistenciaException
	{
		List<String[]> filas = leerArchivo( ARCHIVO_CLUB );
		if( filas.isEmpty( ) )
		{
			throw new PersistenciaException( "El archivo " + ARCHIVO_CLUB + " esta vacio" );
		}
		String[] fila = filas.get( 0 );
		Club club = new Club( fila[ 0 ], fila[ 1 ], LocalTime.parse( fila[ 2 ] ), LocalTime.parse( fila[ 3 ] ), Integer.parseInt( fila[ 6 ] ) );
		club.setMinimoEntrenadores( Integer.parseInt( fila[ 4 ] ) );
		club.setMinimoFisioterapeutas( Integer.parseInt( fila[ 5 ] ) );
		return club;
	}

	private void cargarPersonas( Club club ) throws PersistenciaException
	{
		for( String[] fila : leerArchivo( ARCHIVO_PERSONAS ) )
		{
			try
			{
				Persona persona = construirPersona( fila );
				if( persona != null )
				{
					club.registrarPersona( persona );
					if( persona instanceof Empleado )
					{
						Empleado empleado = ( Empleado ) persona;
						empleado.setCodigoDescuento( new CodigoDescuento( "DESC-" + empleado.getCodigoEmpleado( ), empleado ) );
					}
				}
			}
			catch( ClubException excepcion )
			{
				throw new PersistenciaException( "Error al cargar la persona con documento " + fila[ 1 ], excepcion );
			}
		}
	}

	/**
	 * ARMAR LA PERSONA CORRECTA A PARTIR DE UNA LINEA
	 *
	 * Mira el primer campo, que es el tipo, y segun eso construye la subclase
	 * que toca.
	 *
	 * nota: aqui aparece LocalDate.parse, que es de java.time. Lo que hace es
	 * coger el texto "2006-05-14" y volverlo una fecha de verdad, para poder
	 * compararla despues. Si la dejaramos como texto nos tocaria partirla en
	 * dia, mes y ano a mano cada vez.
	 *
	 * @param fila los campos de la linea
	 * @return la persona construida
	 */
	private Persona construirPersona( String[] fila )
	{
		String tipo = fila[ 0 ];
		String documento = fila[ 1 ];
		String nombre = fila[ 2 ];
		String apellido = fila[ 3 ];
		LocalDate nacimiento = LocalDate.parse( fila[ 4 ] );
		String correo = fila[ 5 ];
		String telefono = fila[ 6 ];
		String login = fila[ 7 ];
		String password = fila[ 8 ];
		String codigo = fila[ 9 ];
		LocalDate fecha = LocalDate.parse( fila[ 10 ] );
		String extra1 = leerCampo( fila, 11 );
		String extra2 = leerCampo( fila, 12 );

		if( "AFIL_CONJUNTO".equals( tipo ) )
		{
			AfiliadoConjunto afiliado = new AfiliadoConjunto( documento, nombre, apellido, nacimiento, correo, telefono, login, password, codigo, fecha );
			afiliado.setPuntosFidelidad( leerEntero( extra1 ) );
			return afiliado;
		}
		if( "AFIL_INDIVIDUAL".equals( tipo ) )
		{
			AfiliadoIndividual afiliado = new AfiliadoIndividual( documento, nombre, apellido, nacimiento, correo, telefono, login, password, codigo, fecha );
			afiliado.setPuntosFidelidad( leerEntero( extra1 ) );
			return afiliado;
		}
		if( "ENTRENADOR".equals( tipo ) )
		{
			return new Entrenador( documento, nombre, apellido, nacimiento, correo, telefono, login, password, codigo, fecha, extra1, leerEntero( extra2 ) );
		}
		if( "FISIOTERAPEUTA".equals( tipo ) )
		{
			return new Fisioterapeuta( documento, nombre, apellido, nacimiento, correo, telefono, login, password, codigo, fecha, extra1 );
		}
		if( "ADMIN".equals( tipo ) )
		{
			return new Administrador( documento, nombre, apellido, nacimiento, correo, telefono, login, password, codigo, fecha );
		}
		return null;
	}

	private void cargarEquipos( Club club ) throws PersistenciaException
	{
		for( String[] fila : leerArchivo( ARCHIVO_EQUIPOS ) )
		{
			Equipo equipo = new Equipo( fila[ 0 ], fila[ 1 ], CatalogoReglas.getDeporte( fila[ 2 ] ), Categoria.porNombre( fila[ 3 ] ), Integer.parseInt( fila[ 4 ] ) );
			equipo.setActivo( Boolean.parseBoolean( fila[ 5 ] ) );
			club.agregarEquipo( equipo );
		}
	}

	private void cargarInscripciones( Club club ) throws PersistenciaException
	{
		for( String[] fila : leerArchivo( ARCHIVO_INSCRIPCIONES ) )
		{
			Persona persona = club.buscarPersona( fila[ 0 ] );
			Equipo equipo = club.buscarEquipo( fila[ 1 ] );
			if( persona instanceof AfiliadoConjunto && equipo != null )
			{
				AfiliadoConjunto jugador = ( AfiliadoConjunto ) persona;
				InscripcionEquipo inscripcion = new InscripcionEquipo( jugador, equipo, Integer.parseInt( fila[ 2 ] ), fila[ 3 ], LocalDate.parse( fila[ 4 ] ) );
				inscripcion.setActiva( Boolean.parseBoolean( fila[ 5 ] ) );
				equipo.getInscripciones( ).add( inscripcion );
				jugador.agregarInscripcion( inscripcion );
			}
		}
	}

	private void cargarAcademias( Club club ) throws PersistenciaException
	{
		for( String[] fila : leerArchivo( ARCHIVO_ACADEMIAS ) )
		{
			Persona persona = club.buscarPersona( fila[ 0 ] );
			if( persona instanceof AfiliadoIndividual )
			{
				AfiliadoIndividual afiliado = ( AfiliadoIndividual ) persona;
				uniandes.dpoo.cds.modelo.academias.InscripcionAcademia inscripcion = new uniandes.dpoo.cds.modelo.academias.InscripcionAcademia( afiliado, CatalogoReglas.getDisciplina( fila[ 1 ] ), Nivel.porNombre( fila[ 2 ] ), LocalDate.parse( fila[ 4 ] ) );
				inscripcion.setPuntajeRanking( Double.parseDouble( fila[ 3 ] ) );
				afiliado.agregarInscripcion( inscripcion );
			}
		}
	}

	private void cargarInstalaciones( Club club ) throws PersistenciaException
	{
		for( String[] fila : leerArchivo( ARCHIVO_INSTALACIONES ) )
		{
			Instalacion instalacion = new Instalacion( fila[ 0 ], fila[ 1 ], CatalogoReglas.getDisciplina( fila[ 2 ] ), Integer.parseInt( fila[ 3 ] ), Boolean.parseBoolean( fila[ 4 ] ) );
			instalacion.setDisponible( Boolean.parseBoolean( fila[ 5 ] ) );
			club.agregarInstalacion( instalacion );
		}
	}

	private void cargarProductos( Club club ) throws PersistenciaException
	{
		for( String[] fila : leerArchivo( ARCHIVO_PRODUCTOS ) )
		{
			String tipo = fila[ 0 ];
			String codigo = fila[ 1 ];
			String nombre = fila[ 2 ];
			double precio = Double.parseDouble( fila[ 3 ] );
			int cantidad = Integer.parseInt( fila[ 4 ] );

			if( "ARTICULO".equals( tipo ) )
			{
				club.agregarProducto( new ArticuloDeportivo( codigo, nombre, precio, cantidad, leerCampo( fila, 5 ), leerCampo( fila, 6 ), leerCampo( fila, 7 ) ) );
			}
			else if( "BEBIDA".equals( tipo ) )
			{
				club.agregarProducto( new Bebida( codigo, nombre, precio, cantidad, Boolean.parseBoolean( leerCampo( fila, 5 ) ), leerCampo( fila, 6 ) ) );
			}
			else if( "SNACK".equals( tipo ) )
			{
				Snack snack = new Snack( codigo, nombre, precio, cantidad, leerEntero( leerCampo( fila, 5 ) ) );
				String listaAlergenos = leerCampo( fila, 7 );
				if( !listaAlergenos.isEmpty( ) )
				{
					for( String alergeno : listaAlergenos.split( "," ) )
					{
						snack.agregarAlergeno( new Alergeno( alergeno.trim( ), "Declarado en el archivo de productos" ) );
					}
				}
				club.agregarProducto( snack );
			}
		}
	}

	// UTILIDADES DE ARCHIVOS

	/**
	 * LEER UN ARCHIVO Y PARTIRLO EN CAMPOS
	 *
	 * Se salta las lineas vacias y las que empiezan por almohadilla, pues esas
	 * son los encabezados que pusimos para que se entienda el formato cuando uno
	 * abra el archivo.
	 *
	 * @param nombreArchivo el nombre del archivo dentro de la carpeta de datos
	 * @return la lista de filas
	 * @throws PersistenciaException si el archivo no existe o no se puede leer
	 */
	private List<String[]> leerArchivo( String nombreArchivo ) throws PersistenciaException
	{
		File archivo = new File( carpeta, nombreArchivo );
		List<String[]> filas = new ArrayList<String[]>( );
		if( !archivo.exists( ) )
		{
			return filas;
		}
		BufferedReader lector = null;
		try
		{
			lector = new BufferedReader( new FileReader( archivo ) );
			String linea = lector.readLine( );
			while( linea != null )
			{
				String contenido = linea.trim( );
				if( !contenido.isEmpty( ) && !contenido.startsWith( "#" ) )
				{
					filas.add( contenido.split( SEPARADOR, -1 ) );
				}
				linea = lector.readLine( );
			}
		}
		catch( IOException excepcion )
		{
			throw new PersistenciaException( "No fue posible leer el archivo " + archivo.getPath( ), excepcion );
		}
		finally
		{
			if( lector != null )
			{
				try
				{
					lector.close( );
				}
				catch( IOException excepcion )
				{
					System.err.println( "Aviso: no se pudo cerrar " + archivo.getPath( ) );
				}
			}
		}
		return filas;
	}

	private PrintWriter abrirEscritura( String nombreArchivo ) throws PersistenciaException
	{
		try
		{
			return new PrintWriter( new File( carpeta, nombreArchivo ) );
		}
		catch( IOException excepcion )
		{
			throw new PersistenciaException( "No fue posible escribir el archivo " + nombreArchivo, excepcion );
		}
	}

	/**
	 * SACAR UN CAMPO SIN QUE REVIENTE
	 *
	 * Si la linea tiene menos campos de los que esperabamos devuelve texto vacio
	 * en vez de reventar.
	 *
	 * Pues si a una linea le falta un campo opcional, sin esto se caeria toda la
	 * carga del archivo por culpa de una sola fila y asi.
	 *
	 * @param fila los campos de la linea
	 * @param posicion la posicion que se quiere leer
	 * @return el valor del campo, o una cadena vacia
	 */
	private String leerCampo( String[] fila, int posicion )
	{
		if( posicion < fila.length )
		{
			return fila[ posicion ].trim( );
		}
		return "";
	}

	private int leerEntero( String texto )
	{
		if( texto == null || texto.trim( ).isEmpty( ) )
		{
			return 0;
		}
		try
		{
			return Integer.parseInt( texto.trim( ) );
		}
		catch( NumberFormatException excepcion )
		{
			return 0;
		}
	}

	@Override
	public String getDescripcion( )
	{
		return "Archivos planos separados por punto y coma (" + carpeta.getPath( ) + ")";
	}
}
