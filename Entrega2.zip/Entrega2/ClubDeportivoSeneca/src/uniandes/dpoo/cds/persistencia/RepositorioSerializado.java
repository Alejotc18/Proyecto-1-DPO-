package uniandes.dpoo.cds.persistencia;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import uniandes.dpoo.cds.logica.Club;

/**
 * REPOSITORIO CON SERIALIZACION
 *
 * Guarda el club completo en un archivo binario, usando la serializacion que
 * trae Java.
 *
 * Lo usamos para el estado completo pues el modelo del club es un enredo de
 * objetos que se apuntan entre ellos: el jugador apunta a sus inscripciones,
 * cada inscripcion apunta a su equipo, y el equipo apunta de vuelta a sus
 * inscripciones. Rearmar eso a mano desde texto obligaria a hacer dos
 * recorridos, uno creando objetos y otro conectandolos. La serializacion en
 * cambio lo hace sola y no pierde ninguna conexion.
 *
 * Pero tiene su problema y por eso no es el unico mecanismo: el archivo es
 * fragil. Si uno le cambia la estructura a una clase entonces los archivos
 * viejos ya no se pueden leer. Y como es binario tampoco se puede abrir para
 * revisarlo. Para los datos que hay que poder editar a mano usamos el de
 * archivos planos y asi.
 */
public class RepositorioSerializado implements RepositorioClub
{
	private File archivo;

	public RepositorioSerializado( String rutaArchivo )
	{
		this.archivo = new File( rutaArchivo );
	}

	@Override
	public void guardar( Club club ) throws PersistenciaException
	{
		ObjectOutputStream salida = null;
		try
		{
			File carpeta = archivo.getParentFile( );
			if( carpeta != null && !carpeta.exists( ) )
			{
				carpeta.mkdirs( );
			}
			salida = new ObjectOutputStream( new FileOutputStream( archivo ) );
			salida.writeObject( club );
		}
		catch( IOException excepcion )
		{
			throw new PersistenciaException( "No fue posible guardar el club en " + archivo.getPath( ), excepcion );
		}
		finally
		{
			cerrar( salida );
		}
	}

	@Override
	public Club cargar( ) throws PersistenciaException
	{
		if( !archivo.exists( ) )
		{
			throw new PersistenciaException( "El archivo " + archivo.getPath( ) + " no existe" );
		}
		ObjectInputStream entrada = null;
		try
		{
			entrada = new ObjectInputStream( new FileInputStream( archivo ) );
			return ( Club ) entrada.readObject( );
		}
		catch( IOException excepcion )
		{
			throw new PersistenciaException( "No fue posible leer el archivo " + archivo.getPath( ), excepcion );
		}
		catch( ClassNotFoundException excepcion )
		{
			throw new PersistenciaException( "El archivo " + archivo.getPath( ) + " fue escrito con una version distinta de las clases", excepcion );
		}
		finally
		{
			cerrar( entrada );
		}
	}

	/**
	 * CERRAR UN ARCHIVO SIN HACER ESCANDALO
	 *
	 * Si cerrar falla pues no hay nada que el programa pueda hacer, entonces nos
	 * tragamos ese error.
	 *
	 * Y es importante: si lo dejaramos salir taparia la excepcion original, que
	 * es la que de verdad explica que paso. O sea uno terminaria viendo "no se
	 * pudo cerrar el archivo" cuando el problema real era otro y asi.
	 *
	 * @param recurso el flujo que se quiere cerrar
	 */
	private void cerrar( java.io.Closeable recurso )
	{
		if( recurso != null )
		{
			try
			{
				recurso.close( );
			}
			catch( IOException excepcion )
			{
				System.err.println( "Aviso: no se pudo cerrar el archivo " + archivo.getPath( ) );
			}
		}
	}

	@Override
	public String getDescripcion( )
	{
		return "Archivo binario serializado (" + archivo.getPath( ) + ")";
	}
}
