package uniandes.dpoo.cds.excepciones;

/**
 * EXCEPCION BASE DEL CLUB
 *
 * De aqui heredan todas las demas excepciones nuestras. Pues la idea es que si
 * alguien quiere atrapar cualquier error de las reglas del club de una sola vez,
 * entonces atrapa esta y ya, no le toca nombrarlas una por una.
 */
public class ClubException extends Exception
{
	private static final long serialVersionUID = 1L;

	public ClubException( String mensaje )
	{
		super( mensaje );
	}

	public ClubException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
