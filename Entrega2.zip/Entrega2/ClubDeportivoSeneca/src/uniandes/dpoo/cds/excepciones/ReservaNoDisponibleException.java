package uniandes.dpoo.cds.excepciones;

/**
 * RESERVA NO DISPONIBLE
 *
 * Se lanza cuando la instalacion ya esta ocupada en esa hora o cuando ya se
 * gastaron todas las canchas que la disciplina puede tener al tiempo y asi.
 */
public class ReservaNoDisponibleException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public ReservaNoDisponibleException( String mensaje )
	{
		super( mensaje );
	}

	public ReservaNoDisponibleException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
