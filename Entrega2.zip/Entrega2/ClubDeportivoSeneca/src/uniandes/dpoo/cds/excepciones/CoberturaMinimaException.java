package uniandes.dpoo.cds.excepciones;

/**
 * COBERTURA MINIMA
 *
 * Se lanza cuando aprobar un cambio de turno dejaria al club sin la cantidad
 * minima de personal. Entonces el club no se puede quedar sin entrenadores ni
 * sin fisioterapeuta en el horario de atencion y por eso se bloquea el cambio.
 */
public class CoberturaMinimaException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public CoberturaMinimaException( String mensaje )
	{
		super( mensaje );
	}

	public CoberturaMinimaException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
