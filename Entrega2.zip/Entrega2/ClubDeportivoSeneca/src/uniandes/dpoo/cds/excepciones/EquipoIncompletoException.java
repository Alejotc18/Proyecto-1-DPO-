package uniandes.dpoo.cds.excepciones;

/**
 * EQUIPO INCOMPLETO
 *
 * Se lanza cuando el equipo no junta el minimo de jugadores habilitados que pide
 * el deporte. Pues un equipo de futbol con 6 jugadores no puede salir a jugar.
 */
public class EquipoIncompletoException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public EquipoIncompletoException( String mensaje )
	{
		super( mensaje );
	}

	public EquipoIncompletoException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
