package uniandes.dpoo.cds.excepciones;

/**
 * CUPO LLENO
 *
 * Se lanza cuando el equipo ya tiene todos los jugadores que aguanta, entonces
 * no se puede inscribir a nadie mas y asi.
 */
public class CupoLlenoException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public CupoLlenoException( String mensaje )
	{
		super( mensaje );
	}

	public CupoLlenoException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
