package uniandes.dpoo.cds.excepciones;

/**
 * JUGADOR SUSPENDIDO
 *
 * Se lanza cuando se intenta meter en la nomina a un jugador que todavia esta
 * pagando una sancion, entonces ese jugador no puede jugar hasta que la cumpla.
 */
public class JugadorSuspendidoException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public JugadorSuspendidoException( String mensaje )
	{
		super( mensaje );
	}

	public JugadorSuspendidoException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
