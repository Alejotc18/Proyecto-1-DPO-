package uniandes.dpoo.cds.excepciones;

/**
 * NIVEL INCOMPATIBLE
 *
 * Se lanza cuando dos jugadores que quieren un partido de practica estan muy
 * lejos de nivel. Pues un Principiante contra un Avanzado no tiene sentido,
 * entonces solo se permite entre niveles seguidos.
 */
public class NivelIncompatibleException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public NivelIncompatibleException( String mensaje )
	{
		super( mensaje );
	}

	public NivelIncompatibleException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
