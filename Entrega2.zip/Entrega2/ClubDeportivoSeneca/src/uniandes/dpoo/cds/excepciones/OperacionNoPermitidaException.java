package uniandes.dpoo.cds.excepciones;

/**
 * OPERACION NO PERMITIDA
 *
 * Se lanza cuando alguien intenta hacer algo que su rol no lo deja hacer, pues
 * cada tipo de usuario tiene sus cosas y no se pueden mezclar.
 */
public class OperacionNoPermitidaException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public OperacionNoPermitidaException( String mensaje )
	{
		super( mensaje );
	}

	public OperacionNoPermitidaException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
