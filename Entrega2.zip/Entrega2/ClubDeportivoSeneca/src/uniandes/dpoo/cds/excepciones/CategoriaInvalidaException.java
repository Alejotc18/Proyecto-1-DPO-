package uniandes.dpoo.cds.excepciones;

/**
 * CATEGORIA INVALIDA
 *
 * Se lanza cuando la edad del afiliado no da para la categoria del equipo, pues
 * un equipo de Juvenil no puede recibir a alguien de 40 anos y asi.
 */
public class CategoriaInvalidaException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public CategoriaInvalidaException( String mensaje )
	{
		super( mensaje );
	}

	public CategoriaInvalidaException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
