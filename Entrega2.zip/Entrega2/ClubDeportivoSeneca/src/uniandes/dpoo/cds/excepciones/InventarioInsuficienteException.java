package uniandes.dpoo.cds.excepciones;

/**
 * INVENTARIO INSUFICIENTE
 *
 * Se lanza cuando no hay unidades suficientes del producto para la venta, pues
 * no se puede vender lo que no hay en la tienda y asi.
 */
public class InventarioInsuficienteException extends ClubException
{
	private static final long serialVersionUID = 1L;

	public InventarioInsuficienteException( String mensaje )
	{
		super( mensaje );
	}

	public InventarioInsuficienteException( String mensaje, Throwable causa )
	{
		super( mensaje, causa );
	}
}
