package uniandes.dpoo.cds.pruebas.integracion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.CupoLlenoException;
import uniandes.dpoo.cds.excepciones.EquipoIncompletoException;
import uniandes.dpoo.cds.excepciones.NivelIncompatibleException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.logica.Club;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.modelo.tienda.Bono;
import uniandes.dpoo.cds.modelo.tienda.VentaTienda;
import uniandes.dpoo.cds.modelo.torneos.Encuentro;
import uniandes.dpoo.cds.modelo.torneos.EstadoTorneo;
import uniandes.dpoo.cds.modelo.torneos.InscripcionTorneo;
import uniandes.dpoo.cds.modelo.torneos.Modalidad;
import uniandes.dpoo.cds.modelo.torneos.Participante;
import uniandes.dpoo.cds.modelo.torneos.Torneo;
import uniandes.dpoo.cds.modelo.torneos.TorneoCompetitivo;
import uniandes.dpoo.cds.modelo.torneos.TorneoRecreativo;
import uniandes.dpoo.cds.pruebas.EscenarioPruebas;

/**
 * Pruebas de integracion de los torneos. Son los casos CP-01 a CP-50 del
 * documento de historias de usuario.
 *
 * Se llaman de integracion y no unitarias porque casi todas pasan por la
 * fachada Club y mueven varios objetos al tiempo: inscribir a alguien toca el
 * torneo, el participante, el ranking de la academia y los turnos del empleado.
 * Las que miran una clase sola estan en el paquete unitarias.
 *
 * Cada metodo lleva el numero del caso en el nombre, entonces cuando una falla
 * se sabe de una cual caso del documento no esta pasando.
 */
public class TorneosIntegracionTest
{
	private EscenarioPruebas escenario;

	private Club club;

	private LocalDate hoy;

	@BeforeEach
	public void prepararEscenario( ) throws ClubException
	{
		escenario = new EscenarioPruebas( );
		club = escenario.club;
		hoy = escenario.hoy;
	}

	// historia: crear un torneo

	@Test
	@DisplayName( "CP-01 el torneo competitivo valido queda abierto con 2 cupos preferenciales y 8 regulares" )
	public void cp01CrearTorneoValido( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );

		assertEquals( EstadoTorneo.INSCRIPCIONES_ABIERTAS, t1.getEstado( ), "el torneo recien creado abre inscripciones" );
		assertEquals( 2, t1.getCuposPreferenciales( ), "el 20% de 10 cupos son 2 preferenciales" );
		assertEquals( 8, t1.getCuposRegulares( ), "los otros 8 son regulares" );
		assertSame( t1, club.buscarTorneo( "T1" ), "el torneo queda registrado en el club" );
	}

	@Test
	@DisplayName( "CP-02 los cupos preferenciales se redondean hacia arriba: 7 cupos dan 2 preferenciales" )
	public void cp02RedondeoHaciaArriba( ) throws ClubException
	{
		TorneoCompetitivo torneo = escenario.crearT1( "T1-7", 7 );

		assertEquals( 2, torneo.getCuposPreferenciales( ), "el 20% de 7 es 1,4 y sube a 2" );
		assertEquals( 5, torneo.getCuposRegulares( ), "quedan 5 regulares" );
	}

	@Test
	@DisplayName( "CP-03 un torneo competitivo sin tarifa no se puede crear" )
	public void cp03CompetitivoSinTarifa( )
	{
		assertThrows( OperacionNoPermitidaException.class, ( ) -> new TorneoCompetitivo( "T1", "Abierto de tenis", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, escenario.fechaTorneo, 10, 0.0, EscenarioPruebas.PORCENTAJE_PREMIO ) );
		assertNull( club.buscarTorneo( "T1" ), "el torneo no quedo registrado" );
	}

	@Test
	@DisplayName( "CP-04 un torneo con fecha pasada no se puede crear" )
	public void cp04FechaPasada( ) throws ClubException
	{
		TorneoCompetitivo viejo = new TorneoCompetitivo( "T1", "Abierto de tenis", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, hoy.minusDays( 14 ), 10, EscenarioPruebas.TARIFA, EscenarioPruebas.PORCENTAJE_PREMIO );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.crearTorneo( viejo ) );
		assertNull( club.buscarTorneo( "T1" ), "el torneo no quedo registrado en el club" );
	}

	@Test
	@DisplayName( "CP-05 pueden existir dos torneos abiertos al mismo tiempo" )
	public void cp05TorneosSimultaneos( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		TorneoRecreativo t2 = escenario.crearRecreativoDobles( );

		assertEquals( EstadoTorneo.INSCRIPCIONES_ABIERTAS, t1.getEstado( ) );
		assertEquals( EstadoTorneo.INSCRIPCIONES_ABIERTAS, t2.getEstado( ) );
		assertEquals( 2, club.consultarTorneos( EstadoTorneo.INSCRIPCIONES_ABIERTAS ).size( ) );
	}

	// historia: modificar o cancelar un torneo

	@Test
	@DisplayName( "CP-06 al subir los cupos se recalculan los preferenciales y los inscritos se conservan" )
	public void cp06SubirCuposConInscritos( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 3 );

		club.modificarCuposTorneo( t1, 16 );

		assertEquals( 4, t1.getCuposPreferenciales( ), "el 20% de 16 son 4" );
		assertEquals( 12, t1.getCuposRegulares( ), "los otros 12 son regulares" );
		assertEquals( 3, t1.getInscripciones( ).size( ), "los 3 inscritos siguen adentro" );
	}

	@Test
	@DisplayName( "CP-07 no se pueden bajar los cupos por debajo de los que ya estan inscritos" )
	public void cp07BajarCuposPorDebajoDeInscritos( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 6 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.modificarCuposTorneo( t1, 5 ) );
		assertEquals( 10, t1.getCupos( ), "los cupos se quedaron en 10" );
	}

	@Test
	@DisplayName( "CP-08 cancelar un torneo abierto lo deja en Cancelado y sin inscritos" )
	public void cp08CancelarTorneoAbierto( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 3 );

		club.cancelarTorneo( t1 );

		assertEquals( EstadoTorneo.CANCELADO, t1.getEstado( ) );
		assertEquals( 0, t1.getInscripciones( ).size( ), "al cancelar se sueltan las inscripciones" );
	}

	@Test
	@DisplayName( "CP-09 un torneo En curso ya no se puede modificar" )
	public void cp09ModificarTorneoEnCurso( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 4 );
		club.iniciarTorneo( t1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.modificarCuposTorneo( t1, 12 ) );
		assertEquals( 10, t1.getCupos( ) );
	}

	// historia: liberar cupos preferenciales

	@Test
	@DisplayName( "CP-10 liberar con un preferencial ocupado pasa el otro a regular" )
	public void cp10LiberarConUnPreferencialOcupado( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		club.inscribirEnTorneo( t1, escenario.tenistas[ 0 ], hoy );

		int liberados = club.liberarCuposPreferenciales( t1 );

		assertEquals( 1, liberados, "sobraba un cupo preferencial" );
		assertEquals( 1, t1.getCuposPreferenciales( ) );
		assertEquals( 9, t1.getCuposRegulares( ) );
	}

	@Test
	@DisplayName( "CP-11 liberar con los preferenciales llenos no cambia nada" )
	public void cp11LiberarConPreferencialesLlenos( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 2 );

		int liberados = club.liberarCuposPreferenciales( t1 );

		assertEquals( 0, liberados );
		assertEquals( 2, t1.getCuposPreferenciales( ) );
		assertEquals( 8, t1.getCuposRegulares( ) );
	}

	// historia: iniciar un torneo

	@Test
	@DisplayName( "CP-12 iniciar con 8 participantes arma 4 encuentros de primera ronda" )
	public void cp12IniciarConOchoParticipantes( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 8 );

		club.iniciarTorneo( t1 );

		assertEquals( EstadoTorneo.EN_CURSO, t1.getEstado( ) );
		assertEquals( 4, t1.getEncuentrosDeRonda( 1 ).size( ), "8 participantes dan 4 cruces" );
		assertEquals( 0, t1.getCuposPreferencialesDisponibles( ), "al iniciar no puede quedar un preferencial suelto" );
	}

	@Test
	@DisplayName( "CP-13 un torneo con un solo participante no se puede iniciar" )
	public void cp13IniciarConUnParticipante( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.iniciarTorneo( t1 ) );
		assertEquals( EstadoTorneo.INSCRIPCIONES_ABIERTAS, t1.getEstado( ) );
	}

	// historia: registrar el resultado de un encuentro

	@Test
	@DisplayName( "CP-14 un resultado valido deja ganador y actualiza la tabla de posiciones" )
	public void cp14RegistrarResultadoValido( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 4 );
		club.iniciarTorneo( t1 );
		Encuentro encuentro = t1.getEncuentrosDeRonda( 1 ).get( 0 );
		Participante local = encuentro.getParticipanteA( );

		club.registrarResultadoEncuentro( t1, encuentro, 3, 1 );

		assertSame( local, encuentro.getGanador( ) );
		assertEquals( 3, t1.buscarPosicion( local ).getPuntos( ), "la victoria vale 3 puntos" );
		assertEquals( 1, t1.buscarPosicion( encuentro.getParticipanteB( ) ).getJugados( ) );
	}

	@Test
	@DisplayName( "CP-15 un encuentro que ya tiene resultado no se puede volver a registrar" )
	public void cp15ResultadoRepetido( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 4 );
		club.iniciarTorneo( t1 );
		Encuentro encuentro = t1.getEncuentrosDeRonda( 1 ).get( 0 );
		club.registrarResultadoEncuentro( t1, encuentro, 3, 1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.registrarResultadoEncuentro( t1, encuentro, 2, 0 ) );
		assertEquals( 3, encuentro.getMarcadorA( ), "se conserva el 3-1" );
		assertEquals( 1, encuentro.getMarcadorB( ) );
	}

	@Test
	@DisplayName( "CP-16 un marcador negativo no se acepta" )
	public void cp16MarcadorNegativo( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 4 );
		club.iniciarTorneo( t1 );
		Encuentro encuentro = t1.getEncuentrosDeRonda( 1 ).get( 1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.registrarResultadoEncuentro( t1, encuentro, -1, 2 ) );
		assertFalse( encuentro.isJugado( ) );
	}

	// historia: finalizar el torneo y entregar el premio

	@Test
	@DisplayName( "CP-17 con 8 pagos de 50.000 y premio del 80% el campeon se lleva 320.000" )
	public void cp17FinalizarConOchoPagos( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 8 );
		club.iniciarTorneo( t1 );
		escenario.jugarTorneoCompleto( t1 );

		Participante campeon = club.finalizarTorneo( t1 );

		assertEquals( EstadoTorneo.FINALIZADO, t1.getEstado( ) );
		assertEquals( 400000.0, t1.getTotalRecaudado( ), 0.01, "8 inscripciones de 50.000" );
		assertEquals( 320000.0, t1.getPremioEntregado( ), 0.01, "el 80% de lo recaudado" );
		assertSame( campeon, t1.getGanadorDelPremio( ) );
	}

	@Test
	@DisplayName( "CP-18 los empleados no pagan, entonces con 2 empleados el premio baja a 240.000" )
	public void cp18FinalizarConDosEmpleados( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 6 );
		club.inscribirEnTorneo( t1, escenario.entrenadorLibre, hoy );
		club.inscribirEnTorneo( t1, escenario.fisioterapeuta, hoy );
		club.iniciarTorneo( t1 );
		escenario.jugarTorneoCompleto( t1 );

		club.finalizarTorneo( t1 );

		assertEquals( 300000.0, t1.getTotalRecaudado( ), 0.01, "solo pagaron los 6 afiliados" );
		assertEquals( 240000.0, t1.getPremioEntregado( ), 0.01 );
	}

	@Test
	@DisplayName( "CP-19 si gana un empleado el premio en efectivo pasa al siguiente que no lo sea" )
	public void cp19GanaUnEmpleado( ) throws ClubException
	{
		TorneoCompetitivo torneo = escenario.crearT1( "T1-E", 2 );
		club.inscribirEnTorneo( torneo, escenario.entrenadorLibre, hoy );
		club.inscribirEnTorneo( torneo, escenario.tenistas[ 0 ], hoy );
		club.iniciarTorneo( torneo );
		escenario.jugarTorneoCompleto( torneo );

		Participante campeon = club.finalizarTorneo( torneo );

		assertTrue( campeon.tieneEmpleados( ), "el campeon de la cancha fue el entrenador" );
		assertFalse( torneo.getGanadorDelPremio( ).tieneEmpleados( ), "pero el efectivo se lo lleva el afiliado" );
		assertTrue( torneo.getGanadorDelPremio( ).incluye( escenario.tenistas[ 0 ] ) );
	}

	@Test
	@DisplayName( "CP-20 un recreativo de dobles entrega un bono del 15% a cada integrante de la pareja" )
	public void cp20FinalizarRecreativoDeDobles( ) throws ClubException
	{
		TorneoRecreativo t2 = escenario.crearRecreativoDobles( );
		club.inscribirParejaEnTorneo( t2, escenario.padelistas[ 0 ], escenario.padelistas[ 1 ], hoy );
		club.inscribirParejaEnTorneo( t2, escenario.padelistas[ 2 ], escenario.padelistas[ 3 ], hoy );
		club.iniciarTorneo( t2 );
		escenario.jugarTorneoCompleto( t2 );

		club.finalizarTorneo( t2 );

		assertEquals( 2, t2.getBonosEntregados( ).size( ), "sale un bono por integrante" );
		assertEquals( 1, escenario.padelistas[ 0 ].getBonosDisponibles( ).size( ) );
		assertEquals( 1, escenario.padelistas[ 1 ].getBonosDisponibles( ).size( ) );
		assertEquals( 0.15, t2.getBonosEntregados( ).get( 0 ).getPorcentajeDescuento( ), 0.0001 );
	}

	@Test
	@DisplayName( "CP-21 un torneo con encuentros pendientes no se puede finalizar" )
	public void cp21FinalizarConEncuentrosPendientes( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 4 );
		club.iniciarTorneo( t1 );
		club.registrarResultadoEncuentro( t1, t1.getEncuentrosDeRonda( 1 ).get( 0 ), 3, 1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.finalizarTorneo( t1 ) );
		assertEquals( EstadoTorneo.EN_CURSO, t1.getEstado( ) );
	}

	// historia: inscribirse en un torneo individual o de dobles

	@Test
	@DisplayName( "CP-22 un estudiante sin ranking entra por cupo regular y paga la tarifa completa" )
	public void cp22InscripcionRegularDeEstudiante( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );

		InscripcionTorneo inscripcion = club.inscribirEnTorneo( t1, escenario.estudiante, hoy );

		assertFalse( inscripcion.isPreferencial( ), "el estudiante no esta en el ranking del club" );
		assertEquals( 7, t1.getCuposRegularesDisponibles( ), "de 8 regulares queda 1 ocupado" );
		assertEquals( 50000.0, inscripcion.getValorPagado( ), 0.01 );
	}

	@Test
	@DisplayName( "CP-23 una pareja de dobles ocupa un solo cupo y los dos quedan inscritos" )
	public void cp23InscripcionDeDobles( ) throws ClubException
	{
		TorneoRecreativo t2 = escenario.crearRecreativoDobles( );

		club.inscribirParejaEnTorneo( t2, escenario.padelistas[ 0 ], escenario.padelistas[ 1 ], hoy );

		assertEquals( 1, t2.getInscripciones( ).size( ), "la pareja es un cupo, no dos" );
		assertNotNull( t2.buscarInscripcionDe( escenario.padelistas[ 0 ] ) );
		assertNotNull( t2.buscarInscripcionDe( escenario.padelistas[ 1 ] ) );
	}

	@Test
	@DisplayName( "CP-24 un jugador de nivel Avanzado no entra a un torneo Intermedio" )
	public void cp24NivelDistinto( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );

		assertThrows( NivelIncompatibleException.class, ( ) -> club.inscribirEnTorneo( t1, escenario.tenistaAvanzado, hoy ) );
		assertEquals( 0, t1.getInscripciones( ).size( ) );
	}

	@Test
	@DisplayName( "CP-25 nadie se puede inscribir dos veces al mismo torneo" )
	public void cp25InscripcionRepetida( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		club.inscribirEnTorneo( t1, escenario.tenistas[ 0 ], hoy );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.inscribirEnTorneo( t1, escenario.tenistas[ 0 ], hoy ) );
		assertEquals( 1, t1.getInscripciones( ).size( ) );
	}

	@Test
	@DisplayName( "CP-26 sin cupo regular disponible la inscripcion se rechaza" )
	public void cp26SinCupoRegular( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		// Los dos primeros del ranking toman los preferenciales y los seis
		// siguientes mas el estudiante y el externo llenan los ocho regulares.
		escenario.inscribirTenistas( t1, 8 );
		club.inscribirEnTorneo( t1, escenario.estudiante, hoy );
		club.inscribirEnTorneo( t1, escenario.externo, hoy );

		assertEquals( 0, t1.getCuposRegularesDisponibles( ) );
		assertThrows( CupoLlenoException.class, ( ) -> club.inscribirEnTorneo( t1, escenario.tenistas[ 8 ], hoy ) );
	}

	// historia: inscribir un equipo en un torneo de conjunto

	@Test
	@DisplayName( "CP-27 un equipo completo ocupa un cupo del torneo de conjunto" )
	public void cp27InscribirEquipoCompleto( ) throws ClubException
	{
		TorneoCompetitivo t3 = escenario.crearTorneoDeConjunto( );

		InscripcionTorneo inscripcion = club.inscribirEquipoEnTorneo( t3, escenario.equipoCompleto, hoy );

		assertEquals( 1, t3.getInscripciones( ).size( ) );
		assertEquals( escenario.equipoCompleto.getNombre( ), inscripcion.getParticipante( ).getNombre( ) );
	}

	@Test
	@DisplayName( "CP-28 un equipo sin el minimo de jugadores no se puede inscribir" )
	public void cp28EquipoIncompleto( ) throws ClubException
	{
		TorneoCompetitivo t3 = escenario.crearTorneoDeConjunto( );

		assertThrows( EquipoIncompletoException.class, ( ) -> club.inscribirEquipoEnTorneo( t3, escenario.equipoIncompleto, hoy ) );
		assertEquals( 0, t3.getInscripciones( ).size( ) );
	}

	@Test
	@DisplayName( "CP-29 un equipo no cabe en un torneo individual" )
	public void cp29EquipoEnTorneoIndividual( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.inscribirEquipoEnTorneo( t1, escenario.equipoCompleto, hoy ) );
	}

	// historia: inscribirse en un cupo preferencial

	@Test
	@DisplayName( "CP-30 el primero del ranking entra por cupo preferencial" )
	public void cp30JugadorElegible( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );

		InscripcionTorneo inscripcion = club.inscribirEnTorneo( t1, escenario.tenistas[ 0 ], hoy );

		assertTrue( inscripcion.isPreferencial( ) );
		assertEquals( 1, t1.getCuposPreferencialesDisponibles( ), "queda un preferencial libre" );
		assertEquals( 8, t1.getCuposRegularesDisponibles( ), "los regulares no se tocaron" );
	}

	@Test
	@DisplayName( "CP-31 un elegible que llega con los preferenciales llenos entra por cupo regular" )
	public void cp31ElegibleConPreferencialesLlenos( ) throws ClubException
	{
		TorneoCompetitivo torneo = escenario.crearT1( "T1-P", 5 );
		// Con 5 cupos solo hay 1 preferencial, entonces el primero lo toma.
		club.inscribirEnTorneo( torneo, escenario.tenistas[ 0 ], hoy );

		InscripcionTorneo segunda = club.inscribirEnTorneo( torneo, escenario.tenistas[ 1 ], hoy );

		assertEquals( 0, torneo.getCuposPreferencialesDisponibles( ) );
		assertFalse( segunda.isPreferencial( ), "no se queda afuera, se pasa a regular" );
	}

	@Test
	@DisplayName( "CP-32 a la pareja le vale el mejor ranking de los dos integrantes" )
	public void cp32ParejaConUnIntegranteElegible( ) throws ClubException
	{
		TorneoRecreativo t2 = escenario.crearRecreativoDobles( );

		// El padelista 2 es el segundo del ranking y el 4 es el ultimo: a la
		// pareja le cuenta el del segundo y le alcanza para el preferencial.
		InscripcionTorneo inscripcion = club.inscribirParejaEnTorneo( t2, escenario.padelistas[ 1 ], escenario.padelistas[ 3 ], hoy );

		assertTrue( inscripcion.isPreferencial( ) );
	}

	// historia: desinscribirse de un torneo

	@Test
	@DisplayName( "CP-33 salir de un cupo regular devuelve el cupo regular" )
	public void cp33SalirDeCupoRegular( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		club.inscribirEnTorneo( t1, escenario.estudiante, hoy );
		assertEquals( 7, t1.getCuposRegularesDisponibles( ) );

		club.desinscribirDeTorneo( t1, escenario.estudiante );

		assertEquals( 8, t1.getCuposRegularesDisponibles( ) );
	}

	@Test
	@DisplayName( "CP-34 salir de un cupo preferencial devuelve el preferencial y no toca los regulares" )
	public void cp34SalirDeCupoPreferencial( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		club.inscribirEnTorneo( t1, escenario.tenistas[ 0 ], hoy );

		club.desinscribirDeTorneo( t1, escenario.tenistas[ 0 ] );

		assertEquals( 2, t1.getCuposPreferencialesDisponibles( ) );
		assertEquals( 8, t1.getCuposRegularesDisponibles( ) );
	}

	@Test
	@DisplayName( "CP-35 de un torneo En curso ya no se puede salir" )
	public void cp35SalirDeTorneoEnCurso( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 4 );
		club.iniciarTorneo( t1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.desinscribirDeTorneo( t1, escenario.tenistas[ 0 ] ) );
	}

	@Test
	@DisplayName( "CP-36 no se puede salir de un torneo en el que uno no estaba" )
	public void cp36SalirSinEstarInscrito( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.desinscribirDeTorneo( t1, escenario.tenistas[ 0 ] ) );
	}

	// historia: consultar y redimir bonos

	@Test
	@DisplayName( "CP-37 la consulta de bonos trae los disponibles y los usados con su estado" )
	public void cp37ConsultarBonos( ) throws ClubException
	{
		Persona socio = escenario.tenistas[ 0 ];
		socio.agregarBono( new Bono( "BONO-1", socio, 0.15, "T9", "Copa vieja" ) );
		Bono gastado = new Bono( "BONO-2", socio, 0.10, "T8", "Copa mas vieja" );
		gastado.marcarUsado( hoy.minusDays( 5 ) );
		socio.agregarBono( gastado );

		assertEquals( 2, club.getBonosDe( socio ).size( ), "la consulta trae los dos" );
		assertEquals( 1, socio.getBonosDisponibles( ).size( ), "pero solo uno sirve" );
	}

	/**
	 * CP-38, redimir un bono valido.
	 *
	 * Ojo con este numero: el documento dice que una compra de 40.000 con un bono
	 * del 15% queda en 34.000. Ese es el valor despues del descuento pero antes
	 * del impuesto, que es lo que aqui se revisa con el subtotal menos el
	 * descuento. El total que paga el cliente lleva ademas el IVA del 19% que la
	 * tienda cobra desde la Entrega 2, o sea 40.460.
	 */
	@Test
	@DisplayName( "CP-38 un bono del 15% sobre una compra de 40.000 descuenta 6.000 y queda usado" )
	public void cp38RedimirBonoValido( ) throws ClubException
	{
		Persona socio = escenario.tenistas[ 0 ];
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T9", "Copa recreativa" );
		socio.agregarBono( bono );
		VentaTienda venta = new VentaTienda( "V-01", hoy, socio );
		venta.agregarItem( escenario.raqueta, 1 );

		club.redimirBonoEnVenta( venta, bono );
		venta.liquidar( );

		assertEquals( 6000.0, venta.getDescuento( ), 0.01, "el 15% de 40.000" );
		assertEquals( 34000.0, venta.getSubtotal( ) - venta.getDescuento( ), 0.01, "la base antes del IVA" );
		assertTrue( bono.isUsado( ), "el bono se gasta al liquidar la venta" );
	}

	@Test
	@DisplayName( "CP-39 un bono ya usado no se puede volver a redimir" )
	public void cp39BonoYaUsado( ) throws ClubException
	{
		Persona socio = escenario.tenistas[ 0 ];
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T9", "Copa recreativa" );
		bono.marcarUsado( hoy.minusDays( 1 ) );
		socio.agregarBono( bono );
		VentaTienda venta = new VentaTienda( "V-02", hoy, socio );
		venta.agregarItem( escenario.raqueta, 1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.redimirBonoEnVenta( venta, bono ) );
		venta.liquidar( );
		assertEquals( 0.0, venta.getDescuento( ), 0.01, "la compra queda sin descuento" );
	}

	@Test
	@DisplayName( "CP-40 el bono no es acumulable con otro descuento" )
	public void cp40CompraConOtroDescuento( ) throws ClubException
	{
		Persona socio = escenario.tenistas[ 0 ];
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T9", "Copa recreativa" );
		socio.agregarBono( bono );
		VentaTienda venta = new VentaTienda( "V-03", hoy, socio );
		venta.agregarItem( escenario.raqueta, 1 );
		venta.aplicarDescuento( escenario.entrenadorLibre.getCodigoDescuento( ) );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.redimirBonoEnVenta( venta, bono ) );
	}

	@Test
	@DisplayName( "CP-41 el bono de un socio no lo puede usar otro" )
	public void cp41BonoDeOtroSocio( ) throws ClubException
	{
		Persona dueno = escenario.tenistas[ 0 ];
		Persona otro = escenario.tenistas[ 1 ];
		Bono bono = new Bono( "BONO-1", dueno, 0.15, "T9", "Copa recreativa" );
		dueno.agregarBono( bono );
		VentaTienda venta = new VentaTienda( "V-04", hoy, otro );
		venta.agregarItem( escenario.raqueta, 1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.redimirBonoEnVenta( venta, bono ) );
	}

	// historia: inscribirse como empleado

	@Test
	@DisplayName( "CP-42 un empleado sin turno ese dia se inscribe y paga cero" )
	public void cp42EmpleadoSinTurno( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );

		InscripcionTorneo inscripcion = club.inscribirEnTorneo( t1, escenario.entrenadorLibre, hoy );

		assertEquals( 0.0, inscripcion.getValorPagado( ), 0.01, "los empleados entran gratis" );
		assertFalse( inscripcion.isPreferencial( ), "el empleado no tiene ranking del club" );
		assertTrue( inscripcion.getParticipante( ).tieneEmpleados( ), "queda marcado para no recibir efectivo" );
	}

	@Test
	@DisplayName( "CP-43 un empleado con turno el dia del torneo no se puede inscribir" )
	public void cp43EmpleadoConTurno( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.ponerTurnoElDiaDelTorneo( "TUR-01", escenario.fisioterapeuta );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.inscribirEnTorneo( t1, escenario.fisioterapeuta, hoy ) );
		assertEquals( 0, t1.getInscripciones( ).size( ) );
	}

	@Test
	@DisplayName( "CP-44 un empleado no se puede meter solo a un torneo de conjunto" )
	public void cp44EmpleadoEnTorneoDeConjunto( ) throws ClubException
	{
		TorneoCompetitivo t3 = escenario.crearTorneoDeConjunto( );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.inscribirEnTorneo( t3, escenario.entrenadorLibre, hoy ) );
	}

	@Test
	@DisplayName( "CP-45 un empleado que gana un recreativo si recibe el bono" )
	public void cp45EmpleadoGanaRecreativo( ) throws ClubException
	{
		TorneoRecreativo t4 = escenario.crearRecreativoIndividual( );
		club.inscribirEnTorneo( t4, escenario.entrenadorLibre, hoy );
		club.inscribirEnTorneo( t4, escenario.tenistas[ 0 ], hoy );
		club.iniciarTorneo( t4 );
		escenario.jugarTorneoCompleto( t4 );

		Participante campeon = club.finalizarTorneo( t4 );

		assertTrue( campeon.incluye( escenario.entrenadorLibre ) );
		assertEquals( 1, escenario.entrenadorLibre.getBonosDisponibles( ).size( ), "el bono si se lo gana" );
	}

	// historia: consultar torneos e historial

	@Test
	@DisplayName( "CP-46 la consulta sin filtro trae los tres torneos con su estado" )
	public void cp46ConsultarSinFiltro( ) throws ClubException
	{
		armarTresTorneosEnEstadosDistintos( );

		assertEquals( 3, club.consultarTorneos( null ).size( ) );
	}

	@Test
	@DisplayName( "CP-47 la consulta filtrada por Finalizado trae uno solo" )
	public void cp47FiltrarPorFinalizado( ) throws ClubException
	{
		armarTresTorneosEnEstadosDistintos( );

		assertEquals( 1, club.consultarTorneos( EstadoTorneo.FINALIZADO ).size( ) );
		assertEquals( 1, club.consultarTorneos( EstadoTorneo.EN_CURSO ).size( ) );
		assertEquals( 1, club.consultarTorneos( EstadoTorneo.INSCRIPCIONES_ABIERTAS ).size( ) );
	}

	@Test
	@DisplayName( "CP-48 el historial de un torneo finalizado trae encuentros, posiciones y premio" )
	public void cp48HistorialDeTorneoFinalizado( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 4 );
		club.iniciarTorneo( t1 );
		escenario.jugarTorneoCompleto( t1 );
		club.finalizarTorneo( t1 );

		String historial = t1.getHistorial( );

		assertTrue( historial.contains( "Finalizado" ) );
		assertTrue( historial.contains( "Encuentros:" ) );
		assertTrue( historial.contains( "Posiciones:" ) );
		assertTrue( t1.getPremioEntregado( ) > 0, "el premio quedo entregado" );
	}

	@Test
	@DisplayName( "CP-49 el historial de un torneo En curso muestra lo jugado y lo pendiente" )
	public void cp49HistorialDeTorneoEnCurso( ) throws ClubException
	{
		TorneoCompetitivo t1 = escenario.crearT1( );
		escenario.inscribirTenistas( t1, 8 );
		club.iniciarTorneo( t1 );
		club.registrarResultadoEncuentro( t1, t1.getEncuentrosDeRonda( 1 ).get( 0 ), 3, 1 );
		club.registrarResultadoEncuentro( t1, t1.getEncuentrosDeRonda( 1 ).get( 1 ), 3, 0 );

		assertEquals( 2, t1.contarEncuentrosPendientes( ), "quedan 2 de los 4 de la primera ronda" );
		assertTrue( t1.getHistorial( ).contains( "pendiente" ) );
	}

	@Test
	@DisplayName( "CP-50 buscar un torneo que no existe devuelve null" )
	public void cp50TorneoInexistente( ) throws ClubException
	{
		escenario.crearT1( );

		assertNull( club.buscarTorneo( "X99" ) );
	}

	/**
	 * Deja tres torneos, uno en cada estado. Es el montaje que comparten los dos
	 * casos de la consulta de torneos.
	 *
	 * @throws ClubException si algun torneo no se puede montar
	 */
	private void armarTresTorneosEnEstadosDistintos( ) throws ClubException
	{
		TorneoCompetitivo finalizado = escenario.crearT1( "T-FIN", 4 );
		escenario.inscribirTenistas( finalizado, 2 );
		club.iniciarTorneo( finalizado );
		escenario.jugarTorneoCompleto( finalizado );
		club.finalizarTorneo( finalizado );

		TorneoCompetitivo enCurso = escenario.crearT1( "T-CUR", 4 );
		club.inscribirEnTorneo( enCurso, escenario.tenistas[ 2 ], hoy );
		club.inscribirEnTorneo( enCurso, escenario.tenistas[ 3 ], hoy );
		club.iniciarTorneo( enCurso );

		escenario.crearT1( "T-ABI", 4 );
	}

	/**
	 * Revisa que el torneo de conjunto si pida categoria y no nivel. No es un caso
	 * del documento, lo agregamos para dejar clavado que los dos no se mezclan.
	 */
	@Test
	@DisplayName( "extra: el torneo de conjunto va por categoria y el individual por nivel" )
	public void extraCriterioDeNivelYCategoria( ) throws ClubException
	{
		Torneo conjunto = escenario.crearTorneoDeConjunto( );
		Torneo individual = escenario.crearT1( );

		assertEquals( Categoria.SUB_15, conjunto.getCategoria( ) );
		assertNull( conjunto.getNivel( ), "los de conjunto no tienen nivel" );
		assertEquals( Nivel.INTERMEDIO, individual.getNivel( ) );
		assertNull( individual.getCategoria( ), "los individuales no tienen categoria" );
	}
}
