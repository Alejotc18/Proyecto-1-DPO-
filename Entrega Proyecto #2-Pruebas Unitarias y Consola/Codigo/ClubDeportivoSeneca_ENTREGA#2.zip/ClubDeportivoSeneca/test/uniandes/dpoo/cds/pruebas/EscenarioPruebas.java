package uniandes.dpoo.cds.pruebas;

import java.time.LocalDate;
import java.time.LocalTime;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.logica.Club;
import uniandes.dpoo.cds.modelo.academias.Instalacion;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.entrenamiento.Turno;
import uniandes.dpoo.cds.modelo.personas.Administrador;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;
import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.modelo.personas.Estudiante;
import uniandes.dpoo.cds.modelo.personas.Externo;
import uniandes.dpoo.cds.modelo.personas.Fisioterapeuta;
import uniandes.dpoo.cds.modelo.tienda.ArticuloDeportivo;
import uniandes.dpoo.cds.modelo.tienda.Producto;
import uniandes.dpoo.cds.modelo.torneos.Encuentro;
import uniandes.dpoo.cds.modelo.torneos.Modalidad;
import uniandes.dpoo.cds.modelo.torneos.Torneo;
import uniandes.dpoo.cds.modelo.torneos.TorneoCompetitivo;
import uniandes.dpoo.cds.modelo.torneos.TorneoRecreativo;
import uniandes.dpoo.cds.reglas.CatalogoReglas;

/**
 * El mundo sobre el que corren las pruebas. Esta clase no es una prueba.
 *
 * Arma un club entero en memoria: el administrador, los empleados, nueve
 * tenistas con rankings distintos, un estudiante, un externo, los padelistas y
 * tres equipos de futbol, uno de ellos incompleto a proposito.
 *
 * No se leen los archivos de la carpeta data, porque una prueba que depende de
 * un archivo se cae cuando alguien lo edita, y ademas no habria como armar los
 * casos raros, tipo el equipo incompleto. Entonces cada prueba se construye su
 * propio club desde cero y arranca siempre igual.
 *
 * Las fechas son relativas a hoy y no fijas, porque el club no deja crear
 * torneos con fecha pasada: si dejaramos la fecha quemada, estas pruebas
 * empezarian a fallar solas el dia que esa fecha quede atras.
 */
public class EscenarioPruebas
{
	public Club club;

	public Administrador admin;

	public Entrenador entrenadorLibre;

	public Entrenador entrenadorDeTurno;

	public Entrenador tercerEntrenador;

	public Fisioterapeuta fisioterapeuta;

	/** Los nueve tenistas de nivel Intermedio, ordenados del mejor al peor del ranking. */
	public AfiliadoIndividual[] tenistas;

	public AfiliadoIndividual tenistaAvanzado;

	public Estudiante estudiante;

	public Externo externo;

	/** Las cuatro personas de padel Intermedio, para armar dos parejas de dobles. */
	public AfiliadoIndividual[] padelistas;

	public Equipo equipoCompleto;

	public Equipo equipoIncompleto;

	public Equipo otroEquipoCompleto;

	public Instalacion canchaTenis;

	public Producto raqueta;

	public LocalDate hoy;

	public LocalDate fechaTorneo;

	public static final double TARIFA = 50000.0;

	public static final double PORCENTAJE_PREMIO = 0.8;

	public static final double PORCENTAJE_BONO = 0.15;

	/** Los puntajes de ranking de los nueve tenistas, de mayor a menor. */
	public static final double[] RANKINGS = { 1150, 1120, 1080, 1050, 1020, 1000, 970, 940, 910 };

	public EscenarioPruebas( ) throws ClubException
	{
		hoy = LocalDate.now( );
		fechaTorneo = hoy.plusDays( 20 );

		club = new Club( "Club Deportivo Seneca", "Universidad Seneca", LocalTime.of( 6, 0 ), LocalTime.of( 22, 0 ), 2 );

		armarPersonal( );
		armarTenistas( );
		armarVisitantes( );
		armarPadelistas( );
		armarEquipos( );
		armarInstalacionesYProductos( );
	}

	private void armarPersonal( ) throws ClubException
	{
		admin = new Administrador( "1001", "Lucia", "Moreno", hoy.minusYears( 40 ), "lmoreno@seneca.edu.co", "3001112233", "admin", "admin123", "ADM-01", hoy.minusYears( 6 ) );
		club.registrarPersona( admin );

		entrenadorLibre = new Entrenador( "1002", "Carlos", "Rendon", hoy.minusYears( 38 ), "crendon@seneca.edu.co", "3002223344", "crendon", "clave", "EMP-01", hoy.minusYears( 5 ), "Tenis", 8 );
		entrenadorLibre.setNivelDeclarado( Nivel.INTERMEDIO );
		club.registrarPersona( entrenadorLibre );

		entrenadorDeTurno = new Entrenador( "1003", "Marcela", "Pineda", hoy.minusYears( 36 ), "mpineda@seneca.edu.co", "3003334455", "mpineda", "clave", "EMP-02", hoy.minusYears( 4 ), "Tenis", 5 );
		entrenadorDeTurno.setNivelDeclarado( Nivel.INTERMEDIO );
		club.registrarPersona( entrenadorDeTurno );

		tercerEntrenador = new Entrenador( "1004", "Jorge", "Villalba", hoy.minusYears( 41 ), "jvillalba@seneca.edu.co", "3004445566", "jvillalba", "clave", "EMP-03", hoy.minusYears( 7 ), "Futbol", 11 );
		club.registrarPersona( tercerEntrenador );

		fisioterapeuta = new Fisioterapeuta( "1005", "Paula", "Arcila", hoy.minusYears( 34 ), "parcila@seneca.edu.co", "3005556677", "parcila", "clave", "EMP-04", hoy.minusYears( 3 ), "TP-45821" );
		fisioterapeuta.setNivelDeclarado( Nivel.INTERMEDIO );
		club.registrarPersona( fisioterapeuta );
	}

	private void armarTenistas( ) throws ClubException
	{
		tenistas = new AfiliadoIndividual[RANKINGS.length];
		for( int i = 0; i < RANKINGS.length; i++ )
		{
			String documento = "300" + ( i + 1 );
			AfiliadoIndividual tenista = new AfiliadoIndividual( documento, "Tenista" + ( i + 1 ), "Apellido" + ( i + 1 ), hoy.minusYears( 21 ), "tenista" + ( i + 1 ) + "@seneca.edu.co", "321000000" + i, "tenista" + ( i + 1 ), "clave", "AFI-00" + ( i + 1 ), hoy.minusYears( 2 ) );
			club.registrarPersona( tenista );
			club.inscribirEnAcademia( tenista, CatalogoReglas.getDisciplina( "Tenis" ), Nivel.INTERMEDIO, hoy.minusYears( 2 ) ).setPuntajeRanking( RANKINGS[ i ] );
			tenistas[ i ] = tenista;
		}

		tenistaAvanzado = new AfiliadoIndividual( "3099", "Valentina", "Soto", hoy.minusYears( 22 ), "valentina@seneca.edu.co", "3219999999", "valentina", "clave", "AFI-099", hoy.minusYears( 2 ) );
		club.registrarPersona( tenistaAvanzado );
		club.inscribirEnAcademia( tenistaAvanzado, CatalogoReglas.getDisciplina( "Tenis" ), Nivel.AVANZADO, hoy.minusYears( 2 ) ).setPuntajeRanking( 1300 );
	}

	private void armarVisitantes( ) throws ClubException
	{
		estudiante = new Estudiante( "4001", "Juliana", "Hoyos", hoy.minusYears( 21 ), "jhoyos@seneca.edu.co", "3220000001", "jhoyos", "clave", "EST-001", "Ingenieria de Sistemas", Nivel.INTERMEDIO );
		club.registrarPersona( estudiante );

		externo = new Externo( "5001", "Patricia", "Linares", hoy.minusYears( 28 ), "plinares@correo.com", "3230000001", "plinares", "clave", "Hernan Linares 3109998877", Nivel.INTERMEDIO );
		club.registrarPersona( externo );
	}

	private void armarPadelistas( ) throws ClubException
	{
		padelistas = new AfiliadoIndividual[4];
		for( int i = 0; i < 4; i++ )
		{
			String documento = "310" + ( i + 1 );
			AfiliadoIndividual padelista = new AfiliadoIndividual( documento, "Padelista" + ( i + 1 ), "Apellido" + ( i + 1 ), hoy.minusYears( 24 ), "padel" + ( i + 1 ) + "@seneca.edu.co", "322000000" + i, "padel" + ( i + 1 ), "clave", "AFI-10" + ( i + 1 ), hoy.minusYears( 2 ) );
			club.registrarPersona( padelista );
			club.inscribirEnAcademia( padelista, CatalogoReglas.getDisciplina( "Padel" ), Nivel.INTERMEDIO, hoy.minusYears( 2 ) ).setPuntajeRanking( 1100 - i * 30 );
			padelistas[ i ] = padelista;
		}
	}

	/**
	 * Arma los equipos de futbol Sub-15.
	 *
	 * El futbol pide minimo siete jugadores, entonces el equipo completo lleva
	 * ocho y el incompleto lleva cuatro, que es lo que necesita el caso de prueba.
	 *
	 * Los jugadores nacen hace quince anos a proposito: la categoria Sub-15 va de
	 * catorce a quince, y con una fecha fija algun dia cumplirian dieciseis y la
	 * inscripcion empezaria a fallar sola.
	 */
	private void armarEquipos( ) throws ClubException
	{
		equipoCompleto = new Equipo( "EQ-01", "Leones Sub-15", CatalogoReglas.getDeporte( "Futbol" ), Categoria.SUB_15, 18 );
		equipoIncompleto = new Equipo( "EQ-02", "Halcones Sub-15", CatalogoReglas.getDeporte( "Futbol" ), Categoria.SUB_15, 18 );
		otroEquipoCompleto = new Equipo( "EQ-03", "Condores Sub-15", CatalogoReglas.getDeporte( "Futbol" ), Categoria.SUB_15, 18 );
		club.agregarEquipo( equipoCompleto );
		club.agregarEquipo( equipoIncompleto );
		club.agregarEquipo( otroEquipoCompleto );

		llenarEquipo( equipoCompleto, 8, 200 );
		llenarEquipo( equipoIncompleto, 4, 300 );
		llenarEquipo( otroEquipoCompleto, 8, 400 );
	}

	private void llenarEquipo( Equipo equipo, int cuantos, int baseDocumento ) throws ClubException
	{
		for( int i = 0; i < cuantos; i++ )
		{
			String documento = String.valueOf( baseDocumento + i );
			AfiliadoConjunto jugador = new AfiliadoConjunto( documento, "Jugador" + documento, "Apellido" + documento, hoy.minusYears( 15 ), "jug" + documento + "@seneca.edu.co", "320" + documento, "jug" + documento, "clave", "AFC-" + documento, hoy.minusYears( 1 ) );
			club.registrarPersona( jugador );
			equipo.inscribirJugador( jugador, i + 1, "Mediocampista", hoy.minusYears( 1 ) );
		}
	}

	private void armarInstalacionesYProductos( )
	{
		canchaTenis = new Instalacion( "INS-01", "Cancha de tenis 1", CatalogoReglas.getDisciplina( "Tenis" ), 4, false );
		club.agregarInstalacion( canchaTenis );

		raqueta = new ArticuloDeportivo( "ART-01", "Raqueta de tenis Pro", 40000.0, 20, "Raquetas", "Wilson", "Unica" );
		club.agregarProducto( raqueta );
	}

	// de aqui para abajo van las ayudas para armar torneos

	/**
	 * Crea el torneo T1 del documento de pruebas: competitivo, tenis individual,
	 * nivel Intermedio, diez cupos, tarifa de cincuenta mil y premio del 80% de
	 * lo recaudado.
	 *
	 * @return el torneo T1 ya registrado en el club
	 * @throws ClubException si el torneo no se puede crear
	 */
	public TorneoCompetitivo crearT1( ) throws ClubException
	{
		return crearT1( "T1", 10 );
	}

	public TorneoCompetitivo crearT1( String codigo, int cupos ) throws ClubException
	{
		TorneoCompetitivo torneo = new TorneoCompetitivo( codigo, "Abierto de tenis Intermedio", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, fechaTorneo, cupos, TARIFA, PORCENTAJE_PREMIO );
		club.crearTorneo( torneo );
		return torneo;
	}

	/**
	 * Crea un torneo recreativo de dobles de padel.
	 *
	 * @return el torneo ya registrado en el club
	 * @throws ClubException si el torneo no se puede crear
	 */
	public TorneoRecreativo crearRecreativoDobles( ) throws ClubException
	{
		TorneoRecreativo torneo = new TorneoRecreativo( "T2", "Copa recreativa de dobles", Modalidad.DOBLES, "Padel", Nivel.INTERMEDIO, null, fechaTorneo, 8, PORCENTAJE_BONO );
		club.crearTorneo( torneo );
		return torneo;
	}

	/**
	 * Crea un torneo recreativo individual de tenis. Sirve para el caso del
	 * empleado que gana un recreativo y si recibe bono.
	 *
	 * @return el torneo ya registrado en el club
	 * @throws ClubException si el torneo no se puede crear
	 */
	public TorneoRecreativo crearRecreativoIndividual( ) throws ClubException
	{
		TorneoRecreativo torneo = new TorneoRecreativo( "T4", "Copa recreativa de tenis", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, fechaTorneo, 4, PORCENTAJE_BONO );
		club.crearTorneo( torneo );
		return torneo;
	}

	/**
	 * Crea un torneo de conjunto de futbol Sub-15.
	 *
	 * @return el torneo ya registrado en el club
	 * @throws ClubException si el torneo no se puede crear
	 */
	public TorneoCompetitivo crearTorneoDeConjunto( ) throws ClubException
	{
		TorneoCompetitivo torneo = new TorneoCompetitivo( "T3", "Torneo de futbol Sub-15", Modalidad.CONJUNTO, "Futbol", null, Categoria.SUB_15, fechaTorneo, 4, 80000.0, 0.7 );
		club.crearTorneo( torneo );
		return torneo;
	}

	/**
	 * Inscribe los primeros tenistas del ranking.
	 *
	 * @param torneo el torneo al que se inscriben
	 * @param cuantos cuantos tenistas se inscriben, empezando por el mejor del ranking
	 * @throws ClubException si alguna inscripcion no se puede hacer
	 */
	public void inscribirTenistas( Torneo torneo, int cuantos ) throws ClubException
	{
		for( int i = 0; i < cuantos; i++ )
		{
			club.inscribirEnTorneo( torneo, tenistas[ i ], hoy );
		}
	}

	/**
	 * Juega el torneo completo: registra todos los encuentros hasta que no quede
	 * ninguno pendiente, y en todos gana el primer participante. Como cada
	 * resultado puede abrir la ronda siguiente, toca volver a mirar la lista
	 * despues de cada vuelta.
	 *
	 * @param torneo el torneo que se va a jugar completo
	 * @throws ClubException si algun resultado no se puede registrar
	 */
	public void jugarTorneoCompleto( Torneo torneo ) throws ClubException
	{
		while( torneo.contarEncuentrosPendientes( ) > 0 )
		{
			Encuentro pendiente = buscarPendiente( torneo );
			club.registrarResultadoEncuentro( torneo, pendiente, 3, 1 );
		}
	}

	/**
	 * Busca un encuentro al que todavia no le han puesto resultado.
	 *
	 * @param torneo el torneo que se esta revisando
	 * @return el primer encuentro pendiente, o null si ya se jugaron todos
	 */
	public Encuentro buscarPendiente( Torneo torneo )
	{
		for( Encuentro encuentro : torneo.getEncuentros( ) )
		{
			if( !encuentro.isJugado( ) )
			{
				return encuentro;
			}
		}
		return null;
	}

	/**
	 * Le pone un turno a un empleado el dia del torneo. Traduce la fecha al dia
	 * de la semana y a la semana que usa el turno, que es la conversion de la
	 * decision D10.
	 *
	 * @param codigo el codigo del turno
	 * @param empleado el empleado al que se le asigna
	 * @return el turno creado
	 */
	public Turno ponerTurnoElDiaDelTorneo( String codigo, uniandes.dpoo.cds.modelo.personas.Empleado empleado )
	{
		Turno turno = new Turno( codigo, empleado, Turno.diaSemanaDe( fechaTorneo ), Turno.semanaDe( fechaTorneo ), LocalTime.of( 8, 0 ), LocalTime.of( 12, 0 ) );
		club.agregarTurno( turno );
		return turno;
	}
}
