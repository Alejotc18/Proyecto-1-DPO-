package uniandes.dpoo.cds.pruebas.unitarias;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.entrenamiento.Turno;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.modelo.torneos.EstadoTorneo;
import uniandes.dpoo.cds.modelo.torneos.Modalidad;

/**
 * Pruebas del turno y de los enumerados de torneos.
 *
 * El turno traduce una fecha de calendario al dia de la semana y a la semana
 * con la que el club los guarda. Esa es la decision D10. Es una cuenta
 * chiquita, pero si se equivoca un empleado se podria inscribir a un torneo el
 * dia que le toca trabajar.
 */
public class TurnoYEnumsTest
{
	private Entrenador entrenador;

	@BeforeEach
	public void prepararEntrenador( )
	{
		entrenador = new Entrenador( "EMP-1", "Carlos", "Rendon", LocalDate.now( ).minusYears( 35 ), "c@seneca.edu.co", "300", "crendon", "clave", "EMP-01", LocalDate.now( ).minusYears( 4 ), "Tenis", 8 );
	}

	@Test
	@DisplayName( "la fecha se traduce al dia de la semana en espanol" )
	public void traduccionDelDia( )
	{
		// El 5 de diciembre de 2026 cae sabado.
		assertEquals( "Sabado", Turno.diaSemanaDe( LocalDate.of( 2026, 12, 5 ) ) );
		assertEquals( "Lunes", Turno.diaSemanaDe( LocalDate.of( 2026, 12, 7 ) ) );
		assertEquals( "Domingo", Turno.diaSemanaDe( LocalDate.of( 2026, 12, 6 ) ) );
	}

	@Test
	@DisplayName( "la fecha se traduce al identificador de la semana" )
	public void traduccionDeLaSemana( )
	{
		assertEquals( "2026-W49", Turno.semanaDe( LocalDate.of( 2026, 12, 5 ) ) );
		assertEquals( "2026-W50", Turno.semanaDe( LocalDate.of( 2026, 12, 7 ) ), "el lunes ya es otra semana" );
	}

	@Test
	@DisplayName( "el turno cubre la fecha que le corresponde y ninguna otra" )
	public void turnoQueCubreUnaFecha( )
	{
		// el turno se guarda como dia de la semana y semana, no como fecha, y por
		// eso toca traducirla antes de preguntarle si cubre ese dia
		LocalDate dia = LocalDate.of( 2026, 12, 5 );
		Turno turno = new Turno( "TUR-01", entrenador, Turno.diaSemanaDe( dia ), Turno.semanaDe( dia ), LocalTime.of( 8, 0 ), LocalTime.of( 12, 0 ) );

		assertTrue( turno.cubre( dia ) );
		assertFalse( turno.cubre( dia.plusDays( 1 ) ), "el domingo ya no le toca" );
		assertFalse( turno.cubre( dia.plusWeeks( 1 ) ), "el sabado de la otra semana tampoco" );
		assertFalse( turno.cubre( null ) );
	}

	@Test
	@DisplayName( "un turno que ya no esta vigente no cubre ninguna fecha" )
	public void turnoNoVigente( )
	{
		LocalDate dia = LocalDate.of( 2026, 12, 5 );
		Turno turno = new Turno( "TUR-01", entrenador, Turno.diaSemanaDe( dia ), Turno.semanaDe( dia ), LocalTime.of( 8, 0 ), LocalTime.of( 12, 0 ) );
		turno.setVigente( false );

		assertFalse( turno.cubre( dia ) );
	}

	@Test
	@DisplayName( "el empleado responde si tiene turno un dia puntual" )
	public void empleadoConTurnoEseDia( )
	{
		LocalDate dia = LocalDate.of( 2026, 12, 5 );
		Turno turno = new Turno( "TUR-01", entrenador, Turno.diaSemanaDe( dia ), Turno.semanaDe( dia ), LocalTime.of( 8, 0 ), LocalTime.of( 12, 0 ) );
		entrenador.agregarTurno( turno );

		assertTrue( entrenador.tieneTurnoEn( dia ) );
		assertFalse( entrenador.tieneTurnoEn( dia.plusDays( 1 ) ) );
		assertEquals( 1, entrenador.getTurnosEn( dia ).size( ) );
		assertEquals( 0, entrenador.getTurnosEn( dia.plusDays( 1 ) ).size( ) );
	}

	@Test
	@DisplayName( "todo empleado nace con su codigo de descuento" )
	public void codigoDeDescuentoDelEmpleado( )
	{
		assertEquals( "DESC-EMP-01", entrenador.getCodigoDescuento( ).getCodigo( ) );
		assertTrue( entrenador.getCodigoDescuento( ).isActivo( ) );
		assertEquals( 0.15, entrenador.getCodigoDescuento( ).getPorcentajeAplicable( true ), 0.001 );
		assertEquals( 0.08, entrenador.getCodigoDescuento( ).getPorcentajeAplicable( false ), 0.001 );
	}

	@Test
	@DisplayName( "la modalidad sabe cuanta gente ocupa un cupo" )
	public void enumeradoDeModalidad( )
	{
		assertEquals( 1, Modalidad.INDIVIDUAL.getPersonasPorCupo( ) );
		assertEquals( 2, Modalidad.DOBLES.getPersonasPorCupo( ) );
		assertEquals( 1, Modalidad.CONJUNTO.getPersonasPorCupo( ), "el equipo entero es un cupo" );
		assertTrue( Modalidad.INDIVIDUAL.esIndividual( ) );
		assertTrue( Modalidad.CONJUNTO.esDeEquipos( ) );
		assertFalse( Modalidad.DOBLES.esIndividual( ) );
	}

	@Test
	@DisplayName( "la modalidad y el estado se pueden buscar por su nombre" )
	public void busquedaPorNombre( )
	{
		assertEquals( Modalidad.DOBLES, Modalidad.porNombre( "Dobles" ) );
		assertEquals( Modalidad.DOBLES, Modalidad.porNombre( "dobles" ), "no distingue mayusculas" );
		assertNull( Modalidad.porNombre( "Triples" ) );
		assertEquals( EstadoTorneo.EN_CURSO, EstadoTorneo.porNombre( "En curso" ) );
		assertEquals( EstadoTorneo.INSCRIPCIONES_ABIERTAS, EstadoTorneo.porNombre( "Inscripciones abiertas" ) );
		assertNull( EstadoTorneo.porNombre( "Suspendido" ) );
	}

	@Test
	@DisplayName( "cada estado sabe que deja hacer y que no" )
	public void reglasDeLosEstados( )
	{
		assertTrue( EstadoTorneo.INSCRIPCIONES_ABIERTAS.admiteInscripciones( ) );
		assertTrue( EstadoTorneo.INSCRIPCIONES_ABIERTAS.admiteCambios( ) );
		assertFalse( EstadoTorneo.EN_CURSO.admiteInscripciones( ) );
		assertFalse( EstadoTorneo.EN_CURSO.admiteCambios( ) );
		assertTrue( EstadoTorneo.EN_CURSO.estaEnJuego( ) );
		assertFalse( EstadoTorneo.FINALIZADO.estaEnJuego( ) );
		assertFalse( EstadoTorneo.CANCELADO.admiteInscripciones( ) );
	}

	@Test
	@DisplayName( "el nivel declarado del empleado es el que usa el torneo" )
	public void nivelDeclaradoDelEmpleado( )
	{
		entrenador.setNivelDeclarado( Nivel.INTERMEDIO );

		assertEquals( Nivel.INTERMEDIO, entrenador.getNivelEn( "Tenis" ) );
		assertEquals( Nivel.INTERMEDIO, entrenador.getNivelEn( "Padel" ), "es el mismo para toda disciplina" );
		assertEquals( 0.0, entrenador.getPuntajeEn( "Tenis" ), 0.01, "no tiene ranking del club" );
		assertTrue( entrenador.esEmpleadoDelClub( ) );
	}
}
