package uniandes.dpoo.cds.pruebas.unitarias;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.EquipoIncompletoException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.personas.Administrador;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.modelo.personas.Estudiante;
import uniandes.dpoo.cds.modelo.personas.Externo;
import uniandes.dpoo.cds.modelo.torneos.Modalidad;
import uniandes.dpoo.cds.modelo.torneos.ParticipanteEquipo;
import uniandes.dpoo.cds.modelo.torneos.ParticipanteIndividual;
import uniandes.dpoo.cds.modelo.torneos.ParticipantePareja;
import uniandes.dpoo.cds.reglas.CatalogoReglas;

/**
 * Pruebas de los participantes.
 *
 * Un cupo del torneo es un participante, sin importar cuanta gente lleve
 * adentro. Esa es la decision D3. Aqui se prueban las tres formas de
 * participar: solo, en pareja y con equipo.
 */
public class ParticipanteTest
{
	private LocalDate hoy = LocalDate.now( );

	private Estudiante estudiante( int numero, Nivel nivel )
	{
		return new Estudiante( "E" + numero, "Nombre" + numero, "Apellido" + numero, hoy.minusYears( 20 ), "e" + numero + "@seneca.edu.co", "300", "login" + numero, "clave", "EST-" + numero, "Sistemas", nivel );
	}

	@Test
	@DisplayName( "el participante individual lleva una sola persona y es de modalidad Individual" )
	public void participanteIndividual( ) throws ClubException
	{
		// un jugador solo tambien es un participante, igual que una pareja o un
		// equipo entero: para el torneo los tres se ven igual
		Estudiante jugador = estudiante( 1, Nivel.INTERMEDIO );
		ParticipanteIndividual participante = new ParticipanteIndividual( jugador );

		assertEquals( 1, participante.getIntegrantes( ).size( ) );
		assertEquals( Modalidad.INDIVIDUAL, participante.getModalidad( ) );
		assertTrue( participante.incluye( jugador ) );
		assertEquals( Nivel.INTERMEDIO, participante.getNivelEn( "Tenis" ) );
		assertNull( participante.getCategoria( ), "los individuales no tienen categoria" );
	}

	@Test
	@DisplayName( "el administrador no puede competir en torneos" )
	public void elAdministradorNoCompite( )
	{
		Administrador admin = new Administrador( "1", "Lucia", "Moreno", hoy.minusYears( 40 ), "l@seneca.edu.co", "300", "admin", "clave", "ADM-01", hoy.minusYears( 5 ) );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> new ParticipanteIndividual( admin ) );
	}

	@Test
	@DisplayName( "la pareja ocupa un cupo pero lleva dos integrantes" )
	public void parejaDeDobles( ) throws ClubException
	{
		Estudiante uno = estudiante( 1, Nivel.INTERMEDIO );
		Externo dos = new Externo( "X1", "Patricia", "Linares", hoy.minusYears( 28 ), "p@correo.com", "300", "plinares", "clave", "contacto", Nivel.INTERMEDIO );
		ParticipantePareja pareja = new ParticipantePareja( uno, dos );

		assertEquals( 2, pareja.getIntegrantes( ).size( ) );
		assertEquals( Modalidad.DOBLES, pareja.getModalidad( ) );
		assertTrue( pareja.incluye( uno ) );
		assertTrue( pareja.incluye( dos ), "buscar a cualquiera de los dos encuentra el cupo entero" );
	}

	@Test
	@DisplayName( "si los dos de la pareja son de niveles distintos la pareja no tiene nivel" )
	public void parejaConNivelesDistintos( ) throws ClubException
	{
		ParticipantePareja pareja = new ParticipantePareja( estudiante( 1, Nivel.INTERMEDIO ), estudiante( 2, Nivel.AVANZADO ) );

		assertNull( pareja.getNivelEn( "Tenis" ), "y por eso el torneo le rechaza la inscripcion" );
	}

	@Test
	@DisplayName( "una pareja no puede ser la misma persona dos veces" )
	public void parejaRepetida( )
	{
		Estudiante uno = estudiante( 1, Nivel.INTERMEDIO );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> new ParticipantePareja( uno, uno ) );
	}

	@Test
	@DisplayName( "a la pareja le cuenta el mejor puntaje de los dos" )
	public void puntajeDeLaPareja( ) throws ClubException
	{
		// Los estudiantes no tienen ranking del club, entonces los dos valen
		// cero y el mejor de los dos tambien es cero.
		ParticipantePareja pareja = new ParticipantePareja( estudiante( 1, Nivel.INTERMEDIO ), estudiante( 2, Nivel.INTERMEDIO ) );

		assertEquals( 0.0, pareja.getPuntajeEn( "Tenis" ), 0.01 );
	}

	@Test
	@DisplayName( "con un empleado adentro el participante queda marcado como de empleados" )
	public void participanteConEmpleado( ) throws ClubException
	{
		Entrenador entrenador = new Entrenador( "EMP-1", "Carlos", "Rendon", hoy.minusYears( 35 ), "c@seneca.edu.co", "300", "crendon", "clave", "EMP-01", hoy.minusYears( 4 ), "Tenis", 8 );
		entrenador.setNivelDeclarado( Nivel.INTERMEDIO );

		assertTrue( new ParticipanteIndividual( entrenador ).tieneEmpleados( ) );
		assertTrue( new ParticipantePareja( entrenador, estudiante( 1, Nivel.INTERMEDIO ) ).tieneEmpleados( ), "basta con que uno lo sea" );
		assertFalse( new ParticipanteIndividual( estudiante( 1, Nivel.INTERMEDIO ) ).tieneEmpleados( ) );
	}

	@Test
	@DisplayName( "un equipo completo si puede competir y uno incompleto no" )
	public void equipoCompletoEIncompleto( ) throws ClubException
	{
		Equipo completo = armarEquipo( "EQ-01", "Leones", 8, 100 );
		Equipo incompleto = armarEquipo( "EQ-02", "Halcones", 4, 200 );

		new ParticipanteEquipo( completo ).validarPuedeCompetir( );

		assertThrows( EquipoIncompletoException.class, ( ) -> new ParticipanteEquipo( incompleto ).validarPuedeCompetir( ) );
	}

	@Test
	@DisplayName( "el equipo va por categoria y no por nivel" )
	public void equipoVaPorCategoria( ) throws ClubException
	{
		ParticipanteEquipo participante = new ParticipanteEquipo( armarEquipo( "EQ-01", "Leones", 8, 100 ) );

		assertEquals( Categoria.SUB_15, participante.getCategoria( ) );
		assertNull( participante.getNivelEn( "Futbol" ), "los equipos no tienen nivel de juego" );
		assertEquals( Modalidad.CONJUNTO, participante.getModalidad( ) );
		assertEquals( 8, participante.getIntegrantes( ).size( ) );
	}

	@Test
	@DisplayName( "el puntaje de un equipo son sus partidos internos ganados" )
	public void puntajeDelEquipo( ) throws ClubException
	{
		Equipo equipo = armarEquipo( "EQ-01", "Leones", 8, 100 );
		equipo.registrarVictoria( );
		equipo.registrarVictoria( );
		equipo.registrarVictoria( );

		assertEquals( 3.0, new ParticipanteEquipo( equipo ).getPuntajeEn( "Futbol" ), 0.01 );
	}

	private Equipo armarEquipo( String codigo, String nombre, int cuantos, int baseDocumento ) throws ClubException
	{
		Equipo equipo = new Equipo( codigo, nombre, CatalogoReglas.getDeporte( "Futbol" ), Categoria.SUB_15, 18 );
		for( int i = 0; i < cuantos; i++ )
		{
			String documento = String.valueOf( baseDocumento + i );
			AfiliadoConjunto jugador = new AfiliadoConjunto( documento, "Jugador" + documento, "Apellido", hoy.minusYears( 15 ), "j" + documento + "@seneca.edu.co", "320", "jug" + documento, "clave", "AFC-" + documento, hoy.minusYears( 1 ) );
			equipo.inscribirJugador( jugador, i + 1, "Mediocampista", hoy.minusYears( 1 ) );
		}
		return equipo;
	}
}
