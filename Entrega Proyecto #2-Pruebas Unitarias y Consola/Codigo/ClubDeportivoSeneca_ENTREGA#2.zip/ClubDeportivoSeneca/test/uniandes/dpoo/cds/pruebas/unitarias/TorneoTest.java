package uniandes.dpoo.cds.pruebas.unitarias;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.CupoLlenoException;
import uniandes.dpoo.cds.excepciones.NivelIncompatibleException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.personas.Estudiante;
import uniandes.dpoo.cds.modelo.torneos.Encuentro;
import uniandes.dpoo.cds.modelo.torneos.EstadoTorneo;
import uniandes.dpoo.cds.modelo.torneos.Modalidad;
import uniandes.dpoo.cds.modelo.torneos.Participante;
import uniandes.dpoo.cds.modelo.torneos.ParticipanteIndividual;
import uniandes.dpoo.cds.modelo.torneos.Torneo;
import uniandes.dpoo.cds.modelo.torneos.TorneoCompetitivo;

/**
 * Pruebas de la clase Torneo sola.
 *
 * Aqui no se usa el club ni los archivos: se arma un torneo pelado y se le
 * piden sus propias reglas. Esa es la idea de una prueba unitaria, que si falla
 * uno sepa que el error esta en esta clase y en ninguna otra.
 *
 * Los participantes son estudiantes porque es el rol mas simple que puede
 * competir: no tienen ranking ni equipo ni turnos, entonces no meten ruido.
 */
public class TorneoTest
{
	private TorneoCompetitivo torneo;

	private LocalDate fechaTorneo;

	// lo que va marcado con @BeforeEach se vuelve a correr antes de cada
	// prueba, asi que cada una arranca con un torneo nuevo y vacio
	@BeforeEach
	public void prepararTorneo( ) throws ClubException
	{
		fechaTorneo = LocalDate.now( ).plusDays( 20 );
		torneo = new TorneoCompetitivo( "T1", "Abierto de prueba", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, fechaTorneo, 10, 50000.0, 0.8 );
	}

	/**
	 * Arma un estudiante de nivel Intermedio.
	 *
	 * @param numero el numero que lo distingue de los demas
	 * @return un estudiante listo para inscribirse
	 */
	private Estudiante estudiante( int numero )
	{
		return new Estudiante( "E" + numero, "Nombre" + numero, "Apellido" + numero, LocalDate.now( ).minusYears( 20 ), "e" + numero + "@seneca.edu.co", "300", "login" + numero, "clave", "EST-" + numero, "Sistemas", Nivel.INTERMEDIO );
	}

	private Participante inscribir( int numero ) throws ClubException
	{
		ParticipanteIndividual participante = new ParticipanteIndividual( estudiante( numero ) );
		torneo.inscribir( participante, LocalDate.now( ), false );
		return participante;
	}

	@Test
	@DisplayName( "el 20% de los cupos se redondea siempre hacia arriba" )
	public void calculoDeCuposPreferenciales( )
	{
		// assertEquals compara lo que esperamos con lo que devolvio el metodo.
		// El texto del final solo sale cuando la prueba falla, para saber cual fue
		assertEquals( 2, Torneo.calcularCuposPreferenciales( 10 ), "10 cupos" );
		assertEquals( 2, Torneo.calcularCuposPreferenciales( 7 ), "7 cupos: 1,4 sube a 2" );
		assertEquals( 4, Torneo.calcularCuposPreferenciales( 16 ), "16 cupos" );
		assertEquals( 1, Torneo.calcularCuposPreferenciales( 2 ), "2 cupos: 0,4 sube a 1" );
		assertEquals( 1, Torneo.calcularCuposPreferenciales( 5 ), "5 cupos" );
	}

	// assertThrows dice: esto de aqui tiene que reventar con esa excepcion.
	// Si no revienta, la prueba falla
	@Test
	@DisplayName( "un torneo de un solo cupo no se puede crear" )
	public void torneoDeUnSoloCupo( )
	{
		assertThrows( OperacionNoPermitidaException.class, ( ) -> new TorneoCompetitivo( "T9", "Torneo imposible", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, fechaTorneo, 1, 50000.0, 0.8 ) );
	}

	@Test
	@DisplayName( "el porcentaje del premio tiene que estar entre 1% y 100%" )
	public void porcentajeDePremioFueraDeRango( )
	{
		assertThrows( OperacionNoPermitidaException.class, ( ) -> new TorneoCompetitivo( "T9", "Premio de mas", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, fechaTorneo, 10, 50000.0, 1.5 ) );
		assertThrows( OperacionNoPermitidaException.class, ( ) -> new TorneoCompetitivo( "T9", "Premio de cero", Modalidad.INDIVIDUAL, "Tenis", Nivel.INTERMEDIO, null, fechaTorneo, 10, 50000.0, 0.0 ) );
	}

	@Test
	@DisplayName( "la cuenta de cupos libres baja con cada inscripcion" )
	public void cuentaDeCuposLibres( ) throws ClubException
	{
		assertEquals( 2, torneo.getCuposPreferencialesDisponibles( ) );
		assertEquals( 8, torneo.getCuposRegularesDisponibles( ) );

		inscribir( 1 );
		inscribir( 2 );

		assertEquals( 2, torneo.getCuposPreferencialesDisponibles( ), "entraron por regular" );
		assertEquals( 6, torneo.getCuposRegularesDisponibles( ) );
	}

	@Test
	@DisplayName( "cuando se llenan los regulares la siguiente inscripcion revienta" )
	public void cuposRegularesLlenos( ) throws ClubException
	{
		for( int i = 1; i <= 8; i++ )
		{
			inscribir( i );
		}

		assertThrows( CupoLlenoException.class, ( ) -> inscribir( 9 ) );
	}

	@Test
	@DisplayName( "un participante de otro nivel no entra" )
	public void nivelQueNoCoincide( )
	{
		Estudiante avanzado = new Estudiante( "E99", "Avanzado", "Apellido", LocalDate.now( ).minusYears( 20 ), "a@seneca.edu.co", "300", "avanzado", "clave", "EST-99", "Sistemas", Nivel.AVANZADO );

		assertThrows( NivelIncompatibleException.class, ( ) -> torneo.inscribir( new ParticipanteIndividual( avanzado ), LocalDate.now( ), false ) );
	}

	@Test
	@DisplayName( "liberar pasa a regulares los preferenciales que sobraron" )
	public void liberarCuposPreferenciales( ) throws ClubException
	{
		inscribir( 1 );

		int liberados = torneo.liberarCuposPreferenciales( );

		assertEquals( 2, liberados, "ninguno de los dos preferenciales se uso" );
		assertEquals( 0, torneo.getCuposPreferenciales( ) );
		assertEquals( 10, torneo.getCuposRegulares( ) );
	}

	@Test
	@DisplayName( "iniciar con 8 participantes deja 4 cruces y el torneo En curso" )
	public void iniciarArmaLaPrimeraRonda( ) throws ClubException
	{
		for( int i = 1; i <= 8; i++ )
		{
			inscribir( i );
		}

		torneo.iniciar( );

		assertEquals( EstadoTorneo.EN_CURSO, torneo.getEstado( ) );
		assertEquals( 4, torneo.getEncuentrosDeRonda( 1 ).size( ) );
	}

	@Test
	@DisplayName( "con numero impar de participantes uno pasa derecho a la ronda siguiente" )
	public void numeroImparDeParticipantes( ) throws ClubException
	{
		Participante uno = inscribir( 1 );
		Participante dos = inscribir( 2 );
		Participante tres = inscribir( 3 );
		torneo.iniciar( );

		assertEquals( 1, torneo.getEncuentrosDeRonda( 1 ).size( ), "solo se pudo armar un cruce" );

		torneo.registrarResultado( torneo.getEncuentrosDeRonda( 1 ).get( 0 ), 3, 1 );

		assertEquals( 1, torneo.getEncuentrosDeRonda( 2 ).size( ), "el que paso derecho juega la segunda ronda" );
		Encuentro segunda = torneo.getEncuentrosDeRonda( 2 ).get( 0 );
		assertSame( uno, segunda.getParticipanteA( ), "gano el primero del cruce" );
		assertSame( tres, segunda.getParticipanteB( ), "y lo espera el que descanso" );
		assertEquals( 1, torneo.buscarPosicion( dos ).getPerdidos( ) );
	}

	@Test
	@DisplayName( "el campeon es el que gana el encuentro de la ultima ronda" )
	public void campeonDelTorneo( ) throws ClubException
	{
		Participante uno = inscribir( 1 );
		inscribir( 2 );
		inscribir( 3 );
		inscribir( 4 );
		torneo.iniciar( );
		while( torneo.contarEncuentrosPendientes( ) > 0 )
		{
			for( Encuentro encuentro : torneo.getEncuentrosDeRonda( rondaPendiente( ) ) )
			{
				if( !encuentro.isJugado( ) )
				{
					torneo.registrarResultado( encuentro, 3, 1 );
				}
			}
		}

		assertSame( uno, torneo.getCampeon( ) );
		assertEquals( 6, torneo.buscarPosicion( uno ).getPuntos( ), "gano dos encuentros" );
	}

	private int rondaPendiente( )
	{
		for( Encuentro encuentro : torneo.getEncuentros( ) )
		{
			if( !encuentro.isJugado( ) )
			{
				return encuentro.getRonda( );
			}
		}
		return 1;
	}

	@Test
	@DisplayName( "finalizar con encuentros pendientes deja el torneo En curso" )
	public void finalizarConPendientes( ) throws ClubException
	{
		inscribir( 1 );
		inscribir( 2 );
		inscribir( 3 );
		inscribir( 4 );
		torneo.iniciar( );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> torneo.finalizar( ) );
		assertEquals( EstadoTorneo.EN_CURSO, torneo.getEstado( ), "no quedo cerrado a medias" );
	}

	@Test
	@DisplayName( "cancelar un torneo lo cierra y le suelta las inscripciones" )
	public void cancelarTorneo( ) throws ClubException
	{
		inscribir( 1 );
		inscribir( 2 );

		torneo.cancelar( );

		assertEquals( EstadoTorneo.CANCELADO, torneo.getEstado( ) );
		assertTrue( torneo.getInscripciones( ).isEmpty( ) );
		assertThrows( OperacionNoPermitidaException.class, ( ) -> torneo.cancelar( ), "y ya no se puede volver a cancelar" );
	}

	@Test
	@DisplayName( "un torneo cancelado no admite mas inscripciones" )
	public void inscribirEnTorneoCancelado( ) throws ClubException
	{
		torneo.cancelar( );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> inscribir( 1 ) );
	}

	@Test
	@DisplayName( "el empleado no paga pero el estudiante si: la tarifa va por integrante que paga" )
	public void valorAPagarPorCupo( ) throws ClubException
	{
		ParticipanteIndividual soloEstudiante = new ParticipanteIndividual( estudiante( 1 ) );

		assertEquals( 50000.0, torneo.getValorAPagar( soloEstudiante ), 0.01 );
		assertFalse( soloEstudiante.tieneEmpleados( ) );
	}
}
