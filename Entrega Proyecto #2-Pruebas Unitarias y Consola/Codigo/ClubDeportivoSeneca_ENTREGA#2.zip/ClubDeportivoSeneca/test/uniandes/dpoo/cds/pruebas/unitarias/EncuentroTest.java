package uniandes.dpoo.cds.pruebas.unitarias;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.personas.Estudiante;
import uniandes.dpoo.cds.modelo.torneos.Encuentro;
import uniandes.dpoo.cds.modelo.torneos.Participante;
import uniandes.dpoo.cds.modelo.torneos.ParticipanteIndividual;
import uniandes.dpoo.cds.modelo.torneos.PosicionTorneo;

/**
 * Pruebas del encuentro y de la tabla de posiciones.
 *
 * El encuentro guarda el marcador y dice quien gano. La posicion lleva la
 * cuenta de ese participante en la tabla. Son las dos clases mas chiquitas de
 * los torneos, por eso se prueban juntas.
 */
public class EncuentroTest
{
	private Participante local;

	private Participante visitante;

	private Encuentro encuentro;

	@BeforeEach
	public void prepararEncuentro( ) throws OperacionNoPermitidaException
	{
		local = new ParticipanteIndividual( competidor( 1 ) );
		visitante = new ParticipanteIndividual( competidor( 2 ) );
		encuentro = new Encuentro( "T1-R1-1", 1, local, visitante );
	}

	private Estudiante competidor( int numero )
	{
		return new Estudiante( "E" + numero, "Nombre" + numero, "Apellido" + numero, LocalDate.now( ).minusYears( 20 ), "e" + numero + "@seneca.edu.co", "300", "login" + numero, "clave", "EST-" + numero, "Sistemas", Nivel.INTERMEDIO );
	}

	@Test
	@DisplayName( "un encuentro recien creado no tiene ganador" )
	public void encuentroSinJugar( )
	{
		// assertFalse pide que sea falso y assertNull pide que no haya nada
		assertFalse( encuentro.isJugado( ) );
		assertNull( encuentro.getGanador( ), "todavia no hay ganador" );
		assertNull( encuentro.getPerdedor( ) );
	}

	@Test
	@DisplayName( "el que mete mas tantos es el ganador" )
	public void resultadoValido( ) throws OperacionNoPermitidaException
	{
		encuentro.registrarResultado( 3, 1 );

		// assertSame es mas estricto que assertEquals: pide que sea el mismo
		// objeto, no uno igual
		assertTrue( encuentro.isJugado( ) );
		assertSame( local, encuentro.getGanador( ) );
		assertSame( visitante, encuentro.getPerdedor( ) );
	}

	@Test
	@DisplayName( "tambien gana el visitante cuando le mete mas al local" )
	public void ganaElVisitante( ) throws OperacionNoPermitidaException
	{
		encuentro.registrarResultado( 0, 2 );

		assertSame( visitante, encuentro.getGanador( ) );
	}

	@Test
	@DisplayName( "un resultado no se puede volver a registrar" )
	public void resultadoRepetido( ) throws OperacionNoPermitidaException
	{
		encuentro.registrarResultado( 3, 1 );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> encuentro.registrarResultado( 0, 5 ) );
		assertEquals( 3, encuentro.getMarcadorA( ) );
		assertEquals( 1, encuentro.getMarcadorB( ) );
	}

	@Test
	@DisplayName( "los marcadores negativos no se aceptan" )
	public void marcadorNegativo( )
	{
		assertThrows( OperacionNoPermitidaException.class, ( ) -> encuentro.registrarResultado( -1, 2 ) );
		assertThrows( OperacionNoPermitidaException.class, ( ) -> encuentro.registrarResultado( 2, -3 ) );
		assertFalse( encuentro.isJugado( ) );
	}

	@Test
	@DisplayName( "un encuentro de eliminacion no puede quedar empatado" )
	public void marcadorEmpatado( )
	{
		assertThrows( OperacionNoPermitidaException.class, ( ) -> encuentro.registrarResultado( 2, 2 ) );
		assertFalse( encuentro.isJugado( ) );
	}

	@Test
	@DisplayName( "la victoria suma tres puntos y la derrota ninguno" )
	public void tablaDePosiciones( )
	{
		PosicionTorneo posicion = new PosicionTorneo( local );

		posicion.registrarVictoria( );
		posicion.registrarDerrota( );

		assertEquals( 2, posicion.getJugados( ) );
		assertEquals( 1, posicion.getGanados( ) );
		assertEquals( 1, posicion.getPerdidos( ) );
		assertEquals( PosicionTorneo.PUNTOS_POR_VICTORIA, posicion.getPuntos( ) );
	}

	@Test
	@DisplayName( "el texto del encuentro dice pendiente mientras no se juegue" )
	public void textoDelEncuentro( ) throws OperacionNoPermitidaException
	{
		assertTrue( encuentro.toString( ).contains( "pendiente" ) );

		encuentro.registrarResultado( 3, 1 );

		assertTrue( encuentro.toString( ).contains( "3-1" ) );
		assertTrue( encuentro.toString( ).contains( "gano" ) );
	}
}
