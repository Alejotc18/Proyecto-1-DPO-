package uniandes.dpoo.cds.pruebas.integracion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.CoberturaMinimaException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.excepciones.ReservaNoDisponibleException;
import uniandes.dpoo.cds.logica.Club;
import uniandes.dpoo.cds.modelo.academias.Instalacion;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaFutbol;
import uniandes.dpoo.cds.modelo.deportes.PartidoInterno;
import uniandes.dpoo.cds.modelo.entrenamiento.Convocatoria;
import uniandes.dpoo.cds.modelo.entrenamiento.SesionEntrenamiento;
import uniandes.dpoo.cds.modelo.entrenamiento.SolicitudCambioTurno;
import uniandes.dpoo.cds.modelo.entrenamiento.Turno;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;
import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;
import uniandes.dpoo.cds.pruebas.EscenarioPruebas;
import uniandes.dpoo.cds.reglas.CatalogoReglas;

/**
 * Pruebas de integracion del banco de historias de la Entrega 1. Son los casos
 * CP-51 a CP-63 del documento.
 *
 * Estas no prueban lo nuevo: vuelven a revisar las cinco historias que ya
 * habiamos escrito en la Entrega 1, porque dos se estaban cumpliendo solo a
 * medias y en el Proyecto 2 les hicimos el ajuste. CP-60 y CP-63 son esos dos.
 */
public class BancoEntrega1IntegracionTest
{
	private EscenarioPruebas escenario;

	private Club club;

	private LocalDate hoy;

	@BeforeEach
	public void prepararEscenario( ) throws ClubException
	{
		escenario = new EscenarioPruebas( );
		club = escenario.club;
		hoy = escenario.hoy;
	}

	// historia: el administrador aprueba o rechaza cambios de turno

	@Test
	@DisplayName( "CP-51 con tres entrenadores de turno el cambio se aprueba y el turno queda movido" )
	public void cp51AprobarSinRomperElMinimo( ) throws ClubException
	{
		escenario.ponerTurnoElDiaDelTorneo( "TUR-01", escenario.entrenadorLibre );
		escenario.ponerTurnoElDiaDelTorneo( "TUR-02", escenario.entrenadorDeTurno );
		Turno turno = escenario.ponerTurnoElDiaDelTorneo( "TUR-03", escenario.tercerEntrenador );
		SolicitudCambioTurno solicitud = club.solicitarCambioTurno( "SOL-01", escenario.tercerEntrenador, turno, hoy, "cita medica", "Viernes", LocalTime.of( 14, 0 ), LocalTime.of( 18, 0 ) );

		club.aprobarCambioTurno( solicitud, escenario.admin, hoy );

		assertEquals( SolicitudCambioTurno.APROBADA, solicitud.getEstado( ) );
		assertEquals( "Viernes", turno.getDiaSemana( ), "el turno quedo movido al dia nuevo" );
		assertEquals( LocalTime.of( 14, 0 ), turno.getHoraInicio( ) );
	}

	@Test
	@DisplayName( "CP-52 si el cambio deja al club sin fisioterapeuta no se aprueba y la solicitud sigue pendiente" )
	public void cp52AprobarDejandoCeroFisioterapeutas( ) throws ClubException
	{
		Turno turno = escenario.ponerTurnoElDiaDelTorneo( "TUR-10", escenario.fisioterapeuta );
		SolicitudCambioTurno solicitud = club.solicitarCambioTurno( "SOL-02", escenario.fisioterapeuta, turno, hoy, "viaje", "Sabado", LocalTime.of( 8, 0 ), LocalTime.of( 12, 0 ) );

		assertThrows( CoberturaMinimaException.class, ( ) -> club.aprobarCambioTurno( solicitud, escenario.admin, hoy ) );
		assertTrue( solicitud.estaPendiente( ), "el empleado todavia puede conseguir quien le cubra" );
	}

	@Test
	@DisplayName( "CP-53 el rechazo guarda la observacion del administrador" )
	public void cp53RechazarConObservacion( ) throws ClubException
	{
		Turno turno = escenario.ponerTurnoElDiaDelTorneo( "TUR-11", escenario.entrenadorLibre );
		SolicitudCambioTurno solicitud = club.solicitarCambioTurno( "SOL-03", escenario.entrenadorLibre, turno, hoy, "diligencia", "Jueves", LocalTime.of( 9, 0 ), LocalTime.of( 13, 0 ) );

		club.rechazarCambioTurno( solicitud, escenario.admin, hoy, "sin reemplazo" );

		assertEquals( SolicitudCambioTurno.RECHAZADA, solicitud.getEstado( ) );
		assertEquals( "sin reemplazo", solicitud.getObservacionDecision( ) );
	}

	// historia: el afiliado de conjunto consulta sus sanciones

	@Test
	@DisplayName( "CP-54 con una sola amarilla el jugador sigue habilitado" )
	public void cp54UnaAmarilla( ) throws ClubException
	{
		AfiliadoConjunto jugador = ( AfiliadoConjunto ) escenario.club.buscarPersona( "200" );
		jugarPartidoConTarjetas( jugador, 1, 0 );

		assertEquals( 0, jugador.getSancionesVigentes( ).size( ), "una amarilla no suspende" );
		assertTrue( jugador.estaHabilitado( escenario.equipoCompleto ) );
	}

	@Test
	@DisplayName( "CP-55 con dos amarillas en el mismo partido el jugador queda suspendido" )
	public void cp55DosAmarillas( ) throws ClubException
	{
		AfiliadoConjunto jugador = ( AfiliadoConjunto ) escenario.club.buscarPersona( "200" );
		jugarPartidoConTarjetas( jugador, 2, 0 );

		assertEquals( 1, jugador.getSancionesVigentes( ).size( ) );
		assertFalse( jugador.estaHabilitado( escenario.equipoCompleto ), "sale del equipo mientras dure la sancion" );
	}

	/**
	 * Juega un partido interno en el que un jugador saca tarjetas.
	 *
	 * @param jugador el jugador al que se le cargan las tarjetas
	 * @param amarillas cuantas amarillas saco
	 * @param rojas cuantas rojas saco
	 * @throws ClubException si el partido no se puede registrar
	 */
	private void jugarPartidoConTarjetas( AfiliadoConjunto jugador, int amarillas, int rojas ) throws ClubException
	{
		PartidoInterno partido = new PartidoInterno( "PI-01", hoy, LocalTime.of( 16, 0 ), escenario.equipoCompleto, escenario.otroEquipoCompleto );
		EstadisticaFutbol estadistica = new EstadisticaFutbol( jugador, partido );
		estadistica.setAmarillas( amarillas );
		estadistica.setRojas( rojas );
		partido.agregarEstadistica( estadistica );

		club.registrarPartidoInterno( partido, 2, 1 );
	}

	// historia: el afiliado individual reserva una instalacion

	@Test
	@DisplayName( "CP-56 con cancha libre y cupo la reserva queda registrada" )
	public void cp56ReservaConCupo( ) throws ClubException
	{
		AfiliadoIndividual tenista = escenario.tenistas[ 0 ];

		assertNotNull( club.crearReserva( "RES-01", tenista, escenario.canchaTenis, hoy.plusDays( 2 ), LocalTime.of( 9, 0 ), LocalTime.of( 10, 0 ), 2, "Sencillos" ) );
		assertEquals( 1, club.contarReservasSimultaneas( "Tenis", hoy.plusDays( 2 ), LocalTime.of( 9, 0 ), LocalTime.of( 10, 0 ) ) );
	}

	@Test
	@DisplayName( "CP-57 cuando ya estan ocupadas todas las canchas simultaneas de la disciplina la reserva se rechaza" )
	public void cp57MaximoSimultaneoCopado( ) throws ClubException
	{
		// El club de las pruebas permite dos canchas de la misma disciplina al
		// tiempo, entonces se ocupan las dos y la tercera reserva ya no cabe.
		Instalacion segunda = new Instalacion( "INS-02", "Cancha de tenis 2", CatalogoReglas.getDisciplina( "Tenis" ), 4, false );
		Instalacion tercera = new Instalacion( "INS-03", "Cancha de tenis 3", CatalogoReglas.getDisciplina( "Tenis" ), 4, false );
		club.agregarInstalacion( segunda );
		club.agregarInstalacion( tercera );
		LocalDate dia = hoy.plusDays( 2 );
		club.crearReserva( "RES-01", escenario.tenistas[ 0 ], escenario.canchaTenis, dia, LocalTime.of( 9, 0 ), LocalTime.of( 10, 0 ), 2, "Sencillos" );
		club.crearReserva( "RES-02", escenario.tenistas[ 1 ], segunda, dia, LocalTime.of( 9, 0 ), LocalTime.of( 10, 0 ), 2, "Sencillos" );

		assertThrows( ReservaNoDisponibleException.class, ( ) -> club.crearReserva( "RES-03", escenario.tenistas[ 2 ], tercera, dia, LocalTime.of( 9, 0 ), LocalTime.of( 10, 0 ), 2, "Sencillos" ) );
	}

	// historia: el entrenador registra la asistencia

	@Test
	@DisplayName( "CP-58 en una sesion finalizada la asistencia del convocado si se guarda" )
	public void cp58AsistenciaEnSesionFinalizada( ) throws ClubException
	{
		AfiliadoConjunto jugador = ( AfiliadoConjunto ) club.buscarPersona( "200" );
		SesionEntrenamiento sesion = crearSesionCon( jugador );
		sesion.finalizar( );

		Convocatoria convocatoria = sesion.buscarConvocatoria( jugador );
		convocatoria.registrarAsistencia( Convocatoria.ASISTIO );

		assertTrue( convocatoria.isRegistrada( ) );
		assertEquals( Convocatoria.ASISTIO, convocatoria.getEstadoAsistencia( ) );
	}

	@Test
	@DisplayName( "CP-59 a un afiliado que no fue convocado no se le puede registrar asistencia" )
	public void cp59AfiliadoNoConvocado( ) throws ClubException
	{
		AfiliadoConjunto convocado = ( AfiliadoConjunto ) club.buscarPersona( "200" );
		AfiliadoConjunto ajeno = ( AfiliadoConjunto ) club.buscarPersona( "201" );
		SesionEntrenamiento sesion = crearSesionCon( convocado );
		sesion.finalizar( );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> sesion.buscarConvocatoria( ajeno ) );
	}

	@Test
	@DisplayName( "CP-60 en una sesion que no ha terminado no se puede registrar asistencia (ajuste del Proyecto 2)" )
	public void cp60SesionSinFinalizar( ) throws ClubException
	{
		AfiliadoConjunto jugador = ( AfiliadoConjunto ) club.buscarPersona( "200" );
		SesionEntrenamiento sesion = crearSesionCon( jugador );

		Convocatoria convocatoria = sesion.buscarConvocatoria( jugador );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> convocatoria.registrarAsistencia( Convocatoria.ASISTIO ) );
		assertFalse( convocatoria.isRegistrada( ) );
	}

	/**
	 * Crea una sesion de entrenamiento con un convocado.
	 *
	 * @param jugador el jugador que queda convocado
	 * @return la sesion creada y ya registrada en el club
	 */
	private SesionEntrenamiento crearSesionCon( AfiliadoConjunto jugador )
	{
		SesionEntrenamiento sesion = new SesionEntrenamiento( "SES-01", hoy, LocalTime.of( 15, 0 ), 90, "Tecnica", escenario.tercerEntrenador, escenario.canchaTenis );
		club.agregarSesion( sesion );
		sesion.convocar( jugador );
		return sesion;
	}

	// historia: el fisioterapeuta pide un cambio de turno

	@Test
	@DisplayName( "CP-61 una solicitud con turno nuevo dentro del horario queda pendiente" )
	public void cp61SolicitudValida( ) throws ClubException
	{
		Turno turno = escenario.ponerTurnoElDiaDelTorneo( "TUR-20", escenario.fisioterapeuta );

		SolicitudCambioTurno solicitud = club.solicitarCambioTurno( "SOL-10", escenario.fisioterapeuta, turno, hoy, "estudio", "Miercoles", LocalTime.of( 7, 0 ), LocalTime.of( 11, 0 ) );

		assertTrue( solicitud.estaPendiente( ) );
		assertEquals( "Miercoles", solicitud.getNuevoDiaSemana( ) );
	}

	@Test
	@DisplayName( "CP-62 nadie puede tener dos solicitudes pendientes al tiempo" )
	public void cp62YaTieneUnaPendiente( ) throws ClubException
	{
		Turno turno = escenario.ponerTurnoElDiaDelTorneo( "TUR-21", escenario.fisioterapeuta );
		club.solicitarCambioTurno( "SOL-11", escenario.fisioterapeuta, turno, hoy, "estudio", "Miercoles", LocalTime.of( 7, 0 ), LocalTime.of( 11, 0 ) );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.solicitarCambioTurno( "SOL-12", escenario.fisioterapeuta, turno, hoy, "otra cosa", "Jueves", LocalTime.of( 7, 0 ), LocalTime.of( 11, 0 ) ) );
	}

	@Test
	@DisplayName( "CP-63 un turno nuevo que empieza antes de que el club abra se rechaza (ajuste del Proyecto 2)" )
	public void cp63TurnoFueraDelHorario( ) throws ClubException
	{
		Turno turno = escenario.ponerTurnoElDiaDelTorneo( "TUR-22", escenario.fisioterapeuta );

		// El club abre a las 6:00 y la solicitud pide arrancar a las 5:00.
		assertThrows( OperacionNoPermitidaException.class, ( ) -> club.solicitarCambioTurno( "SOL-13", escenario.fisioterapeuta, turno, hoy, "madrugar", "Martes", LocalTime.of( 5, 0 ), LocalTime.of( 9, 0 ) ) );
		assertEquals( 0, club.getSolicitudes( ).size( ), "la solicitud ni se radico" );
	}

	/**
	 * Revisa que el nivel de las academias sigue intacto. El Proyecto 2 no le
	 * movio nada a la Entrega 2, y los torneos reutilizan ese mismo nivel y ese
	 * mismo ranking.
	 */
	@Test
	@DisplayName( "extra: el nivel y el ranking de la academia siguen funcionando igual que en la Entrega 2" )
	public void extraNivelYRankingIntactos( )
	{
		AfiliadoIndividual mejor = escenario.tenistas[ 0 ];

		assertEquals( Nivel.INTERMEDIO, mejor.getNivelEn( "Tenis" ) );
		assertEquals( EscenarioPruebas.RANKINGS[ 0 ], mejor.getPuntajeEn( "Tenis" ), 0.01 );
		assertEquals( 0.0, mejor.getPuntajeEn( "Padel" ), 0.01, "no esta inscrito en padel" );
		assertTrue( mejor.puedeJugarContra( escenario.tenistas[ 1 ], "Tenis" ) );
	}
}
