package uniandes.dpoo.cds.pruebas.unitarias;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.modelo.tienda.ArticuloDeportivo;
import uniandes.dpoo.cds.modelo.tienda.Bono;
import uniandes.dpoo.cds.modelo.tienda.Producto;
import uniandes.dpoo.cds.modelo.tienda.VentaTienda;

/**
 * Pruebas del bono y de su efecto en la venta.
 *
 * El bono es el premio de los torneos recreativos. La regla que mas se puede
 * romper es la de que no es acumulable, entonces se prueba el bono solo y el
 * bono metido dentro de una venta.
 *
 * Ojo con los numeros: la venta cobra IVA del 19%, entonces el total siempre
 * sale mayor que la base. Donde el documento dice que una compra de 40.000 con
 * bono del 15% queda en 34.000, eso es la base despues del descuento, no el
 * total con impuesto.
 */
public class BonoYVentaTest
{
	private AfiliadoIndividual socio;

	private AfiliadoIndividual otroSocio;

	private Producto raqueta;

	private LocalDate hoy;

	@BeforeEach
	public void prepararVenta( )
	{
		hoy = LocalDate.now( );
		socio = new AfiliadoIndividual( "3001", "Laura", "Quintero", hoy.minusYears( 21 ), "l@seneca.edu.co", "321", "laura", "clave", "AFI-001", hoy.minusYears( 2 ) );
		otroSocio = new AfiliadoIndividual( "3002", "Martin", "Correa", hoy.minusYears( 22 ), "m@seneca.edu.co", "321", "martin", "clave", "AFI-002", hoy.minusYears( 2 ) );
		raqueta = new ArticuloDeportivo( "ART-01", "Raqueta de tenis", 40000.0, 20, "Raquetas", "Wilson", "Unica" );
	}

	private VentaTienda ventaDeUnaRaqueta( String codigo, uniandes.dpoo.cds.modelo.personas.Persona comprador ) throws ClubException
	{
		VentaTienda venta = new VentaTienda( codigo, hoy, comprador );
		venta.agregarItem( raqueta, 1 );
		return venta;
	}

	@Test
	@DisplayName( "el bono calcula su descuento sobre la base que le pasen" )
	public void calculoDelDescuento( )
	{
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );

		assertEquals( 6000.0, bono.calcularDescuento( 40000.0 ), 0.01 );
		assertFalse( bono.isUsado( ), "recien entregado todavia sirve" );
	}

	@Test
	@DisplayName( "el bono sabe de quien es" )
	public void duenoDelBono( )
	{
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );

		assertTrue( bono.esDe( socio ) );
		assertFalse( bono.esDe( otroSocio ) );
		assertFalse( bono.esDe( null ) );
	}

	@Test
	@DisplayName( "un bono no se puede gastar dos veces" )
	public void bonoGastadoDosVeces( ) throws ClubException
	{
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );
		bono.marcarUsado( hoy );

		assertTrue( bono.isUsado( ) );
		assertEquals( hoy, bono.getFechaUso( ) );
		assertThrows( OperacionNoPermitidaException.class, ( ) -> bono.marcarUsado( hoy ) );
	}

	@Test
	@DisplayName( "al liquidar la venta el bono descuenta y queda gastado" )
	public void redimirBonoEnUnaVenta( ) throws ClubException
	{
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );
		socio.agregarBono( bono );
		VentaTienda venta = ventaDeUnaRaqueta( "V-01", socio );

		// el bono solo se gasta cuando la venta se liquida de verdad
		venta.redimirBono( bono );
		venta.liquidar( );

		assertEquals( 40000.0, venta.getSubtotal( ), 0.01 );
		assertEquals( 6000.0, venta.getDescuento( ), 0.01 );
		assertEquals( 34000.0, venta.getSubtotal( ) - venta.getDescuento( ), 0.01, "la base antes del IVA" );
		assertEquals( 40460.0, venta.getTotal( ), 0.01, "y el total con el IVA del 19%" );
		assertTrue( bono.isUsado( ) );
	}

	@Test
	@DisplayName( "el bono solo se gasta si la venta de verdad se liquida" )
	public void bonoNoSeGastaSiNoSeLiquida( ) throws ClubException
	{
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );
		socio.agregarBono( bono );
		VentaTienda venta = ventaDeUnaRaqueta( "V-02", socio );

		venta.redimirBono( bono );

		assertFalse( bono.isUsado( ), "la venta se quedo a medias y el bono se salvo" );
	}

	@Test
	@DisplayName( "el bono no se junta con el codigo de descuento del empleado" )
	public void bonoNoAcumulableConCodigo( ) throws ClubException
	{
		Entrenador entrenador = new Entrenador( "EMP-1", "Carlos", "Rendon", hoy.minusYears( 35 ), "c@seneca.edu.co", "300", "crendon", "clave", "EMP-01", hoy.minusYears( 4 ), "Tenis", 8 );
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );
		socio.agregarBono( bono );
		VentaTienda venta = ventaDeUnaRaqueta( "V-03", socio );
		venta.aplicarDescuento( entrenador.getCodigoDescuento( ) );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> venta.redimirBono( bono ) );
	}

	@Test
	@DisplayName( "y tampoco al reves: con bono puesto ya no entra el codigo" )
	public void codigoNoEntraDespuesDelBono( ) throws ClubException
	{
		Entrenador entrenador = new Entrenador( "EMP-1", "Carlos", "Rendon", hoy.minusYears( 35 ), "c@seneca.edu.co", "300", "crendon", "clave", "EMP-01", hoy.minusYears( 4 ), "Tenis", 8 );
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );
		socio.agregarBono( bono );
		VentaTienda venta = ventaDeUnaRaqueta( "V-04", socio );
		venta.redimirBono( bono );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> venta.aplicarDescuento( entrenador.getCodigoDescuento( ) ) );
	}

	@Test
	@DisplayName( "una venta ya liquidada no acepta bonos" )
	public void ventaYaLiquidada( ) throws ClubException
	{
		Bono bono = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );
		socio.agregarBono( bono );
		VentaTienda venta = ventaDeUnaRaqueta( "V-05", socio );
		venta.liquidar( );

		assertThrows( OperacionNoPermitidaException.class, ( ) -> venta.redimirBono( bono ) );
	}

	@Test
	@DisplayName( "la lista de bonos disponibles deja afuera los que ya se usaron" )
	public void bonosDisponibles( ) throws ClubException
	{
		Bono disponible = new Bono( "BONO-1", socio, 0.15, "T2", "Copa recreativa" );
		Bono usado = new Bono( "BONO-2", socio, 0.10, "T1", "Copa vieja" );
		usado.marcarUsado( hoy.minusDays( 3 ) );
		socio.agregarBono( disponible );
		socio.agregarBono( usado );

		assertEquals( 2, socio.getBonos( ).size( ) );
		assertEquals( 1, socio.getBonosDisponibles( ).size( ) );
		assertEquals( "BONO-1", socio.buscarBono( "BONO-1" ).getCodigo( ) );
	}
}
