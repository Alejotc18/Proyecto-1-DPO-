================================================================
  CLUB DEPORTIVO SENECA - Proyecto 2, Entrega unica
  ISIS-1226 Diseno y Programacion Orientada a Objetos
  Modelo, interfaces de consola y pruebas automaticas
================================================================

QUE CONTIENE ESTA ENTREGA
-------------------------
Todo lo de la Entrega 2 del Proyecto 1, mas lo nuevo del Proyecto 2:

  - El manejo completo de torneos: crearlos, modificarlos, cancelarlos,
    inscribir participantes con cupos preferenciales, iniciarlos, registrar
    resultados y finalizarlos entregando el premio.
  - Dos roles nuevos que el enunciado pide: Estudiante y Externo.
  - Los bonos de descuento de los torneos recreativos.
  - Tres programas de consola, uno por rol, cada uno con su metodo main.
  - 116 pruebas automaticas con JUnit 5: 51 unitarias y 65 de integracion.

El proyecto compila sin errores y las 116 pruebas pasan.

COMO ABRIR EL PROYECTO EN ECLIPSE
---------------------------------
1. File -> Import -> General -> Existing Projects into Workspace
2. Seleccionar la carpeta "ClubDeportivoSeneca"
3. Finish

El proyecto trae dos carpetas de codigo fuente: src con el programa y test con
las pruebas. El .classpath ya pide la libreria de JUnit 5, que Eclipse trae
incluida. Si Eclipse no la encuentra sola: clic derecho en el proyecto ->
Build Path -> Add Libraries -> JUnit -> JUnit 5.

No usa ninguna libreria descargada de internet: solo un JDK 8 o superior y el
JUnit que viene con Eclipse.

COMO CORRER LOS TRES PROGRAMAS
------------------------------
Cada uno se corre con clic derecho -> Run As -> Java Application:

  uniandes.dpoo.cds.consola.ConsolaAdministrador
      Monta los torneos y los lleva de principio a fin, y atiende las
      solicitudes de cambio de turno de los empleados.
      Usuario de prueba: admin / admin123

  uniandes.dpoo.cds.consola.ConsolaJugador
      Para afiliados, estudiantes y externos: ver torneos, inscribirse solo,
      en pareja o con el equipo, salirse, y manejar los bonos.
      Usuarios de prueba: laura02 / clave02, jhoyos / estu123, plinares / ext123

  uniandes.dpoo.cds.consola.ConsolaEmpleado
      Para entrenadores y fisioterapeutas: turnos, solicitudes de cambio,
      asistencia de sesiones, e inscripcion a torneos individuales.
      Usuarios de prueba: crendon / entre123, parcila / fisio123

Los tres se pasan los datos entre ellos: lo que hace uno queda guardado y el
siguiente lo ve.

COMO CORRER LAS PRUEBAS
-----------------------
Clic derecho en la carpeta "test" -> Run As -> JUnit Test. Corre las siete
clases de una.

  test/uniandes/dpoo/cds/pruebas/unitarias/
      TorneoTest             reglas propias del torneo: cupos, estados, llave
      EncuentroTest          marcadores, ganador y tabla de posiciones
      ParticipanteTest       las tres formas de ocupar un cupo
      BonoYVentaTest         el bono y su efecto en la venta
      TurnoYEnumsTest        la traduccion de fecha a turno y los enumerados

  test/uniandes/dpoo/cds/pruebas/integracion/
      TorneosIntegracionTest        casos CP-01 a CP-50 del documento
      BancoEntrega1IntegracionTest  casos CP-51 a CP-63 del documento

  test/uniandes/dpoo/cds/pruebas/
      EscenarioPruebas       no es una prueba, es el club de mentiras que las
                             pruebas usan: personas, equipos, rankings y demas

Cada metodo de prueba lleva en el nombre el numero del caso del documento,
entonces cuando una falla se sabe de una cual caso es.

COMO COMPILAR DESDE LA LINEA DE COMANDOS
----------------------------------------
Lo recomendado es importar el proyecto en Eclipse, que compila solo. Si se
quiere verificar desde la terminal, el comando depende del sistema, porque la
forma de listar los archivos .java no es la misma en todos:

  Windows (PowerShell), desde la carpeta ClubDeportivoSeneca:
      javac -encoding UTF-8 -d bin (Get-ChildItem -Recurse -Filter *.java src).FullName

  Windows (simbolo del sistema, cmd):
      dir /s /b src\*.java > fuentes.txt
      javac -encoding UTF-8 -d bin @fuentes.txt

  Linux o macOS:
      javac -encoding UTF-8 -d bin $(find src -name "*.java")

ESTRUCTURA DE CARPETAS
----------------------
src/    codigo fuente del programa
test/   codigo fuente de las pruebas
data/   archivos de datos de ejemplo, fuera de la carpeta del codigo como
        exige el enunciado
bin/    clases compiladas
doc/    este archivo

PAQUETES
--------
uniandes.dpoo.cds.modelo.personas        jerarquia de Persona
uniandes.dpoo.cds.modelo.deportes        equipos, partidos, estadisticas
uniandes.dpoo.cds.modelo.competencias    circuitos externos y nominas
uniandes.dpoo.cds.modelo.academias       disciplinas individuales e instalaciones
uniandes.dpoo.cds.modelo.entrenamiento   sesiones, convocatorias y turnos
uniandes.dpoo.cds.modelo.tienda          productos, ventas y bonos
uniandes.dpoo.cds.modelo.torneos         NUEVO: torneos, participantes y encuentros
uniandes.dpoo.cds.reglas                 reglas de cada deporte y disciplina
uniandes.dpoo.cds.logica                 fachada del club
uniandes.dpoo.cds.persistencia           lectura y escritura de archivos
uniandes.dpoo.cds.consola                NUEVO: los tres programas de consola
uniandes.dpoo.cds.excepciones            errores del dominio

COMO SE GUARDAN LOS DATOS
-------------------------
El club tiene dos repositorios que cumplen la misma interfaz, y los programas
de consola usan los dos a proposito.

La primera vez que se corre cualquiera de los tres programas todavia no existe
el archivo data/club.ser, entonces los datos se cargan de los archivos de
texto, que son los que uno puede abrir y editar a mano. De ahi en adelante el
club entero se guarda con serializacion en data/club.ser y de ahi se vuelve a
cargar, y ademas se actualizan los archivos de texto con lo que si cabe en una
linea.

Se hace asi porque las inscripciones a torneos, los encuentros y los bonos no
estan en los archivos de texto: son datos que apuntan a varios objetos al
tiempo y en texto plano tocaria inventarse tres archivos mas con codigos
cruzados. Con la serializacion se guarda el club completo y los tres programas
si se ven el trabajo entre ellos.

Para volver a arrancar con los datos de ejemplo limpios, basta con borrar
data/club.ser.

    club.txt            configuracion general del club
    personas.txt        afiliados, empleados, administrador, estudiantes y externos
    equipos.txt         equipos de deportes de conjunto
    inscripciones.txt   vinculo jugador-equipo
    academias.txt       vinculo afiliado-disciplina, con el ranking
    instalaciones.txt   canchas y mesas
    productos.txt       articulos, bebidas y snacks
    torneos.txt         NUEVO: definicion de los torneos

PATRONES DE DISENO APLICADOS
----------------------------
Strategy        ReglasDeporte, ReglasDisciplina, FormatoCompetencia
Factory Method  crearEstadistica dentro de las interfaces de reglas
Template Method Venta.liquidar, Torneo.finalizar, ConsolaBase.arrancar y
                ReglasRaquetaBase.calcularNuevoPuntaje
DAO             RepositorioClub con dos implementaciones
Fachada         la clase Club

QUE SE LE CAMBIO AL CODIGO DE LA ENTREGA ANTERIOR
-------------------------------------------------
Todos los cambios estan marcados en el codigo con un comentario que arranca
diciendo "CAMBIO DEL PROYECTO 2":

  Persona                 ahora guarda los bonos que gano en torneos
  AfiliadoIndividual      implementa Competidor; el nivel y el puntaje salen de
                          la inscripcion a la academia, que ya existia
  Empleado                implementa Competidor, declara su nivel, sabe si
                          tiene turno un dia, y nace con su codigo de descuento
  Equipo                  lleva la cuenta de partidos internos ganados, que es
                          el criterio de ranking de equipos que no existia
  Turno                   traduce una fecha de calendario a dia y semana
  SolicitudCambioTurno    ahora lleva el dia y las horas del turno nuevo, y al
                          aprobarse mueve el turno en vez de desaparecerlo
  Convocatoria            rechaza la asistencia si la sesion no ha finalizado
  Venta                   acepta bonos y revisa que no se junten con otro
                          descuento
  Club                    operaciones de torneos, bonos, rankings, el rechazo
                          de cambios de turno y la validacion del horario de
                          atencion. Cuando aprobar un cambio rompe la cobertura
                          minima, la solicitud se queda Pendiente en vez de
                          quedar rechazada de una
  RepositorioArchivosPlanos  guarda y carga torneos, estudiantes y externos
