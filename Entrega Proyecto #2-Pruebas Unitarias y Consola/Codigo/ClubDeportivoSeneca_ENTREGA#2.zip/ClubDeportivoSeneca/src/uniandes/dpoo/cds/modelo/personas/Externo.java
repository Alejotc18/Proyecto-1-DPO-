package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.academias.Nivel;

/**
 * PERSONA EXTERNA AL CLUB
 *
 * Es alguien que no es socio ni estudia en la universidad, pero que el enunciado
 * del Proyecto 2 deja entrar a los torneos.
 *
 * Es casi igual a Estudiante y de hecho pensamos en dejar una sola clase con un
 * campo que dijera si era estudiante o externo. Lo separamos porque son dos
 * vinculos distintos con la universidad y el club les puede pedir cosas
 * distintas despues, por ejemplo el estudiante muestra su codigo y el externo
 * tiene que dejar un contacto de emergencia. Con un campo de texto eso quedaria
 * como un monton de ifs, y con dos clases cada una carga lo suyo y asi.
 */
public class Externo extends Persona implements Competidor
{
	private static final long serialVersionUID = 1L;

	private String contactoEmergencia;

	private Nivel nivelDeclarado;

	public Externo( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String contactoEmergencia, Nivel nivelDeclarado )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password );
		this.contactoEmergencia = contactoEmergencia;
		this.nivelDeclarado = nivelDeclarado;
	}

	/**
	 * EN QUE NIVEL JUEGA
	 *
	 * Es el nivel que declaro al registrarse, igual para cualquier disciplina.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return el nivel declarado
	 */
	@Override
	public Nivel getNivelEn( String nombreDisciplina )
	{
		return nivelDeclarado;
	}

	/**
	 * CUANTO PUNTAJE DE RANKING TIENE
	 *
	 * Cero, pues no esta inscrito en las academias del club.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return siempre cero
	 */
	@Override
	public double getPuntajeEn( String nombreDisciplina )
	{
		return 0.0;
	}

	@Override
	public boolean esEmpleadoDelClub( )
	{
		return false;
	}

	public String getContactoEmergencia( )
	{
		return contactoEmergencia;
	}

	public void setContactoEmergencia( String contactoEmergencia )
	{
		this.contactoEmergencia = contactoEmergencia;
	}

	public Nivel getNivelDeclarado( )
	{
		return nivelDeclarado;
	}

	public void setNivelDeclarado( Nivel nivelDeclarado )
	{
		this.nivelDeclarado = nivelDeclarado;
	}

	@Override
	public String getRol( )
	{
		return "Externo";
	}
}
