package uniandes.dpoo.cds.modelo.torneos;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.CupoLlenoException;
import uniandes.dpoo.cds.excepciones.NivelIncompatibleException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * TORNEO, PATRON TEMPLATE METHOD
 *
 * Es un torneo del club, competitivo o recreativo.
 *
 * Entre los dos tipos casi todo es igual: los dos tienen cupos, los dos tienen
 * cupos preferenciales, los dos arrancan con inscripciones abiertas, los dos
 * arman encuentros de eliminacion y los dos terminan premiando al campeon. Lo
 * unico que de verdad cambia son dos cosas: cuanto hay que pagar para entrar y
 * que se lleva el que gana, o sea plata en el competitivo y un bono de descuento
 * en el recreativo.
 *
 * Entonces hicimos lo mismo que con Venta: el metodo finalizar esta aqui, es
 * final, y lleva el procedimiento completo en orden. Deja dos huecos que cada
 * subclase llena, que son getValorAPagar y entregarPremio. Asi ninguna subclase
 * puede saltarse la revision de los encuentros pendientes ni premiar antes de
 * tiempo.
 *
 * DECISION DE DISENO D2
 * Los estados van Inscripciones abiertas, luego En curso y luego Finalizado, y
 * ademas existe Cancelado. El enunciado solo nombra los dos del medio pero sin
 * el primero no habria cuando inscribirse.
 */
public abstract class Torneo implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private String nombre;

	private Modalidad modalidad;

	private String disciplina;

	private Nivel nivel;

	private Categoria categoria;

	private LocalDate fecha;

	private int cupos;

	private int cuposPreferenciales;

	private EstadoTorneo estado;

	private List<InscripcionTorneo> inscripciones;

	private List<Encuentro> encuentros;

	private List<PosicionTorneo> posiciones;

	// Es el participante que en la ronda que se esta jugando paso derecho porque
	// el numero era impar y no habia con quien emparejarlo. Guardamos uno solo
	// pues en cada momento hay una sola ronda abierta, entonces cuando se arma la
	// ronda siguiente este se mete con los ganadores y el campo se vuelve a
	// calcular.
	private Participante byePendiente;

	public static final double PORCENTAJE_PREFERENCIAL = 0.2;

	public static final int CUPOS_MINIMOS = 2;

	/**
	 * CREAR EL TORNEO
	 *
	 * Lo deja en Inscripciones abiertas y de una calcula cuantos cupos
	 * preferenciales le tocan.
	 *
	 * Si los cupos no alcanzan para dos participantes entonces revienta aqui
	 * mismo y el torneo nunca llega a existir, pues un torneo de un solo cupo no
	 * tiene con quien jugar.
	 *
	 * @param codigo el codigo del torneo
	 * @param nombre el nombre del torneo
	 * @param modalidad conjunto, individual o dobles
	 * @param disciplina el deporte o la disciplina que se juega
	 * @param nivel el nivel exigido, o null en los torneos de conjunto
	 * @param categoria la categoria exigida, o null en los individuales y de dobles
	 * @param fecha la fecha en la que se juega
	 * @param cupos el numero total de cupos
	 * @throws OperacionNoPermitidaException si los cupos no alcanzan para dos participantes
	 */
	public Torneo( String codigo, String nombre, Modalidad modalidad, String disciplina, Nivel nivel, Categoria categoria, LocalDate fecha, int cupos ) throws OperacionNoPermitidaException
	{
		if( cupos < CUPOS_MINIMOS )
		{
			throw new OperacionNoPermitidaException( "Un torneo necesita por lo menos " + CUPOS_MINIMOS + " cupos y se pidieron " + cupos );
		}
		this.codigo = codigo;
		this.nombre = nombre;
		this.modalidad = modalidad;
		this.disciplina = disciplina;
		this.nivel = nivel;
		this.categoria = categoria;
		this.fecha = fecha;
		this.cupos = cupos;
		this.cuposPreferenciales = calcularCuposPreferenciales( cupos );
		this.estado = EstadoTorneo.INSCRIPCIONES_ABIERTAS;
		this.inscripciones = new ArrayList<InscripcionTorneo>( );
		this.encuentros = new ArrayList<Encuentro>( );
		this.posiciones = new ArrayList<PosicionTorneo>( );
	}

	/**
	 * CUANTOS CUPOS PREFERENCIALES LE TOCAN
	 *
	 * DECISION DE DISENO D4
	 * Es el 20% de los cupos redondeado hacia arriba. Redondeamos hacia arriba y
	 * no hacia abajo porque si fuera hacia abajo un torneo de 7 cupos quedaria
	 * con un solo cupo preferencial, y la idea del club es premiar a los mejores,
	 * no dejarlos con las migajas.
	 *
	 * Entonces 10 cupos dan 2 preferenciales, 7 cupos dan 2 porque 1,4 sube a 2,
	 * y 16 cupos dan 4.
	 *
	 * nota: Math.ceil es lo que redondea hacia arriba. Trabaja con decimales
	 * entonces al final hay que volverlo entero con el cast a int.
	 *
	 * @param cupos el total de cupos del torneo
	 * @return la cantidad de cupos reservados para los mejores del ranking
	 */
	public static int calcularCuposPreferenciales( int cupos )
	{
		return ( int ) Math.ceil( cupos * PORCENTAJE_PREFERENCIAL );
	}

	// HUECOS QUE LLENA CADA SUBCLASE

	/**
	 * QUE TIPO DE TORNEO ES
	 *
	 * @return "Competitivo" o "Recreativo"
	 */
	public abstract String getTipo( );

	/**
	 * CUANTO LE TOCA PAGAR A ESTE PARTICIPANTE
	 *
	 * Primer hueco del metodo plantilla. El recreativo no cobra nada y el
	 * competitivo cobra la tarifa, menos a los empleados que entran gratis.
	 *
	 * @param participante el participante que se esta inscribiendo
	 * @return el valor que debe pagar por el cupo
	 */
	public abstract double getValorAPagar( Participante participante );

	/**
	 * ENTREGAR EL PREMIO
	 *
	 * Segundo hueco del metodo plantilla. El competitivo entrega plata y el
	 * recreativo entrega bonos de descuento.
	 *
	 * @param campeon el participante que gano el torneo
	 * @throws ClubException si el premio no se puede entregar
	 */
	protected abstract void entregarPremio( Participante campeon ) throws ClubException;

	// INSCRIPCIONES

	/**
	 * INSCRIBIR UN PARTICIPANTE
	 *
	 * Revisa todo en este orden: que las inscripciones esten abiertas, que la
	 * modalidad sea la del torneo, que el participante este en condiciones de
	 * competir, que no este ya inscrito, que el nivel o la categoria coincidan, y
	 * de ultimas que haya cupo.
	 *
	 * la parte del codigo que puede hacerlo estallar es: lo del cupo preferencial
	 * cuando ya estan llenos. Quien tiene derecho a preferencial pero llega y ya
	 * no quedan NO se queda afuera: se pasa a cupo regular. Si lo rechazaramos
	 * entonces estariamos castigando al que va mejor en el ranking, que es
	 * exactamente lo contrario de lo que quiere la regla.
	 *
	 * @param participante el que se quiere inscribir
	 * @param fecha la fecha de la inscripcion
	 * @param pidePreferencial true si tiene derecho a cupo preferencial
	 * @return la inscripcion creada
	 * @throws ClubException si alguna de las reglas de inscripcion no se cumple
	 */
	public InscripcionTorneo inscribir( Participante participante, LocalDate fecha, boolean pidePreferencial ) throws ClubException
	{
		if( !estado.admiteInscripciones( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " esta en estado " + estado.getNombre( ) + " y no admite inscripciones" );
		}
		if( participante.getModalidad( ) != modalidad )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " es de modalidad " + modalidad.getNombre( ) + " y el participante es de " + participante.getModalidad( ).getNombre( ) );
		}

		participante.validarPuedeCompetir( );
		validarNoRepetido( participante );
		validarNivelOCategoria( participante );

		boolean preferencial = pidePreferencial && getCuposPreferencialesDisponibles( ) > 0;
		if( !preferencial && getCuposRegularesDisponibles( ) <= 0 )
		{
			throw new CupoLlenoException( "El torneo " + codigo + " ya no tiene cupos regulares disponibles" );
		}

		InscripcionTorneo inscripcion = new InscripcionTorneo( this, participante, fecha, preferencial, getValorAPagar( participante ) );
		inscripciones.add( inscripcion );
		return inscripcion;
	}

	/**
	 * REVISAR QUE NO ESTE YA ADENTRO
	 *
	 * DECISION DE DISENO D12
	 * Un jugador puede estar en varios torneos al mismo tiempo, pero no dos veces
	 * en el mismo. Y la revision es por persona y no por participante, entonces
	 * alguien tampoco puede entrar solo y de nuevo en pareja con otro.
	 *
	 * @param participante el que se quiere inscribir
	 * @throws OperacionNoPermitidaException si alguno de sus integrantes ya esta inscrito
	 */
	private void validarNoRepetido( Participante participante ) throws OperacionNoPermitidaException
	{
		for( Persona integrante : participante.getIntegrantes( ) )
		{
			if( buscarInscripcionDe( integrante ) != null )
			{
				throw new OperacionNoPermitidaException( integrante.getNombreCompleto( ) + " ya esta inscrito en el torneo " + codigo );
			}
		}
	}

	/**
	 * REVISAR EL NIVEL O LA CATEGORIA
	 *
	 * DECISION DE DISENO D11
	 * En los torneos individuales y de dobles lo que manda es el nivel, y en los
	 * de conjunto la categoria de edad. Cada torneo tiene uno de los dos lleno y
	 * el otro en null, entonces aqui se revisa el que corresponda.
	 *
	 * @param participante el que se quiere inscribir
	 * @throws NivelIncompatibleException si el nivel o la categoria no son los del torneo
	 */
	private void validarNivelOCategoria( Participante participante ) throws NivelIncompatibleException
	{
		if( nivel != null )
		{
			Nivel nivelParticipante = participante.getNivelEn( disciplina );
			if( nivelParticipante != nivel )
			{
				throw new NivelIncompatibleException( "El torneo " + codigo + " es de nivel " + nivel.getNombre( ) + " y " + participante.getNombre( ) + " no juega en ese nivel" );
			}
		}
		if( categoria != null )
		{
			Categoria categoriaParticipante = participante.getCategoria( );
			if( categoriaParticipante != categoria )
			{
				throw new NivelIncompatibleException( "El torneo " + codigo + " es de categoria " + categoria.getNombre( ) + " y " + participante.getNombre( ) + " no es de esa categoria" );
			}
		}
	}

	/**
	 * SACAR A ALGUIEN DEL TORNEO
	 *
	 * Busca el cupo en el que esta esa persona y lo saca completo. Entonces si
	 * era una pareja de dobles se van los dos, pues el cupo era de la pareja y no
	 * de cada uno.
	 *
	 * @param persona la persona que se quiere salir
	 * @throws OperacionNoPermitidaException si el torneo ya arranco o si la persona no estaba inscrita
	 */
	public void desinscribir( Persona persona ) throws OperacionNoPermitidaException
	{
		if( !estado.admiteInscripciones( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " esta en estado " + estado.getNombre( ) + " y ya no se puede salir" );
		}
		InscripcionTorneo inscripcion = buscarInscripcionDe( persona );
		if( inscripcion == null )
		{
			throw new OperacionNoPermitidaException( persona.getNombreCompleto( ) + " no esta inscrito en el torneo " + codigo );
		}
		inscripciones.remove( inscripcion );
	}

	public InscripcionTorneo buscarInscripcionDe( Persona persona )
	{
		for( InscripcionTorneo inscripcion : inscripciones )
		{
			if( inscripcion.getParticipante( ).incluye( persona ) )
			{
				return inscripcion;
			}
		}
		return null;
	}

	// CUENTA DE CUPOS

	public int getCuposRegulares( )
	{
		return cupos - cuposPreferenciales;
	}

	public int getInscritosPreferenciales( )
	{
		int total = 0;
		for( InscripcionTorneo inscripcion : inscripciones )
		{
			if( inscripcion.isPreferencial( ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	public int getInscritosRegulares( )
	{
		return inscripciones.size( ) - getInscritosPreferenciales( );
	}

	public int getCuposPreferencialesDisponibles( )
	{
		return cuposPreferenciales - getInscritosPreferenciales( );
	}

	public int getCuposRegularesDisponibles( )
	{
		return getCuposRegulares( ) - getInscritosRegulares( );
	}

	// OPERACIONES DEL ADMINISTRADOR

	/**
	 * CAMBIAR EL NUMERO DE CUPOS
	 *
	 * Solo se puede mientras el torneo no haya arrancado, y los cupos nuevos
	 * tienen que alcanzar para los que ya estan inscritos, pues si no tocaria
	 * sacar gente que ya pago.
	 *
	 * Al cambiar los cupos se recalculan los preferenciales, entonces subir de 10
	 * a 16 cupos pasa los preferenciales de 2 a 4.
	 *
	 * @param nuevosCupos el nuevo total de cupos
	 * @throws OperacionNoPermitidaException si el torneo ya arranco o si los cupos no alcanzan
	 */
	public void modificarCupos( int nuevosCupos ) throws OperacionNoPermitidaException
	{
		if( !estado.admiteCambios( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " esta en estado " + estado.getNombre( ) + " y ya no se puede modificar" );
		}
		if( nuevosCupos < CUPOS_MINIMOS )
		{
			throw new OperacionNoPermitidaException( "Un torneo necesita por lo menos " + CUPOS_MINIMOS + " cupos y se pidieron " + nuevosCupos );
		}
		if( nuevosCupos < inscripciones.size( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " ya tiene " + inscripciones.size( ) + " inscritos y no se puede bajar a " + nuevosCupos + " cupos" );
		}
		this.cupos = nuevosCupos;
		this.cuposPreferenciales = calcularCuposPreferenciales( nuevosCupos );
	}

	/**
	 * CANCELAR EL TORNEO
	 *
	 * Lo pasa a Cancelado y borra las inscripciones, pues el torneo no se va a
	 * jugar y nadie deberia quedar apuntado a algo que no existe.
	 *
	 * @throws OperacionNoPermitidaException si el torneo ya arranco o ya termino
	 */
	public void cancelar( ) throws OperacionNoPermitidaException
	{
		if( !estado.admiteCambios( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " esta en estado " + estado.getNombre( ) + " y ya no se puede cancelar" );
		}
		this.estado = EstadoTorneo.CANCELADO;
		this.inscripciones.clear( );
	}

	/**
	 * LIBERAR LOS CUPOS PREFERENCIALES QUE SOBRARON
	 *
	 * DECISION DE DISENO D6
	 * Los cupos preferenciales que nadie uso se vuelven regulares. Lo hace el
	 * administrador cuando quiera, y si no lo hace entonces pasa solo al iniciar
	 * el torneo, porque si no esos cupos se perderian y el torneo arrancaria con
	 * menos gente de la que cabia.
	 *
	 * @return cuantos cupos preferenciales se pasaron a regulares
	 */
	public int liberarCuposPreferenciales( )
	{
		int libres = getCuposPreferencialesDisponibles( );
		this.cuposPreferenciales = this.cuposPreferenciales - libres;
		return libres;
	}

	/**
	 * ARRANCAR EL TORNEO
	 *
	 * Hace cuatro cosas en orden: revisa que haya por lo menos dos
	 * participantes, libera los cupos preferenciales que sobraron, arma los
	 * encuentros de la primera ronda y abre la tabla de posiciones.
	 *
	 * la parte del codigo que puede hacerlo estallar es: el orden entre liberar
	 * los cupos y armar los encuentros. Los encuentros se arman con los que
	 * estan inscritos, entonces liberar primero no cambia la llave pero si deja
	 * la cuenta de cupos cuadrada en el momento en que el torneo pasa a En curso,
	 * que es como queda guardado para siempre.
	 *
	 * @throws OperacionNoPermitidaException si el torneo no esta abierto o no hay con quien jugar
	 */
	public void iniciar( ) throws OperacionNoPermitidaException
	{
		if( !estado.admiteCambios( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " esta en estado " + estado.getNombre( ) + " y no se puede iniciar" );
		}
		if( inscripciones.size( ) < CUPOS_MINIMOS )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " tiene " + inscripciones.size( ) + " participante(s) y se necesitan al menos " + CUPOS_MINIMOS );
		}

		liberarCuposPreferenciales( );

		List<Participante> participantes = new ArrayList<Participante>( );
		for( InscripcionTorneo inscripcion : inscripciones )
		{
			participantes.add( inscripcion.getParticipante( ) );
			posiciones.add( new PosicionTorneo( inscripcion.getParticipante( ) ) );
		}
		armarRonda( 1, participantes );

		this.estado = EstadoTorneo.EN_CURSO;
	}

	/**
	 * ARMAR LOS ENCUENTROS DE UNA RONDA
	 *
	 * Los empareja de dos en dos en el orden en que se inscribieron. Si quedan
	 * impares entonces el ultimo pasa derecho a la ronda siguiente, que en los
	 * torneos de verdad le dicen "bye".
	 *
	 * @param ronda el numero de la ronda
	 * @param participantes los que juegan esa ronda
	 */
	private void armarRonda( int ronda, List<Participante> participantes )
	{
		int numero = 1;
		for( int i = 0; i + 1 < participantes.size( ); i = i + 2 )
		{
			String codigoEncuentro = codigo + "-R" + ronda + "-" + numero;
			encuentros.add( new Encuentro( codigoEncuentro, ronda, participantes.get( i ), participantes.get( i + 1 ) ) );
			numero = numero + 1;
		}

		if( participantes.size( ) % 2 == 0 )
		{
			this.byePendiente = null;
		}
		else
		{
			this.byePendiente = participantes.get( participantes.size( ) - 1 );
		}
	}

	/**
	 * GUARDAR EL RESULTADO DE UN ENCUENTRO
	 *
	 * Guarda el marcador, actualiza la tabla de posiciones y, si con eso se
	 * completo la ronda, arma de una la ronda siguiente con los que ganaron.
	 *
	 * la parte del codigo que puede hacerlo estallar es: actualizar la tabla
	 * ANTES de armar la ronda siguiente. Si se armara la ronda primero, el que
	 * acaba de ganar quedaria emparejado sin que su victoria este sumada, y si
	 * algo falla en la mitad el torneo tendria una llave que no corresponde a los
	 * resultados.
	 *
	 * @param encuentro el encuentro que se esta registrando
	 * @param marcadorA los tantos del primer participante
	 * @param marcadorB los tantos del segundo participante
	 * @throws OperacionNoPermitidaException si el torneo no esta En curso, el encuentro no es de este torneo o el resultado no es valido
	 */
	public void registrarResultado( Encuentro encuentro, int marcadorA, int marcadorB ) throws OperacionNoPermitidaException
	{
		if( !estado.estaEnJuego( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " esta en estado " + estado.getNombre( ) + " y no admite resultados" );
		}
		if( !encuentros.contains( encuentro ) )
		{
			throw new OperacionNoPermitidaException( "El encuentro " + encuentro.getCodigo( ) + " no pertenece al torneo " + codigo );
		}

		encuentro.registrarResultado( marcadorA, marcadorB );

		buscarPosicion( encuentro.getGanador( ) ).registrarVictoria( );
		buscarPosicion( encuentro.getPerdedor( ) ).registrarDerrota( );

		armarRondaSiguienteSiTermino( encuentro.getRonda( ) );
	}

	/**
	 * PASAR A LA RONDA SIGUIENTE
	 *
	 * Si ya se jugaron todos los encuentros de la ronda y quedan dos o mas
	 * ganadores, entonces arma la ronda siguiente con ellos. Si queda uno solo
	 * entonces ese es el campeon y no se arma nada mas.
	 *
	 * @param ronda la ronda que se acabo de jugar
	 */
	private void armarRondaSiguienteSiTermino( int ronda )
	{
		List<Participante> ganadores = new ArrayList<Participante>( );
		for( Encuentro encuentro : encuentros )
		{
			if( encuentro.getRonda( ) != ronda )
			{
				continue;
			}
			if( !encuentro.isJugado( ) )
			{
				return;
			}
			ganadores.add( encuentro.getGanador( ) );
		}

		if( byePendiente != null )
		{
			ganadores.add( byePendiente );
		}

		if( ganadores.size( ) >= CUPOS_MINIMOS )
		{
			armarRonda( ronda + 1, ganadores );
		}
	}

	/**
	 * TERMINAR EL TORNEO, ESTE ES EL METODO PLANTILLA
	 *
	 * Aqui esta el procedimiento completo y en orden, y esta marcado como final a
	 * proposito para que ninguna subclase lo pueda reescribir: revisa que el
	 * torneo este En curso, revisa que no queden encuentros pendientes, busca al
	 * campeon, le entrega el premio que le toque segun el tipo de torneo, y de
	 * ultimas lo pasa a Finalizado.
	 *
	 * la parte del codigo que puede hacerlo estallar es: pasar el torneo a
	 * Finalizado al final y no al principio. Si lo marcaramos primero y la
	 * entrega del premio fallara, el torneo quedaria cerrado y sin premio
	 * entregado, y ya no habria forma de volverlo a finalizar porque el estado no
	 * lo deja. Asi como esta, si el premio falla el torneo sigue En curso y se
	 * puede volver a intentar.
	 *
	 * @return el participante que gano el torneo
	 * @throws ClubException si el torneo no esta En curso o si quedan encuentros sin resultado
	 */
	public final Participante finalizar( ) throws ClubException
	{
		if( !estado.estaEnJuego( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " esta en estado " + estado.getNombre( ) + " y no se puede finalizar" );
		}
		if( contarEncuentrosPendientes( ) > 0 )
		{
			throw new OperacionNoPermitidaException( "El torneo " + codigo + " tiene " + contarEncuentrosPendientes( ) + " encuentro(s) sin resultado" );
		}

		Participante campeon = getCampeon( );
		entregarPremio( campeon );
		this.estado = EstadoTorneo.FINALIZADO;
		return campeon;
	}

	/**
	 * CUANTOS ENCUENTROS FALTAN
	 *
	 * @return la cantidad de encuentros que todavia no tienen resultado
	 */
	public int contarEncuentrosPendientes( )
	{
		int total = 0;
		for( Encuentro encuentro : encuentros )
		{
			if( !encuentro.isJugado( ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	/**
	 * QUIEN GANO EL TORNEO
	 *
	 * Es el que gano el encuentro de la ultima ronda.
	 *
	 * Lo sacamos de la llave y no de los puntos de la tabla a proposito, pues
	 * cuando hay numero impar de participantes alguien pasa sin jugar y entonces
	 * puede llegar a la final con menos puntos que el que perdio en semifinales.
	 * Si ordenaramos por puntos nos saldria un campeon equivocado y asi.
	 *
	 * @return el campeon, o null si todavia no hay encuentros jugados
	 */
	public Participante getCampeon( )
	{
		Encuentro ultimo = null;
		for( Encuentro encuentro : encuentros )
		{
			if( !encuentro.isJugado( ) )
			{
				continue;
			}
			if( ultimo == null || encuentro.getRonda( ) >= ultimo.getRonda( ) )
			{
				ultimo = encuentro;
			}
		}
		if( ultimo == null )
		{
			return null;
		}
		return ultimo.getGanador( );
	}

	public PosicionTorneo buscarPosicion( Participante participante )
	{
		for( PosicionTorneo posicion : posiciones )
		{
			if( posicion.getParticipante( ) == participante )
			{
				return posicion;
			}
		}
		PosicionTorneo nueva = new PosicionTorneo( participante );
		posiciones.add( nueva );
		return nueva;
	}

	/**
	 * ARMAR LA TABLA DE POSICIONES ORDENADA
	 *
	 * Los ordena de mas puntos a menos puntos, y si empatan en puntos entonces
	 * manda el que gano mas encuentros.
	 *
	 * @return las posiciones ordenadas de primero a ultimo
	 */
	public List<PosicionTorneo> getTablaPosiciones( )
	{
		List<PosicionTorneo> tabla = new ArrayList<PosicionTorneo>( posiciones );
		for( int i = 0; i < tabla.size( ); i++ )
		{
			for( int j = i + 1; j < tabla.size( ); j++ )
			{
				boolean masPuntos = tabla.get( j ).getPuntos( ) > tabla.get( i ).getPuntos( );
				boolean mismosPuntos = tabla.get( j ).getPuntos( ) == tabla.get( i ).getPuntos( );
				boolean masGanados = tabla.get( j ).getGanados( ) > tabla.get( i ).getGanados( );
				if( masPuntos || ( mismosPuntos && masGanados ) )
				{
					PosicionTorneo temporal = tabla.get( i );
					tabla.set( i, tabla.get( j ) );
					tabla.set( j, temporal );
				}
			}
		}
		return tabla;
	}

	/**
	 * ARMAR EL HISTORIAL DEL TORNEO
	 *
	 * Muestra los encuentros con su resultado o con la palabra pendiente, y
	 * debajo la tabla de posiciones. Sirve tanto para un torneo Finalizado como
	 * para uno que va En curso, que es lo que pide la historia de usuario.
	 *
	 * @return el historial del torneo en texto
	 */
	public String getHistorial( )
	{
		StringBuilder texto = new StringBuilder( );
		texto.append( "Torneo " ).append( codigo ).append( " - " ).append( nombre ).append( " (" ).append( getTipo( ) ).append( ")\n" );
		texto.append( "Estado: " ).append( estado.getNombre( ) ).append( " | fecha " ).append( fecha ).append( "\n" );
		texto.append( "Encuentros:\n" );
		for( Encuentro encuentro : encuentros )
		{
			texto.append( "   " ).append( encuentro.toString( ) ).append( "\n" );
		}
		texto.append( "Posiciones:\n" );
		for( PosicionTorneo posicion : getTablaPosiciones( ) )
		{
			texto.append( "   " ).append( posicion.toString( ) ).append( "\n" );
		}
		return texto.toString( );
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public Modalidad getModalidad( )
	{
		return modalidad;
	}

	public String getDisciplina( )
	{
		return disciplina;
	}

	public Nivel getNivel( )
	{
		return nivel;
	}

	public Categoria getCategoria( )
	{
		return categoria;
	}

	public LocalDate getFecha( )
	{
		return fecha;
	}

	public int getCupos( )
	{
		return cupos;
	}

	public int getCuposPreferenciales( )
	{
		return cuposPreferenciales;
	}

	public EstadoTorneo getEstado( )
	{
		return estado;
	}

	/**
	 * PONERLE EL ESTADO DIRECTAMENTE
	 *
	 * Este setter es para el repositorio y nada mas, o sea para cuando se recarga
	 * un torneo desde el archivo y hay que devolverlo al estado en el que
	 * quedo. Los programas no lo deberian usar: ellos cambian el estado llamando
	 * a iniciar, cancelar o finalizar, que son los que si revisan las reglas.
	 *
	 * @param estado el estado que tenia guardado el torneo
	 */
	public void setEstado( EstadoTorneo estado )
	{
		this.estado = estado;
	}

	public List<InscripcionTorneo> getInscripciones( )
	{
		return inscripciones;
	}

	public List<Encuentro> getEncuentros( )
	{
		return encuentros;
	}

	public List<Encuentro> getEncuentrosDeRonda( int ronda )
	{
		List<Encuentro> dela = new ArrayList<Encuentro>( );
		for( Encuentro encuentro : encuentros )
		{
			if( encuentro.getRonda( ) == ronda )
			{
				dela.add( encuentro );
			}
		}
		return dela;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + nombre + " | " + getTipo( ) + " | " + modalidad.getNombre( ) + " | " + estado.getNombre( ) + " | " + inscripciones.size( ) + "/" + cupos + " cupos";
	}
}
