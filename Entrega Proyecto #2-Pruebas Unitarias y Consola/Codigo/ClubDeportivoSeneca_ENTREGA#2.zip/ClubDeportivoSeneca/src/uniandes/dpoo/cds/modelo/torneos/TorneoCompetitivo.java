package uniandes.dpoo.cds.modelo.torneos;

import java.time.LocalDate;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.personas.Competidor;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * TORNEO COMPETITIVO
 *
 * Es el torneo que cobra inscripcion y reparte plata.
 *
 * Lo que recoge de las inscripciones es la bolsa, y de esa bolsa el campeon se
 * lleva el porcentaje que el administrador fijo al crear el torneo. Lo que sobra
 * se queda en el club.
 */
public class TorneoCompetitivo extends Torneo
{
	private static final long serialVersionUID = 1L;

	private double tarifa;

	// Igual que en el bono, el porcentaje se guarda como fraccion: un premio del
	// 80% de la bolsa aqui es 0.8.
	private double porcentajePremio;

	private double premioEntregado;

	private Participante ganadorDelPremio;

	/**
	 * CREAR EL TORNEO COMPETITIVO
	 *
	 * Revisa dos cosas que el enunciado exige: que la tarifa sea mayor que cero,
	 * pues un torneo competitivo sin tarifa no tendria de donde sacar el premio,
	 * y que el porcentaje del premio este entre 1 y 100.
	 *
	 * Las dos revisiones estan en el constructor a proposito, entonces si algo
	 * esta mal el objeto nunca se llega a crear y no queda rodando por ahi un
	 * torneo invalido.
	 *
	 * @param codigo el codigo del torneo
	 * @param nombre el nombre del torneo
	 * @param modalidad conjunto, individual o dobles
	 * @param disciplina el deporte o la disciplina
	 * @param nivel el nivel exigido, o null en los de conjunto
	 * @param categoria la categoria exigida, o null en los individuales y de dobles
	 * @param fecha la fecha en la que se juega
	 * @param cupos el numero total de cupos
	 * @param tarifa lo que cuesta inscribirse
	 * @param porcentajePremio la fraccion de lo recaudado que se lleva el campeon
	 * @throws OperacionNoPermitidaException si la tarifa no es positiva o el porcentaje esta fuera de rango
	 */
	public TorneoCompetitivo( String codigo, String nombre, Modalidad modalidad, String disciplina, Nivel nivel, Categoria categoria, LocalDate fecha, int cupos, double tarifa, double porcentajePremio ) throws OperacionNoPermitidaException
	{
		super( codigo, nombre, modalidad, disciplina, nivel, categoria, fecha, cupos );
		if( tarifa <= 0 )
		{
			throw new OperacionNoPermitidaException( "Un torneo competitivo necesita una tarifa de inscripcion mayor que cero y llego " + tarifa );
		}
		if( porcentajePremio <= 0 || porcentajePremio > 1 )
		{
			throw new OperacionNoPermitidaException( "El porcentaje del premio debe estar entre 1% y 100%, o sea entre 0.01 y 1, y llego " + porcentajePremio );
		}
		this.tarifa = tarifa;
		this.porcentajePremio = porcentajePremio;
		this.premioEntregado = 0.0;
	}

	@Override
	public String getTipo( )
	{
		return "Competitivo";
	}

	/**
	 * CUANTO LE TOCA PAGAR
	 *
	 * DECISION DE DISENO D7
	 * Los empleados del club no pagan inscripcion. Como un cupo puede llevar mas
	 * de una persona, lo que se cobra es la parte proporcional de los integrantes
	 * que si pagan: un jugador solo paga la tarifa completa, un empleado solo
	 * paga cero, y una pareja con un empleado adentro paga la mitad.
	 *
	 * Lo hicimos proporcional y no "si hay un empleado no paga nadie" porque si
	 * no, dos amigos meterian un empleado a la pareja para entrar gratis.
	 *
	 * @param participante el participante que se esta inscribiendo
	 * @return el valor que debe pagar por el cupo
	 */
	@Override
	public double getValorAPagar( Participante participante )
	{
		int integrantes = participante.getIntegrantes( ).size( );
		if( integrantes == 0 )
		{
			return 0.0;
		}
		int quePagan = 0;
		for( Persona integrante : participante.getIntegrantes( ) )
		{
			boolean esEmpleado = integrante instanceof Competidor && ( ( Competidor ) integrante ).esEmpleadoDelClub( );
			if( !esEmpleado )
			{
				quePagan = quePagan + 1;
			}
		}
		return tarifa * quePagan / integrantes;
	}

	/**
	 * CUANTA PLATA SE RECOGIO
	 *
	 * Suma lo que pago cada inscripcion. Como los empleados pagaron cero
	 * entonces no suman a la bolsa, que es justo lo que dice la decision D7 y la
	 * razon por la que el premio baja cuando hay empleados inscritos.
	 *
	 * @return el total recaudado en inscripciones
	 */
	public double getTotalRecaudado( )
	{
		double total = 0.0;
		for( InscripcionTorneo inscripcion : getInscripciones( ) )
		{
			total = total + inscripcion.getValorPagado( );
		}
		return total;
	}

	/**
	 * CUANTO SERIA EL PREMIO
	 *
	 * @return el porcentaje del premio aplicado a lo recaudado
	 */
	public double calcularPremio( )
	{
		return getTotalRecaudado( ) * porcentajePremio;
	}

	/**
	 * ENTREGAR EL PREMIO EN EFECTIVO
	 *
	 * DECISION DE DISENO D8
	 * El enunciado no dice que pasa si gana un empleado, entonces lo decidimos
	 * nosotros: no recibe el efectivo y el premio pasa al participante mejor
	 * ubicado que no sea empleado. Pues el empleado entro gratis, o sea no puso
	 * nada en la bolsa, y seria raro que se llevara la plata de los que si
	 * pagaron.
	 *
	 * la parte del codigo que puede hacerlo estallar es: cuando el campeon es
	 * empleado hay que seguir bajando por la tabla hasta encontrar a alguien que
	 * no lo sea, y puede que no haya nadie. En ese caso el premio se queda en
	 * cero y en el club, que es mejor que reventar y dejar el torneo sin
	 * finalizar.
	 *
	 * @param campeon el participante que gano el torneo
	 * @throws ClubException si el premio no se puede entregar
	 */
	@Override
	protected void entregarPremio( Participante campeon ) throws ClubException
	{
		this.ganadorDelPremio = buscarPrimeroSinEmpleados( campeon );
		if( ganadorDelPremio == null )
		{
			this.premioEntregado = 0.0;
			return;
		}
		this.premioEntregado = calcularPremio( );
	}

	/**
	 * BUSCAR AL PRIMERO QUE NO SEA EMPLEADO
	 *
	 * Arranca por el campeon y si ese tiene empleados adentro entonces sigue
	 * bajando por la tabla de posiciones.
	 *
	 * @param campeon el campeon del torneo
	 * @return el primer participante sin empleados, o null si todos lo son
	 */
	private Participante buscarPrimeroSinEmpleados( Participante campeon )
	{
		if( campeon != null && !campeon.tieneEmpleados( ) )
		{
			return campeon;
		}
		for( PosicionTorneo posicion : getTablaPosiciones( ) )
		{
			if( !posicion.getParticipante( ).tieneEmpleados( ) )
			{
				return posicion.getParticipante( );
			}
		}
		return null;
	}

	public double getTarifa( )
	{
		return tarifa;
	}

	public double getPorcentajePremio( )
	{
		return porcentajePremio;
	}

	public double getPremioEntregado( )
	{
		return premioEntregado;
	}

	public Participante getGanadorDelPremio( )
	{
		return ganadorDelPremio;
	}
}
