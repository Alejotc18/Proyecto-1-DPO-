package uniandes.dpoo.cds.modelo.torneos;

/**
 * ESTADO DEL TORNEO
 *
 * Es el momento en el que va el torneo.
 *
 * DECISION DE DISENO D2
 * El enunciado solo nombra dos estados, En curso y Finalizado. Pero pues si un
 * torneo arranca ya En curso entonces nunca habria un momento para inscribirse
 * ni para salirse, y esas dos historias de usuario quedarian imposibles.
 * Entonces le agregamos Inscripciones abiertas al principio, y Cancelado para
 * cuando el administrador lo tumba antes de que empiece.
 *
 * nota: esto es un enum. Lo usamos aqui porque el estado manda sobre que se
 * puede hacer y que no: solo se inscribe gente si esta en Inscripciones
 * abiertas, solo se registran resultados si esta En curso y asi. Cada valor ya
 * sabe responder eso, entonces las validaciones quedan en un solo lado y no
 * repartidas en ifs por todo el codigo.
 */
public enum EstadoTorneo
{
	INSCRIPCIONES_ABIERTAS( "Inscripciones abiertas" ),
	EN_CURSO( "En curso" ),
	FINALIZADO( "Finalizado" ),
	CANCELADO( "Cancelado" );

	private String nombre;

	private EstadoTorneo( String nombre )
	{
		this.nombre = nombre;
	}

	/**
	 * REVISAR SI TODAVIA SE PUEDE ENTRAR O SALIR
	 *
	 * Solo mientras las inscripciones esten abiertas, pues despues de que el
	 * torneo arranca ya estan armados los encuentros y si alguien se sale
	 * entonces queda un hueco en la llave.
	 *
	 * @return true si el torneo admite inscripciones y desinscripciones
	 */
	public boolean admiteInscripciones( )
	{
		return this == INSCRIPCIONES_ABIERTAS;
	}

	/**
	 * REVISAR SI EL ADMINISTRADOR TODAVIA LO PUEDE TOCAR
	 *
	 * Modificar los cupos o cancelar el torneo solo se puede antes de arrancar.
	 *
	 * @return true si el torneo se puede modificar o cancelar
	 */
	public boolean admiteCambios( )
	{
		return this == INSCRIPCIONES_ABIERTAS;
	}

	/**
	 * REVISAR SI YA SE ESTA JUGANDO
	 *
	 * @return true si el torneo esta En curso
	 */
	public boolean estaEnJuego( )
	{
		return this == EN_CURSO;
	}

	/**
	 * BUSCAR UN ESTADO POR SU NOMBRE
	 *
	 * Sirve para leer el archivo de torneos y para los filtros de la consulta,
	 * pues ahi el estado llega escrito como texto.
	 *
	 * @param nombre el nombre del estado
	 * @return el estado correspondiente, o null si no existe
	 */
	public static EstadoTorneo porNombre( String nombre )
	{
		for( EstadoTorneo estado : values( ) )
		{
			if( estado.nombre.equalsIgnoreCase( nombre ) )
			{
				return estado;
			}
		}
		return null;
	}

	public String getNombre( )
	{
		return nombre;
	}

	@Override
	public String toString( )
	{
		return nombre;
	}
}
