package uniandes.dpoo.cds.modelo.torneos;

import java.io.Serializable;

/**
 * POSICION EN LA TABLA DEL TORNEO
 *
 * Es la fila de un participante en la tabla de posiciones: cuantos encuentros
 * jugo, cuantos gano, cuantos perdio y cuantos puntos lleva.
 *
 * Es otra clase asociacion, pues estos numeros no son del torneo ni del
 * participante sino de ese participante dentro de ese torneo. El mismo equipo
 * puede ir primero en un torneo y ultimo en otro al mismo tiempo.
 *
 * La tabla se va actualizando cada vez que se registra un resultado y no se
 * calcula de un solo golpe al final, pues la historia de usuario de consultar el
 * historial pide poder ver como va el torneo cuando todavia esta En curso.
 */
public class PosicionTorneo implements Serializable
{
	private static final long serialVersionUID = 1L;

	private Participante participante;

	private int jugados;

	private int ganados;

	private int perdidos;

	private int puntos;

	public static final int PUNTOS_POR_VICTORIA = 3;

	public PosicionTorneo( Participante participante )
	{
		this.participante = participante;
		this.jugados = 0;
		this.ganados = 0;
		this.perdidos = 0;
		this.puntos = 0;
	}

	/**
	 * SUMAR UNA VICTORIA
	 *
	 * Le sube los jugados, los ganados y los puntos de una sola vez, pues si
	 * esos tres numeros se actualizaran por separado desde afuera entonces
	 * alguien se olvida de uno y la tabla queda sin cuadrar.
	 */
	public void registrarVictoria( )
	{
		jugados = jugados + 1;
		ganados = ganados + 1;
		puntos = puntos + PUNTOS_POR_VICTORIA;
	}

	/**
	 * SUMAR UNA DERROTA
	 *
	 * Sube los jugados y los perdidos pero no da puntos, pues en eliminacion el
	 * que pierde no suma nada.
	 */
	public void registrarDerrota( )
	{
		jugados = jugados + 1;
		perdidos = perdidos + 1;
	}

	public Participante getParticipante( )
	{
		return participante;
	}

	public void setParticipante( Participante participante )
	{
		this.participante = participante;
	}

	public int getJugados( )
	{
		return jugados;
	}

	public int getGanados( )
	{
		return ganados;
	}

	public int getPerdidos( )
	{
		return perdidos;
	}

	public int getPuntos( )
	{
		return puntos;
	}

	@Override
	public String toString( )
	{
		return participante.getNombre( ) + " | PJ " + jugados + " | PG " + ganados + " | PP " + perdidos + " | PTS " + puntos;
	}
}
