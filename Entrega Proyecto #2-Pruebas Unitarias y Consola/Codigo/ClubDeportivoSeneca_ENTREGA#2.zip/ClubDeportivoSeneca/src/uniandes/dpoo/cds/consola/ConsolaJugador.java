package uniandes.dpoo.cds.consola;

import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.personas.Afiliado;
import uniandes.dpoo.cds.modelo.personas.Estudiante;
import uniandes.dpoo.cds.modelo.personas.Externo;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.modelo.tienda.Bono;
import uniandes.dpoo.cds.modelo.tienda.Producto;
import uniandes.dpoo.cds.modelo.tienda.VentaTienda;
import uniandes.dpoo.cds.modelo.torneos.EstadoTorneo;
import uniandes.dpoo.cds.modelo.torneos.InscripcionTorneo;
import uniandes.dpoo.cds.modelo.torneos.Torneo;

/**
 * PROGRAMA DE CONSOLA DEL JUGADOR
 *
 * Es el programa de los que compiten: los afiliados del club, los estudiantes de
 * la universidad y la gente externa.
 *
 * Desde aqui ven que torneos hay abiertos, se inscriben solos, en pareja o con
 * su equipo, se salen si cambian de opinion, miran el historial de un torneo y
 * revisan los bonos que se han ganado.
 *
 * El jugador no decide si entra por cupo preferencial o regular: eso lo resuelve
 * la fachada mirando el ranking, y aqui apenas se le informa por cual entro.
 */
public class ConsolaJugador extends ConsolaBase
{
	@Override
	protected String getTitulo( )
	{
		return "CLUB DEPORTIVO SENECA - CONSOLA DEL JUGADOR";
	}

	/**
	 * QUIEN PUEDE ENTRAR AQUI
	 *
	 * Los afiliados del club, los estudiantes y los externos. El administrador no
	 * entra porque no compite, y los empleados tienen su propio programa porque
	 * sus reglas son distintas.
	 *
	 * @param persona la persona que se autentico
	 * @return true si esa persona compite en torneos
	 */
	@Override
	protected boolean admiteUsuario( Persona persona )
	{
		return persona instanceof Afiliado || persona instanceof Estudiante || persona instanceof Externo;
	}

	@Override
	protected String[] getOpciones( )
	{
		return new String[] {
				"Ver los torneos y su estado",
				"Inscribirme en un torneo individual",
				"Inscribirme en un torneo de dobles con un companero",
				"Inscribir a mi equipo en un torneo de conjunto",
				"Salirme de un torneo",
				"Ver en que torneos estoy",
				"Ver el historial de un torneo",
				"Ver mis bonos",
				"Redimir un bono en una compra" };
	}

	@Override
	protected void atender( int opcion ) throws Exception
	{
		if( opcion == 1 )
		{
			verTorneos( );
		}
		else if( opcion == 2 )
		{
			inscribirmeIndividual( );
		}
		else if( opcion == 3 )
		{
			inscribirmeEnDobles( );
		}
		else if( opcion == 4 )
		{
			inscribirMiEquipo( );
		}
		else if( opcion == 5 )
		{
			salirmeDeUnTorneo( );
		}
		else if( opcion == 6 )
		{
			verMisTorneos( );
		}
		else if( opcion == 7 )
		{
			verHistorial( );
		}
		else if( opcion == 8 )
		{
			verMisBonos( );
		}
		else if( opcion == 9 )
		{
			redimirBono( );
		}
	}

	private void verTorneos( )
	{
		System.out.println( "Filtrar:  1. Todos   2. Abiertos   3. En curso   4. Finalizados" );
		int opcion = entrada.leerOpcion( 1, 4 );
		EstadoTorneo filtro = null;
		if( opcion == 2 )
		{
			filtro = EstadoTorneo.INSCRIPCIONES_ABIERTAS;
		}
		else if( opcion == 3 )
		{
			filtro = EstadoTorneo.EN_CURSO;
		}
		else if( opcion == 4 )
		{
			filtro = EstadoTorneo.FINALIZADO;
		}

		System.out.println( );
		for( Torneo torneo : club.consultarTorneos( filtro ) )
		{
			System.out.println( "   " + torneo + " | " + torneo.getDisciplina( ) + " | " + torneo.getFecha( ) );
			if( torneo.getEstado( ).admiteInscripciones( ) )
			{
				System.out.println( "        cupos libres: " + torneo.getCuposPreferencialesDisponibles( ) + " preferenciales y " + torneo.getCuposRegularesDisponibles( ) + " regulares" );
			}
		}
	}

	/**
	 * MOSTRAR LOS TORNEOS ABIERTOS Y PEDIR UNO
	 *
	 * @return el torneo que escogio el usuario
	 * @throws Exception si el codigo no corresponde a ningun torneo
	 */
	private Torneo pedirTorneoAbierto( ) throws Exception
	{
		System.out.println( "Torneos con inscripciones abiertas:" );
		for( Torneo torneo : club.consultarTorneos( EstadoTorneo.INSCRIPCIONES_ABIERTAS ) )
		{
			System.out.println( "   " + torneo + " | " + torneo.getDisciplina( ) + " | " + torneo.getFecha( ) );
		}
		return pedirTorneoPorCodigo( );
	}

	private Torneo pedirTorneoPorCodigo( ) throws Exception
	{
		String codigo = entrada.leerTexto( "\nCodigo del torneo" );
		Torneo torneo = club.buscarTorneo( codigo );
		if( torneo == null )
		{
			throw new Exception( "No existe ningun torneo con el codigo " + codigo );
		}
		return torneo;
	}

	private void inscribirmeIndividual( ) throws Exception
	{
		Torneo torneo = pedirTorneoAbierto( );

		InscripcionTorneo inscripcion = club.inscribirEnTorneo( torneo, usuario, LocalDate.now( ) );

		mostrarInscripcion( inscripcion );
	}

	private void inscribirmeEnDobles( ) throws Exception
	{
		Torneo torneo = pedirTorneoAbierto( );
		String documento = entrada.leerTexto( "Documento de su companero de pareja" );
		Persona companero = club.buscarPersona( documento );
		if( companero == null )
		{
			throw new Exception( "No hay nadie registrado con el documento " + documento );
		}

		InscripcionTorneo inscripcion = club.inscribirParejaEnTorneo( torneo, usuario, companero, LocalDate.now( ) );

		System.out.println( "\n   Pareja inscrita: " + inscripcion.getParticipante( ).getNombre( ) );
		mostrarInscripcion( inscripcion );
	}

	private void inscribirMiEquipo( ) throws Exception
	{
		Torneo torneo = pedirTorneoAbierto( );

		System.out.println( "\nEquipos del club:" );
		for( Equipo equipo : club.getEquipos( ).values( ) )
		{
			System.out.println( "   " + equipo.getCodigo( ) + " | " + equipo.getNombre( ) + " | " + equipo.getReglas( ).getNombre( ) + " | " + equipo.getCategoria( ).getNombre( ) + " | " + equipo.getJugadoresHabilitados( ).size( ) + " jugadores habilitados" );
		}
		String codigoEquipo = entrada.leerTexto( "\nCodigo del equipo" );
		Equipo equipo = club.buscarEquipo( codigoEquipo );
		if( equipo == null )
		{
			throw new Exception( "No existe ningun equipo con el codigo " + codigoEquipo );
		}

		InscripcionTorneo inscripcion = club.inscribirEquipoEnTorneo( torneo, equipo, LocalDate.now( ) );

		mostrarInscripcion( inscripcion );
	}

	private void mostrarInscripcion( InscripcionTorneo inscripcion )
	{
		String tipoCupo = "regular";
		if( inscripcion.isPreferencial( ) )
		{
			tipoCupo = "PREFERENCIAL, por su puesto en el ranking";
		}
		System.out.println( "\n   Inscripcion lista" );
		System.out.println( "   Tipo de cupo: " + tipoCupo );
		System.out.println( "   Valor a pagar: " + String.format( "%.2f", inscripcion.getValorPagado( ) ) );
		System.out.println( "   Cupos que quedan: " + inscripcion.getTorneo( ).getCuposPreferencialesDisponibles( ) + " preferenciales y " + inscripcion.getTorneo( ).getCuposRegularesDisponibles( ) + " regulares" );
	}

	private void salirmeDeUnTorneo( ) throws Exception
	{
		verMisTorneos( );
		Torneo torneo = pedirTorneoPorCodigo( );

		club.desinscribirDeTorneo( torneo, usuario );

		System.out.println( "\n   Listo, ya no esta inscrito en " + torneo.getNombre( ) );
		System.out.println( "   Si estaba en una pareja de dobles entonces su companero tambien salio, porque el cupo era de los dos" );
	}

	private void verMisTorneos( )
	{
		System.out.println( "Torneos en los que esta inscrito:" );
		int encontrados = 0;
		for( Torneo torneo : club.getTorneos( ).values( ) )
		{
			InscripcionTorneo inscripcion = torneo.buscarInscripcionDe( usuario );
			if( inscripcion != null )
			{
				System.out.println( "   " + torneo.getCodigo( ) + " | " + torneo.getNombre( ) + " | " + torneo.getEstado( ).getNombre( ) + " | " + inscripcion );
				encontrados = encontrados + 1;
			}
		}
		if( encontrados == 0 )
		{
			System.out.println( "   (ninguno)" );
		}
	}

	private void verHistorial( ) throws Exception
	{
		Torneo torneo = pedirTorneoPorCodigo( );

		System.out.println( );
		System.out.println( torneo.getHistorial( ) );
	}

	private void verMisBonos( )
	{
		System.out.println( "Sus bonos:" );
		if( club.getBonosDe( usuario ).isEmpty( ) )
		{
			System.out.println( "   (todavia no ha ganado ninguno)" );
			return;
		}
		for( Bono bono : club.getBonosDe( usuario ) )
		{
			System.out.println( "   " + bono );
		}
	}

	/**
	 * REDIMIR UN BONO EN UNA COMPRA
	 *
	 * Arma una venta de tienda con un producto, le pega el bono y la liquida. El
	 * bono se gasta en el momento de liquidar y no antes, entonces si algo falla
	 * en la mitad el bono no se pierde.
	 *
	 * @throws Exception si el bono no se puede usar en esa compra
	 */
	private void redimirBono( ) throws Exception
	{
		verMisBonos( );
		String codigoBono = entrada.leerTexto( "\nCodigo del bono" );
		Bono bono = usuario.buscarBono( codigoBono );
		if( bono == null )
		{
			throw new Exception( "Usted no tiene ningun bono con el codigo " + codigoBono );
		}

		System.out.println( "\nProductos:" );
		for( Producto producto : club.getProductos( ).values( ) )
		{
			System.out.println( "   " + producto.getCodigo( ) + " | " + producto.getNombre( ) + " | " + String.format( "%.2f", producto.getPrecio( ) ) );
		}
		String codigoProducto = entrada.leerTexto( "\nCodigo del producto" );
		Producto producto = club.buscarProducto( codigoProducto );
		if( producto == null )
		{
			throw new Exception( "No existe ningun producto con el codigo " + codigoProducto );
		}
		int cantidad = entrada.leerEntero( "Cuantas unidades" );

		VentaTienda venta = new VentaTienda( "V-" + System.currentTimeMillis( ), LocalDate.now( ), usuario );
		venta.agregarItem( producto, cantidad );
		club.redimirBonoEnVenta( venta, bono );
		venta.liquidar( );
		club.agregarVenta( venta );

		System.out.println( );
		System.out.println( venta.getRecibo( ) );
	}

	/**
	 * ARRANCAR EL PROGRAMA DEL JUGADOR
	 *
	 * @param args no se usan
	 */
	public static void main( String[] args )
	{
		new ConsolaJugador( ).arrancar( );
	}
}
