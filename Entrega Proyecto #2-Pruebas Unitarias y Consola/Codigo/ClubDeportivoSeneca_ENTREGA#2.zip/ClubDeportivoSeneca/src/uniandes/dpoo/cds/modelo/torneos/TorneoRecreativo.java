package uniandes.dpoo.cds.modelo.torneos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.modelo.tienda.Bono;

/**
 * TORNEO RECREATIVO
 *
 * Es el torneo que no cobra inscripcion y que premia con un bono de descuento
 * para la tienda o la cafeteria.
 *
 * DECISION DE DISENO D9
 * El bono se le da a cada integrante del ganador y no uno solo a repartir, pues
 * un descuento no se puede partir en dos. Entonces si gana una pareja de dobles
 * salen dos bonos, uno para cada uno, y si gana un equipo sale uno por jugador
 * habilitado.
 *
 * Y aqui si el campeon es empleado tambien recibe su bono, al contrario de lo
 * que pasa con la plata del competitivo. Pues el bono es un descuento en la
 * tienda y el club no esta sacando plata de la bolsa de nadie.
 */
public class TorneoRecreativo extends Torneo
{
	private static final long serialVersionUID = 1L;

	// Igual que en los otros, el porcentaje va como fraccion: 15% es 0.15.
	private double porcentajeBono;

	private List<Bono> bonosEntregados;

	/**
	 * CREAR EL TORNEO RECREATIVO
	 *
	 * Revisa que el porcentaje del bono este entre 1 y 100, pues un bono del 0%
	 * no es premio y uno de mas del 100% seria regalar plata.
	 *
	 * @param codigo el codigo del torneo
	 * @param nombre el nombre del torneo
	 * @param modalidad conjunto, individual o dobles
	 * @param disciplina el deporte o la disciplina
	 * @param nivel el nivel exigido, o null en los de conjunto
	 * @param categoria la categoria exigida, o null en los individuales y de dobles
	 * @param fecha la fecha en la que se juega
	 * @param cupos el numero total de cupos
	 * @param porcentajeBono la fraccion de descuento que da el bono
	 * @throws OperacionNoPermitidaException si el porcentaje del bono esta fuera de rango
	 */
	public TorneoRecreativo( String codigo, String nombre, Modalidad modalidad, String disciplina, Nivel nivel, Categoria categoria, LocalDate fecha, int cupos, double porcentajeBono ) throws OperacionNoPermitidaException
	{
		super( codigo, nombre, modalidad, disciplina, nivel, categoria, fecha, cupos );
		if( porcentajeBono <= 0 || porcentajeBono > 1 )
		{
			throw new OperacionNoPermitidaException( "El porcentaje del bono debe estar entre 1% y 100%, o sea entre 0.01 y 1, y llego " + porcentajeBono );
		}
		this.porcentajeBono = porcentajeBono;
		this.bonosEntregados = new ArrayList<Bono>( );
	}

	@Override
	public String getTipo( )
	{
		return "Recreativo";
	}

	/**
	 * CUANTO LE TOCA PAGAR
	 *
	 * Nada, los torneos recreativos son gratis.
	 *
	 * @param participante el participante que se esta inscribiendo
	 * @return siempre cero
	 */
	@Override
	public double getValorAPagar( Participante participante )
	{
		return 0.0;
	}

	/**
	 * ENTREGAR LOS BONOS
	 *
	 * Le crea un bono a cada integrante del campeon y se lo mete a su lista, pues
	 * el bono queda atado a su dueno y nadie mas lo puede usar.
	 *
	 * @param campeon el participante que gano el torneo
	 * @throws ClubException si el campeon no tiene integrantes a quien premiar
	 */
	@Override
	protected void entregarPremio( Participante campeon ) throws ClubException
	{
		if( campeon == null || campeon.getIntegrantes( ).isEmpty( ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + getCodigo( ) + " no tiene a quien entregarle los bonos" );
		}

		int numero = 1;
		for( Persona integrante : campeon.getIntegrantes( ) )
		{
			String codigoBono = getCodigo( ) + "-BONO-" + numero;
			Bono bono = new Bono( codigoBono, integrante, porcentajeBono, getCodigo( ), getNombre( ) );
			integrante.agregarBono( bono );
			bonosEntregados.add( bono );
			numero = numero + 1;
		}
	}

	public double getPorcentajeBono( )
	{
		return porcentajeBono;
	}

	public List<Bono> getBonosEntregados( )
	{
		return bonosEntregados;
	}
}
