package uniandes.dpoo.cds.modelo.entrenamiento;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.personas.Empleado;

/**
 * TURNO
 *
 * Es el bloque de horas en que un empleado esta disponible dentro del horario
 * de atencion del club.
 *
 * CORRECCION DE LA ENTREGA 1
 * Antes un turno podia tener maximo una solicitud de cambio. Pero pues si a uno
 * le rechazan la solicitud entonces deberia poder volver a pedir, asi que lo
 * pasamos a muchas. La regla de que solo puede haber UNA pendiente al tiempo la
 * revisa el metodo tieneSolicitudPendiente, o sea la cuidamos con codigo y no
 * apretando la cardinalidad.
 */
public class Turno implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private Empleado empleado;

	private String diaSemana;

	private String semana;

	private LocalTime horaInicio;

	private LocalTime horaFin;

	private boolean vigente;

	private List<SolicitudCambioTurno> solicitudes;

	public Turno( String codigo, Empleado empleado, String diaSemana, String semana, LocalTime horaInicio, LocalTime horaFin )
	{
		this.codigo = codigo;
		this.empleado = empleado;
		this.diaSemana = diaSemana;
		this.semana = semana;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
		this.vigente = true;
		this.solicitudes = new ArrayList<SolicitudCambioTurno>( );
	}

	/**
	 * REVISAR SI HAY UNA SOLICITUD SIN RESPONDER
	 *
	 * @return true si existe una solicitud pendiente
	 */
	public boolean tieneSolicitudPendiente( )
	{
		for( SolicitudCambioTurno solicitud : solicitudes )
		{
			if( solicitud.estaPendiente( ) )
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * REVISAR SI ESTE TURNO CAE EN UNA FECHA
	 *
	 * CAMBIO DEL PROYECTO 2, DECISION DE DISENO D10
	 * El torneo tiene una fecha de calendario, pero el turno esta guardado como
	 * dia de la semana y semana, que fue como lo hicimos en la Entrega 1 porque
	 * los turnos del club se repiten semana a semana. Entonces para saber si un
	 * empleado esta de turno el dia del torneo hay que traducir la fecha a esos
	 * dos textos y comparar, y eso es lo que hace este metodo.
	 *
	 * @param fecha la fecha que se quiere revisar
	 * @return true si el turno esta vigente y cae en esa fecha
	 */
	public boolean cubre( LocalDate fecha )
	{
		if( !vigente || fecha == null )
		{
			return false;
		}
		return diaSemana.equalsIgnoreCase( diaSemanaDe( fecha ) ) && semana.equalsIgnoreCase( semanaDe( fecha ) );
	}

	/**
	 * QUE DIA DE LA SEMANA ES ESA FECHA
	 *
	 * nota: aqui usamos java.time otra vez. getDayOfWeek() de un LocalDate
	 * devuelve un valor de DayOfWeek, que es un enum de Java con los siete dias,
	 * y getValue() lo pasa a numero del 1 al 7 empezando en lunes. Con ese numero
	 * sacamos el nombre del arreglo.
	 *
	 * Lo hicimos con el arreglo y no con el nombre que trae Java porque ese llega
	 * en ingles y en mayusculas, o sea MONDAY, y los turnos del club estan
	 * escritos en espanol.
	 *
	 * @param fecha la fecha que se quiere traducir
	 * @return el nombre del dia en espanol
	 */
	public static String diaSemanaDe( LocalDate fecha )
	{
		return DIAS[fecha.getDayOfWeek( ).getValue( ) - 1];
	}

	/**
	 * EN QUE SEMANA DEL ANO CAE ESA FECHA
	 *
	 * nota: WeekFields.ISO es la forma estandar de numerar las semanas, donde la
	 * semana arranca el lunes. El texto queda como 2026-W49, que es el formato
	 * que usamos para guardar la semana en los turnos.
	 *
	 * @param fecha la fecha que se quiere traducir
	 * @return el identificador de la semana
	 */
	public static String semanaDe( LocalDate fecha )
	{
		int numero = fecha.get( WeekFields.ISO.weekOfWeekBasedYear( ) );
		int ano = fecha.get( WeekFields.ISO.weekBasedYear( ) );
		return ano + "-W" + String.format( "%02d", numero );
	}

	public static final String[] DIAS = { "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo" };

	public void agregarSolicitud( SolicitudCambioTurno solicitud )
	{
		solicitudes.add( solicitud );
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public Empleado getEmpleado( )
	{
		return empleado;
	}

	public void setEmpleado( Empleado empleado )
	{
		this.empleado = empleado;
	}

	public String getDiaSemana( )
	{
		return diaSemana;
	}

	public void setDiaSemana( String diaSemana )
	{
		this.diaSemana = diaSemana;
	}

	public String getSemana( )
	{
		return semana;
	}

	public void setSemana( String semana )
	{
		this.semana = semana;
	}

	public LocalTime getHoraInicio( )
	{
		return horaInicio;
	}

	public void setHoraInicio( LocalTime horaInicio )
	{
		this.horaInicio = horaInicio;
	}

	public LocalTime getHoraFin( )
	{
		return horaFin;
	}

	public void setHoraFin( LocalTime horaFin )
	{
		this.horaFin = horaFin;
	}

	public boolean isVigente( )
	{
		return vigente;
	}

	public void setVigente( boolean vigente )
	{
		this.vigente = vigente;
	}

	public List<SolicitudCambioTurno> getSolicitudes( )
	{
		return solicitudes;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + empleado.getNombreCompleto( ) + " | " + diaSemana + " " + semana + " | " + horaInicio + "-" + horaFin;
	}
}
