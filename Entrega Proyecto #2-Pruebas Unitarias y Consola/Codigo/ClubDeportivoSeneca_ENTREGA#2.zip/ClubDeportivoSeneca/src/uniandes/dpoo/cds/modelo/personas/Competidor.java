package uniandes.dpoo.cds.modelo.personas;

import java.io.Serializable;

import uniandes.dpoo.cds.modelo.academias.Nivel;

/**
 * COMPETIDOR
 *
 * Esta interfaz la implementa todo el que puede meterse a un torneo individual
 * o de dobles.
 *
 * Y es que el enunciado del Proyecto 2 dice que a los torneos entran afiliados
 * del club, estudiantes de la universidad, gente de afuera y tambien los
 * empleados. Esos cuatro no tienen nada mas en comun: un afiliado individual
 * tiene su inscripcion a la academia con su ranking, mientras que un estudiante
 * de la universidad apenas llega y dice en que nivel juega.
 *
 * Entonces en vez de andar preguntando con instanceof de que clase es cada uno,
 * les pedimos las dos cosas que el torneo de verdad necesita: en que nivel juega
 * y cuanto puntaje tiene. Cada clase contesta a su manera y el torneo ni se
 * enterea de con quien esta hablando, que es polimorfismo.
 *
 * POR QUE ESTA EN EL PAQUETE DE PERSONAS Y NO EN EL DE TORNEOS
 * La habiamos puesto en modelo.torneos, que era donde se nos ocurrio primero
 * porque es el torneo el que la usa. Pero entonces el paquete de personas
 * quedaba importando el de torneos y el de torneos importando el de personas, o
 * sea un ciclo nuevo entre los dos. Pasandola para aca el ciclo desaparece: las
 * personas no saben nada de torneos y torneos si usa personas, en un solo
 * sentido. Ademas conceptualmente es de aca, pues "saber competir" es algo de la
 * persona y no del torneo.
 *
 * DECISION DE DISENO D5
 * El puntaje es lo que decide quien tiene derecho a cupo preferencial. Como el
 * ranking es del club, el que no esta inscrito en la academia de esa disciplina
 * devuelve cero y entonces entra por cupo regular como todo el mundo.
 */
public interface Competidor extends Serializable
{
	/**
	 * EN QUE NIVEL JUEGA ESTA DISCIPLINA
	 *
	 * Si la persona no juega esa disciplina devuelve null, entonces hay que
	 * revisarlo antes de comparar.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return el nivel en esa disciplina, o null si no la juega
	 */
	public Nivel getNivelEn( String nombreDisciplina );

	/**
	 * CUANTO PUNTAJE DE RANKING TIENE
	 *
	 * El que no tiene ranking en esa disciplina devuelve cero y asi queda de
	 * ultimo en la fila de los cupos preferenciales.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return el puntaje de ranking, o cero si no tiene
	 */
	public double getPuntajeEn( String nombreDisciplina );

	/**
	 * REVISAR SI ES EMPLEADO DEL CLUB
	 *
	 * De esto dependen dos reglas: el empleado no paga inscripcion y tampoco
	 * recibe el premio en efectivo, que es la decision D8.
	 *
	 * @return true si quien compite trabaja en el club
	 */
	public boolean esEmpleadoDelClub( );
}
