package uniandes.dpoo.cds.modelo.tienda;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.InventarioInsuficienteException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.personas.Afiliado;
import uniandes.dpoo.cds.modelo.personas.Empleado;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * VENTA, PATRON TEMPLATE METHOD
 *
 * Es una venta del club, de la tienda o de la cafeteria.
 *
 * Liquidar una venta es siempre el mismo procedimiento y en el mismo orden:
 * sumar los items, aplicar el descuento si hay codigo, calcular el impuesto
 * sobre lo que quedo, sumar lo adicional y generar los puntos de fidelidad.
 *
 * Entre la tienda y la cafeteria solo cambian dos cositas: el porcentaje del
 * impuesto, que es 19% de IVA contra 8% de impuesto al consumo, y si lleva
 * propina o no.
 *
 * Entonces en vez de copiar y pegar los seis pasos en las dos subclases, el
 * metodo liquidar esta aqui marcado como final y deja dos huecos que cada
 * subclase llena: getPorcentajeImpuesto y calcularValorAdicional. Asi ninguna
 * subclase puede saltarse un paso ni cambiarle el orden y asi.
 *
 * CORRECCION DE LA ENTREGA 1
 * Le quitamos el atributo tipo, pues el rubro ya se sabe por la clase que es.
 */
public abstract class Venta implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private LocalDate fecha;

	private Persona comprador;

	private List<ItemVenta> items;

	private CodigoDescuento codigoDescuento;

	// CAMBIO DEL PROYECTO 2, DECISION DE DISENO D9
	// Es el bono que gano el comprador en un torneo recreativo. Va aparte del
	// codigo de descuento porque son dos cosas distintas: el codigo es del
	// empleado y se puede usar todas las veces, el bono es del ganador y sirve
	// una sola vez. Y son excluyentes, o sea en una venta va uno o va el otro,
	// nunca los dos.
	private Bono bonoRedimido;

	private double subtotal;

	private double descuento;

	private double impuesto;

	private double valorAdicional;

	private double total;

	private int puntosGenerados;

	private int puntosRedimidos;

	private boolean liquidada;

	public Venta( String codigo, LocalDate fecha, Persona comprador )
	{
		this.codigo = codigo;
		this.fecha = fecha;
		this.comprador = comprador;
		this.items = new ArrayList<ItemVenta>( );
		this.liquidada = false;
	}

	/**
	 * QUE IMPUESTO SE COBRA
	 *
	 * Primer hueco del metodo plantilla, lo llena cada subclase.
	 *
	 * @return el porcentaje de impuesto que aplica al rubro de la venta
	 */
	public abstract double getPorcentajeImpuesto( );

	/**
	 * COMO SE LLAMA EL IMPUESTO
	 *
	 * Es para que el recibo diga "IVA" o "Impuesto al consumo" y no un numero
	 * suelto.
	 *
	 * @return el nombre del impuesto, para mostrarlo en el recibo
	 */
	public abstract String getNombreImpuesto( );

	/**
	 * A QUE RUBRO VA LA VENTA
	 *
	 * @return el rubro contable de la venta
	 */
	public abstract String getRubro( );

	/**
	 * LO QUE SE SUMA DESPUES DEL IMPUESTO
	 *
	 * Segundo hueco del metodo plantilla. Por defecto devuelve cero, entonces la
	 * tienda ni lo toca y la cafeteria lo usa para la propina y asi.
	 *
	 * @param base el valor de la venta despues del descuento
	 * @return el valor adicional que se suma al total
	 */
	protected double calcularValorAdicional( double base )
	{
		return 0.0;
	}

	/**
	 * AGREGAR UN PRODUCTO A LA VENTA
	 *
	 * Ademas de meterlo al recibo le descuenta las unidades al inventario de una
	 * vez, pues si no la tienda creeria que todavia tiene esa mercancia.
	 *
	 * Si la venta ya se liquido entonces no deja agregar nada mas, porque los
	 * totales ya estan calculados y quedarian mintiendo.
	 *
	 * @param producto el producto que se lleva el comprador
	 * @param cantidad el numero de unidades
	 * @throws InventarioInsuficienteException si no hay unidades suficientes
	 * @throws OperacionNoPermitidaException si la venta ya fue liquidada
	 */
	public void agregarItem( Producto producto, int cantidad ) throws InventarioInsuficienteException, OperacionNoPermitidaException
	{
		if( liquidada )
		{
			throw new OperacionNoPermitidaException( "La venta " + codigo + " ya fue liquidada y no admite mas items" );
		}
		producto.descontarInventario( cantidad );
		items.add( new ItemVenta( producto, cantidad, producto.getPrecio( ) ) );
	}

	/**
	 * LIQUIDAR LA VENTA, ESTE ES EL METODO PLANTILLA
	 *
	 * Aqui esta el procedimiento completo y en orden. Esta marcado como final a
	 * proposito, o sea ninguna subclase lo puede reescribir.
	 *
	 * Pues el orden importa de verdad: el impuesto se calcula sobre la base YA
	 * descontada, entonces si alguna subclase lo hiciera al reves daria otro
	 * total y los recibos saldrian mal sin que nadie lo note.
	 *
	 * la parte del codigo que puede hacerlo estallar es: implementa el calculo de impuestos, descuentos y puntos de
	 * fidelidad del enunciado.
	 *
	 * @return el valor total que debe pagar el comprador
	 * @throws OperacionNoPermitidaException si la venta no tiene items
	 */
	public final double liquidar( ) throws OperacionNoPermitidaException
	{
		if( items.isEmpty( ) )
		{
			throw new OperacionNoPermitidaException( "No se puede liquidar la venta " + codigo + " porque no tiene items" );
		}

		subtotal = calcularSubtotal( );
		descuento = calcularDescuento( );
		double base = subtotal - descuento;
		impuesto = base * getPorcentajeImpuesto( );
		valorAdicional = calcularValorAdicional( base );
		total = base + impuesto + valorAdicional;
		puntosGenerados = generarPuntosFidelidad( );
		gastarBonoSiHay( );
		liquidada = true;
		return total;
	}

	/**
	 * MARCAR EL BONO COMO GASTADO
	 *
	 * la parte del codigo que puede hacerlo estallar es: el momento en que se
	 * gasta el bono. Se marca aqui adentro de la liquidacion y no cuando el
	 * cajero lo registra, pues si se marcara al registrarlo y despues la venta se
	 * cayera o el cliente se arrepintiera, el bono ya estaria quemado y el socio
	 * perderia su premio sin haber comprado nada.
	 *
	 * @throws OperacionNoPermitidaException si el bono ya estaba usado
	 */
	private void gastarBonoSiHay( ) throws OperacionNoPermitidaException
	{
		if( bonoRedimido != null )
		{
			bonoRedimido.marcarUsado( fecha );
		}
	}

	/**
	 * SUMAR TODOS LOS ITEMS
	 *
	 * Es el paso uno de la liquidacion.
	 *
	 * @return el subtotal antes de descuentos e impuestos
	 */
	private double calcularSubtotal( )
	{
		double suma = 0.0;
		for( ItemVenta item : items )
		{
			suma = suma + item.getSubtotal( );
		}
		return suma;
	}

	/**
	 * CALCULAR EL DESCUENTO
	 *
	 * El codigo del empleado vale 15% si lo usa el mismo y 8% si se lo presta a
	 * un afiliado. No es acumulable, entonces se aplica uno solo y ya.
	 *
	 * CAMBIO DEL PROYECTO 2
	 * Ahora el descuento tambien puede venir de un bono de torneo. Como no son
	 * acumulables, los metodos que los registran ya se encargaron de que solo
	 * haya uno de los dos, entonces aqui es un if y no una suma.
	 *
	 * @return el valor que se descuenta del subtotal
	 */
	private double calcularDescuento( )
	{
		if( bonoRedimido != null )
		{
			return bonoRedimido.calcularDescuento( calcularSubtotal( ) );
		}
		if( codigoDescuento == null || !codigoDescuento.isActivo( ) )
		{
			return 0.0;
		}
		boolean esTitular = codigoDescuento.getTitular( ).equals( comprador );
		double porcentaje = codigoDescuento.getPorcentajeAplicable( esTitular );
		return calcularSubtotal( ) * porcentaje;
	}

	/**
	 * GENERAR LOS PUNTOS DE FIDELIDAD
	 *
	 * Solo los afiliados acumulan puntos, pues el administrador no es afiliado y
	 * los empleados tampoco tienen saldo. Entonces aqui toca revisar quien es el
	 * comprador antes de sumarle nada.
	 *
	 * @return la cantidad de puntos generados
	 */
	private int generarPuntosFidelidad( )
	{
		if( comprador instanceof Afiliado )
		{
			Afiliado afiliado = ( Afiliado ) comprador;
			return afiliado.acumularPuntos( total );
		}
		return 0;
	}

	/**
	 * APLICAR UN CODIGO DE DESCUENTO
	 *
	 * Si la venta ya se liquido o el codigo esta inactivo entonces revienta, pues
	 * no se puede descontar sobre un total que ya se calculo.
	 *
	 * @param codigoDescuento el codigo que se quiere usar
	 * @throws OperacionNoPermitidaException si la venta ya fue liquidada o el codigo esta inactivo
	 */
	public void aplicarDescuento( CodigoDescuento codigoDescuento ) throws OperacionNoPermitidaException
	{
		if( liquidada )
		{
			throw new OperacionNoPermitidaException( "La venta " + codigo + " ya fue liquidada" );
		}
		if( codigoDescuento == null || !codigoDescuento.isActivo( ) )
		{
			throw new OperacionNoPermitidaException( "El codigo de descuento no esta activo" );
		}
		if( bonoRedimido != null )
		{
			throw new OperacionNoPermitidaException( "La venta " + codigo + " ya tiene el bono " + bonoRedimido.getCodigo( ) + " y los descuentos no son acumulables" );
		}
		this.codigoDescuento = codigoDescuento;
	}

	/**
	 * REDIMIR UN BONO DE TORNEO
	 *
	 * DECISION DE DISENO D9
	 * Revisa cuatro cosas, y las cuatro salen de la historia de usuario: que la
	 * venta no este liquidada, que el bono no se haya usado, que el bono sea del
	 * que esta comprando, y que la venta no traiga ya otro descuento ni puntos
	 * redimidos.
	 *
	 * la parte del codigo que puede hacerlo estallar es: lo del dueno. El bono
	 * esta atado a la persona que lo gano, entonces aunque alguien sepa el codigo
	 * no se lo puede aplicar a su propia compra. Si no revisaramos esto, un
	 * socio podria pasarle el codigo a un amigo y el premio del torneo se
	 * volveria un descuento que circula por todo el club.
	 *
	 * @param bono el bono que el comprador quiere usar
	 * @throws OperacionNoPermitidaException si la venta ya se liquido, si el bono ya se uso, si no es del comprador o si la venta ya trae otro descuento
	 */
	public void redimirBono( Bono bono ) throws OperacionNoPermitidaException
	{
		if( liquidada )
		{
			throw new OperacionNoPermitidaException( "La venta " + codigo + " ya fue liquidada" );
		}
		if( bono == null )
		{
			throw new OperacionNoPermitidaException( "No se recibio ningun bono para redimir" );
		}
		if( bono.isUsado( ) )
		{
			throw new OperacionNoPermitidaException( "El bono " + bono.getCodigo( ) + " ya fue usado el " + bono.getFechaUso( ) );
		}
		if( !bono.esDe( comprador ) )
		{
			throw new OperacionNoPermitidaException( "El bono " + bono.getCodigo( ) + " es de " + bono.getDueno( ).getNombreCompleto( ) + " y no de quien esta comprando" );
		}
		if( codigoDescuento != null || puntosRedimidos > 0 )
		{
			throw new OperacionNoPermitidaException( "La venta " + codigo + " ya tiene otro descuento aplicado y el bono no es acumulable" );
		}
		this.bonoRedimido = bono;
	}

	/**
	 * REVISAR SI EL COMPRADOR ES EMPLEADO
	 *
	 * De esto depende si el descuento es del 15% o del 8%.
	 *
	 * @return true si quien compra es un empleado del club
	 */
	public boolean compraEmpleado( )
	{
		return comprador instanceof Empleado;
	}

	/**
	 * ARMAR EL RECIBO
	 *
	 * Muestra cada rubro por aparte, o sea el subtotal, el descuento, el impuesto
	 * y la propina, pues asi el afiliado ve de donde salio el total y no solo el
	 * numero final.
	 *
	 * @return el recibo con todos los rubros discriminados
	 */
	public String getRecibo( )
	{
		StringBuilder texto = new StringBuilder( );
		texto.append( "Venta " ).append( codigo ).append( " - " ).append( getRubro( ) ).append( " - " ).append( fecha ).append( "\n" );
		texto.append( "Comprador: " ).append( comprador.getNombreCompleto( ) ).append( "\n" );
		for( ItemVenta item : items )
		{
			texto.append( "   " ).append( item.toString( ) ).append( "\n" );
		}
		texto.append( "   Subtotal          : " ).append( String.format( "%.2f", subtotal ) ).append( "\n" );
		if( descuento > 0 )
		{
			texto.append( "   Descuento         : -" ).append( String.format( "%.2f", descuento ) ).append( "\n" );
		}
		texto.append( "   " ).append( getNombreImpuesto( ) ).append( " : " ).append( String.format( "%.2f", impuesto ) ).append( "\n" );
		if( valorAdicional > 0 )
		{
			texto.append( "   Propina           : " ).append( String.format( "%.2f", valorAdicional ) ).append( "\n" );
		}
		texto.append( "   TOTAL             : " ).append( String.format( "%.2f", total ) ).append( "\n" );
		texto.append( "   Puntos generados  : " ).append( puntosGenerados );
		return texto.toString( );
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public LocalDate getFecha( )
	{
		return fecha;
	}

	public void setFecha( LocalDate fecha )
	{
		this.fecha = fecha;
	}

	public Persona getComprador( )
	{
		return comprador;
	}

	public void setComprador( Persona comprador )
	{
		this.comprador = comprador;
	}

	public List<ItemVenta> getItems( )
	{
		return items;
	}

	public CodigoDescuento getCodigoDescuento( )
	{
		return codigoDescuento;
	}

	public Bono getBonoRedimido( )
	{
		return bonoRedimido;
	}

	public double getSubtotal( )
	{
		return subtotal;
	}

	public double getDescuento( )
	{
		return descuento;
	}

	public double getImpuesto( )
	{
		return impuesto;
	}

	public double getValorAdicional( )
	{
		return valorAdicional;
	}

	public double getTotal( )
	{
		return total;
	}

	public int getPuntosGenerados( )
	{
		return puntosGenerados;
	}

	public int getPuntosRedimidos( )
	{
		return puntosRedimidos;
	}

	public void setPuntosRedimidos( int puntosRedimidos )
	{
		this.puntosRedimidos = puntosRedimidos;
	}

	public boolean isLiquidada( )
	{
		return liquidada;
	}

	@Override
	public String toString( )
	{
		return codigo + " | " + fecha + " | " + getRubro( ) + " | total " + String.format( "%.2f", total );
	}
}
