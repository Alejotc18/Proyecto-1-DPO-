package uniandes.dpoo.cds.modelo.tienda;

import java.io.Serializable;
import java.time.LocalDate;

import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * BONO DE DESCUENTO
 *
 * Es el premio de los torneos recreativos: en vez de plata, el que gana se lleva
 * un descuento para una compra en la tienda o en la cafeteria.
 *
 * Lo pusimos aqui en el paquete de la tienda y al lado de CodigoDescuento porque
 * cumple el mismo papel, o sea es un instrumento de descuento que la venta sabe
 * aplicar. Y por eso mismo no guarda el objeto Torneo sino su codigo y su nombre
 * como texto: asi el paquete de la tienda no queda dependiendo del paquete de
 * torneos y la grafica de paquetes no se nos llena de flechas cruzadas.
 *
 * DECISION DE DISENO D9
 * El bono es de una sola compra, es de su dueno y nadie mas, y no se junta con
 * ningun otro descuento.
 */
public class Bono implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private Persona dueno;

	// El porcentaje se guarda como fraccion, o sea un bono del 15% aqui es 0.15.
	// Lo dejamos igual que en CodigoDescuento para no tener dos convenciones
	// distintas en el mismo paquete, que es de donde salen los errores tontos.
	private double porcentajeDescuento;

	private String codigoTorneo;

	private String nombreTorneo;

	private boolean usado;

	private LocalDate fechaUso;

	public Bono( String codigo, Persona dueno, double porcentajeDescuento, String codigoTorneo, String nombreTorneo )
	{
		this.codigo = codigo;
		this.dueno = dueno;
		this.porcentajeDescuento = porcentajeDescuento;
		this.codigoTorneo = codigoTorneo;
		this.nombreTorneo = nombreTorneo;
		this.usado = false;
	}

	/**
	 * REVISAR SI EL BONO ES DE ESA PERSONA
	 *
	 * Compara por documento y no por el objeto, pues si el club se recarga desde
	 * un archivo entonces los objetos son otros aunque la persona sea la misma.
	 *
	 * @param persona la persona que lo quiere usar
	 * @return true si el bono le pertenece
	 */
	public boolean esDe( Persona persona )
	{
		if( persona == null )
		{
			return false;
		}
		return dueno.getDocumento( ).equals( persona.getDocumento( ) );
	}

	/**
	 * CALCULAR CUANTO DESCUENTA
	 *
	 * @param base el valor sobre el que se aplica el descuento
	 * @return el valor que se le resta a la compra
	 */
	public double calcularDescuento( double base )
	{
		return base * porcentajeDescuento;
	}

	/**
	 * MARCAR EL BONO COMO GASTADO
	 *
	 * Si ya estaba usado entonces revienta, pues el bono es de una sola compra y
	 * si dejaramos usarlo dos veces el club estaria regalando el doble de lo que
	 * prometio.
	 *
	 * @param fecha la fecha en que se uso
	 * @throws OperacionNoPermitidaException si el bono ya habia sido usado
	 */
	public void marcarUsado( LocalDate fecha ) throws OperacionNoPermitidaException
	{
		if( usado )
		{
			throw new OperacionNoPermitidaException( "El bono " + codigo + " ya fue usado el " + fechaUso );
		}
		this.usado = true;
		this.fechaUso = fecha;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public Persona getDueno( )
	{
		return dueno;
	}

	public void setDueno( Persona dueno )
	{
		this.dueno = dueno;
	}

	public double getPorcentajeDescuento( )
	{
		return porcentajeDescuento;
	}

	public void setPorcentajeDescuento( double porcentajeDescuento )
	{
		this.porcentajeDescuento = porcentajeDescuento;
	}

	public String getCodigoTorneo( )
	{
		return codigoTorneo;
	}

	public String getNombreTorneo( )
	{
		return nombreTorneo;
	}

	public boolean isUsado( )
	{
		return usado;
	}

	public LocalDate getFechaUso( )
	{
		return fechaUso;
	}

	@Override
	public String toString( )
	{
		String estado = "disponible";
		if( usado )
		{
			estado = "usado el " + fechaUso;
		}
		return codigo + " | " + String.format( "%.0f", porcentajeDescuento * 100 ) + "% | torneo " + nombreTorneo + " | " + estado;
	}
}
