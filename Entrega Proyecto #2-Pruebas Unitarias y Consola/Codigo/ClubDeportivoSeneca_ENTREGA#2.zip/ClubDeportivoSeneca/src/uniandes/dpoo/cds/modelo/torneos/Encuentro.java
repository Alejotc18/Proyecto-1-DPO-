package uniandes.dpoo.cds.modelo.torneos;

import java.io.Serializable;

import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;

/**
 * ENCUENTRO DE UN TORNEO
 *
 * Es un cruce entre dos participantes dentro del torneo.
 *
 * No lo hicimos subclase de Partido a proposito. Pues Partido sirve para los
 * partidos del club, que cargan estadisticas de jugadores, tarjetas, reglas del
 * deporte y todo eso. El encuentro de un torneo es mucho mas simple: dos
 * participantes, un marcador y listo, y ademas uno de los dos lados puede ser
 * una pareja o un equipo entero, que no es lo que Partido espera. Entonces si lo
 * forzamos a heredar nos quedarian la mitad de los metodos sin usar y asi.
 */
public class Encuentro implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String codigo;

	private int ronda;

	private Participante participanteA;

	private Participante participanteB;

	private int marcadorA;

	private int marcadorB;

	private boolean jugado;

	public Encuentro( String codigo, int ronda, Participante participanteA, Participante participanteB )
	{
		this.codigo = codigo;
		this.ronda = ronda;
		this.participanteA = participanteA;
		this.participanteB = participanteB;
		this.marcadorA = 0;
		this.marcadorB = 0;
		this.jugado = false;
	}

	/**
	 * GUARDAR EL RESULTADO
	 *
	 * Revisa tres cosas: que no se haya registrado ya, que los marcadores no
	 * sean negativos y que no quede empatado.
	 *
	 * la parte del codigo que puede hacerlo estallar es: lo de registrar dos
	 * veces. Si dejamos sobreescribir un resultado entonces la tabla de
	 * posiciones queda contando la victoria dos veces, porque la tabla se
	 * actualiza en el momento en que se registra. Por eso aqui se revisa el
	 * jugado antes de tocar nada.
	 *
	 * @param marcadorA los tantos del primer participante
	 * @param marcadorB los tantos del segundo participante
	 * @throws OperacionNoPermitidaException si ya tenia resultado, si un marcador es negativo o si quedan empatados
	 */
	public void registrarResultado( int marcadorA, int marcadorB ) throws OperacionNoPermitidaException
	{
		if( jugado )
		{
			throw new OperacionNoPermitidaException( "El encuentro " + codigo + " ya tiene resultado registrado y no se puede cambiar" );
		}
		if( marcadorA < 0 || marcadorB < 0 )
		{
			throw new OperacionNoPermitidaException( "Los marcadores no pueden ser negativos, y llegaron " + marcadorA + " y " + marcadorB );
		}
		if( marcadorA == marcadorB )
		{
			throw new OperacionNoPermitidaException( "El encuentro " + codigo + " es de eliminacion y no puede quedar empatado" );
		}
		this.marcadorA = marcadorA;
		this.marcadorB = marcadorB;
		this.jugado = true;
	}

	/**
	 * QUIEN GANO
	 *
	 * Si todavia no se ha jugado devuelve null, entonces hay que revisarlo antes
	 * de usarlo.
	 *
	 * @return el participante que gano, o null si el encuentro no se ha jugado
	 */
	public Participante getGanador( )
	{
		if( !jugado )
		{
			return null;
		}
		if( marcadorA > marcadorB )
		{
			return participanteA;
		}
		return participanteB;
	}

	/**
	 * QUIEN PERDIO
	 *
	 * @return el participante que perdio, o null si el encuentro no se ha jugado
	 */
	public Participante getPerdedor( )
	{
		if( !jugado )
		{
			return null;
		}
		if( marcadorA > marcadorB )
		{
			return participanteB;
		}
		return participanteA;
	}

	public String getCodigo( )
	{
		return codigo;
	}

	public void setCodigo( String codigo )
	{
		this.codigo = codigo;
	}

	public int getRonda( )
	{
		return ronda;
	}

	public void setRonda( int ronda )
	{
		this.ronda = ronda;
	}

	public Participante getParticipanteA( )
	{
		return participanteA;
	}

	public void setParticipanteA( Participante participanteA )
	{
		this.participanteA = participanteA;
	}

	public Participante getParticipanteB( )
	{
		return participanteB;
	}

	public void setParticipanteB( Participante participanteB )
	{
		this.participanteB = participanteB;
	}

	public int getMarcadorA( )
	{
		return marcadorA;
	}

	public int getMarcadorB( )
	{
		return marcadorB;
	}

	public boolean isJugado( )
	{
		return jugado;
	}

	@Override
	public String toString( )
	{
		String texto = codigo + " | ronda " + ronda + " | " + participanteA.getNombre( ) + " vs " + participanteB.getNombre( );
		if( jugado )
		{
			return texto + " | " + marcadorA + "-" + marcadorB + " | gano " + getGanador( ).getNombre( );
		}
		return texto + " | pendiente";
	}
}
