package uniandes.dpoo.cds.modelo.torneos;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.EquipoIncompletoException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * PARTICIPANTE EQUIPO
 *
 * Es cuando un equipo completo ocupa un cupo, o sea los torneos de conjunto.
 *
 * Aunque el equipo lleve quince jugadores adentro, para el torneo es un cupo
 * solo. Y los bonos del torneo recreativo si se reparten uno por jugador, pues
 * los integrantes son todos los que estan habilitados.
 */
public class ParticipanteEquipo extends Participante
{
	private static final long serialVersionUID = 1L;

	private Equipo equipo;

	public ParticipanteEquipo( Equipo equipo )
	{
		this.equipo = equipo;
	}

	@Override
	public String getNombre( )
	{
		return equipo.getNombre( );
	}

	/**
	 * QUIENES FORMAN EL EQUIPO
	 *
	 * Devuelve los jugadores habilitados y no todos los inscritos, pues un
	 * suspendido no esta jugando el torneo y entonces tampoco deberia recibir el
	 * bono si el equipo gana.
	 *
	 * @return los jugadores habilitados del equipo
	 */
	@Override
	public List<Persona> getIntegrantes( )
	{
		List<Persona> integrantes = new ArrayList<Persona>( );
		for( AfiliadoConjunto jugador : equipo.getJugadoresHabilitados( ) )
		{
			integrantes.add( jugador );
		}
		return integrantes;
	}

	/**
	 * EN QUE NIVEL JUEGA
	 *
	 * Un equipo no tiene nivel, pues los torneos de conjunto van por categoria
	 * de edad y no por nivel de juego. Entonces devuelve null y el torneo de
	 * conjunto ni se lo pregunta.
	 *
	 * @param nombreDisciplina la disciplina del torneo
	 * @return siempre null
	 */
	@Override
	public Nivel getNivelEn( String nombreDisciplina )
	{
		return null;
	}

	@Override
	public Categoria getCategoria( )
	{
		return equipo.getCategoria( );
	}

	/**
	 * CUANTO PUNTAJE TIENE EL EQUIPO
	 *
	 * DECISION DE DISENO D5
	 * El club no tenia ranking de equipos, solo de jugadores individuales.
	 * Entonces el criterio que armamos son los partidos internos que el equipo
	 * lleva ganados, que es un numero que ya se esta produciendo cada vez que se
	 * registra un partido y no hay que inventarse nada nuevo.
	 *
	 * @param nombreDisciplina la disciplina del torneo
	 * @return los partidos internos ganados por el equipo
	 */
	@Override
	public double getPuntajeEn( String nombreDisciplina )
	{
		return equipo.getPartidosGanados( );
	}

	@Override
	public Modalidad getModalidad( )
	{
		return Modalidad.CONJUNTO;
	}

	/**
	 * REVISAR SI EL EQUIPO PUEDE COMPETIR
	 *
	 * DECISION DE DISENO D13
	 * Un equipo solo entra al torneo si tiene el minimo de jugadores que exige su
	 * deporte. Eso ya lo sabia responder el equipo desde la Entrega 2 con
	 * puedeDisputarPartido, entonces aqui lo reutilizamos tal cual en vez de
	 * volver a contar jugadores.
	 *
	 * @throws ClubException si el equipo no reune el minimo de jugadores habilitados
	 */
	@Override
	public void validarPuedeCompetir( ) throws ClubException
	{
		if( !equipo.puedeDisputarPartido( ) )
		{
			throw new EquipoIncompletoException( "El equipo " + equipo.getNombre( ) + " no reune los " + equipo.getReglas( ).getMinimoJugadores( ) + " jugadores habilitados que exige " + equipo.getReglas( ).getNombre( ) );
		}
	}

	public Equipo getEquipo( )
	{
		return equipo;
	}
}
