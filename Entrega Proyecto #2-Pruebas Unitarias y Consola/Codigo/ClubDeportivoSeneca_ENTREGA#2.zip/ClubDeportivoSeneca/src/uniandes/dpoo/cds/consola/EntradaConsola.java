package uniandes.dpoo.cds.consola;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * ENTRADA DE LA CONSOLA
 *
 * Es la clase que le pregunta cosas al usuario y se encarga de que lo que
 * escriba sirva.
 *
 * Existe porque los tres programas de consola necesitan exactamente lo mismo:
 * pedir un texto, pedir un numero, pedir una fecha y volver a preguntar cuando
 * el usuario escribe cualquier cosa. Si cada programa lo resolviera por su
 * cuenta entonces tendriamos el mismo codigo escrito tres veces, y el dia que
 * haya que arreglarle algo se nos olvida arreglarlo en dos.
 *
 * Todos los metodos vuelven a preguntar en vez de reventar, pues un programa de
 * consola que se cae porque alguien escribio "abc" donde iba un numero es un
 * programa molesto.
 */
public class EntradaConsola
{
	private Scanner lector;

	public EntradaConsola( )
	{
		this.lector = new Scanner( System.in );
	}

	/**
	 * PEDIR UN TEXTO
	 *
	 * @param mensaje lo que se le muestra al usuario
	 * @return lo que escribio, sin espacios de sobra a los lados
	 */
	public String leerTexto( String mensaje )
	{
		System.out.print( mensaje + ": " );
		return lector.nextLine( ).trim( );
	}

	/**
	 * PEDIR UN NUMERO ENTERO
	 *
	 * Si el usuario escribe algo que no es numero entonces se lo dice y vuelve a
	 * preguntar.
	 *
	 * @param mensaje lo que se le muestra al usuario
	 * @return el numero que escribio
	 */
	public int leerEntero( String mensaje )
	{
		while( true )
		{
			String texto = leerTexto( mensaje );
			try
			{
				return Integer.parseInt( texto );
			}
			catch( NumberFormatException excepcion )
			{
				System.out.println( "   '" + texto + "' no es un numero entero, intente de nuevo" );
			}
		}
	}

	/**
	 * PEDIR UN NUMERO CON DECIMALES
	 *
	 * @param mensaje lo que se le muestra al usuario
	 * @return el numero que escribio
	 */
	public double leerDecimal( String mensaje )
	{
		while( true )
		{
			String texto = leerTexto( mensaje );
			try
			{
				return Double.parseDouble( texto );
			}
			catch( NumberFormatException excepcion )
			{
				System.out.println( "   '" + texto + "' no es un numero, intente de nuevo" );
			}
		}
	}

	/**
	 * PEDIR UN PORCENTAJE
	 *
	 * El usuario lo escribe como numero normal, o sea 80 para el 80%, y aqui se
	 * convierte a la fraccion que el modelo usa por dentro, que seria 0.8. Pues
	 * nadie escribe "cero punto ocho" cuando quiere decir ochenta por ciento.
	 *
	 * @param mensaje lo que se le muestra al usuario
	 * @return el porcentaje como fraccion entre 0 y 1
	 */
	public double leerPorcentaje( String mensaje )
	{
		return leerDecimal( mensaje + " (en numero, por ejemplo 80 para el 80%)" ) / 100.0;
	}

	/**
	 * PEDIR UNA FECHA
	 *
	 * nota: aqui se usa LocalDate.parse de java.time, que coge el texto
	 * "2026-12-05" y lo vuelve una fecha de verdad. Si el texto no tiene esa
	 * forma entonces lanza una DateTimeParseException, que es la que se atrapa
	 * aqui para volver a preguntar.
	 *
	 * @param mensaje lo que se le muestra al usuario
	 * @return la fecha que escribio
	 */
	public LocalDate leerFecha( String mensaje )
	{
		while( true )
		{
			String texto = leerTexto( mensaje + " (aaaa-mm-dd)" );
			try
			{
				return LocalDate.parse( texto );
			}
			catch( DateTimeParseException excepcion )
			{
				System.out.println( "   '" + texto + "' no es una fecha valida, se escribe asi: 2026-12-05" );
			}
		}
	}

	/**
	 * PEDIR UNA HORA
	 *
	 * @param mensaje lo que se le muestra al usuario
	 * @return la hora que escribio
	 */
	public LocalTime leerHora( String mensaje )
	{
		while( true )
		{
			String texto = leerTexto( mensaje + " (hh:mm)" );
			try
			{
				return LocalTime.parse( texto );
			}
			catch( DateTimeParseException excepcion )
			{
				System.out.println( "   '" + texto + "' no es una hora valida, se escribe asi: 14:30" );
			}
		}
	}

	/**
	 * PEDIR UNA OPCION DEL MENU
	 *
	 * Vuelve a preguntar hasta que el numero este entre el minimo y el maximo,
	 * entonces el que llama puede hacer su switch tranquilo sabiendo que lo que
	 * le llego es una opcion que si existe.
	 *
	 * @param minimo la opcion mas chiquita que vale
	 * @param maximo la opcion mas grande que vale
	 * @return la opcion escogida
	 */
	public int leerOpcion( int minimo, int maximo )
	{
		while( true )
		{
			int opcion = leerEntero( "Opcion" );
			if( opcion >= minimo && opcion <= maximo )
			{
				return opcion;
			}
			System.out.println( "   Escoja un numero entre " + minimo + " y " + maximo );
		}
	}

	/**
	 * PREGUNTAR SI O NO
	 *
	 * @param mensaje la pregunta
	 * @return true si contesto que si
	 */
	public boolean confirmar( String mensaje )
	{
		String respuesta = leerTexto( mensaje + " (s/n)" );
		return respuesta.equalsIgnoreCase( "s" ) || respuesta.equalsIgnoreCase( "si" );
	}

	public void pausa( )
	{
		System.out.print( "\n   [Enter para continuar] " );
		lector.nextLine( );
	}

	public void cerrar( )
	{
		lector.close( );
	}
}
