package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.academias.Nivel;

/**
 * ESTUDIANTE DE LA UNIVERSIDAD
 *
 * Es alguien de la universidad que no es socio del club pero que si puede
 * meterse a los torneos, que es lo que pide el enunciado del Proyecto 2.
 *
 * CAMBIO DEL PROYECTO 2
 * En la Entrega 2 toda persona del sistema era afiliado, empleado o el
 * administrador, entonces un estudiante que no es socio no cabia en ninguna
 * parte. Por eso lo creamos como subclase de Persona: tiene login y se autentica
 * como todo el mundo, pero no tiene codigo de afiliado, ni puntos de fidelidad,
 * ni estadisticas, ni derecho a reservar canchas.
 *
 * DECISION DE DISENO D5
 * Como no esta inscrito en ninguna academia del club, no tiene puntaje de
 * ranking. Entonces declara en que nivel juega cuando se registra y entra a los
 * torneos por cupo regular, pues los cupos preferenciales son para los mejores
 * del ranking del club.
 */
public class Estudiante extends Persona implements Competidor
{
	private static final long serialVersionUID = 1L;

	private String codigoEstudiante;

	private String programa;

	private Nivel nivelDeclarado;

	public Estudiante( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoEstudiante, String programa, Nivel nivelDeclarado )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password );
		this.codigoEstudiante = codigoEstudiante;
		this.programa = programa;
		this.nivelDeclarado = nivelDeclarado;
	}

	/**
	 * EN QUE NIVEL JUEGA
	 *
	 * Devuelve el mismo nivel para cualquier disciplina, pues el estudiante no
	 * tiene una inscripcion por disciplina como si la tiene el afiliado. Es el
	 * nivel que declaro cuando lo registraron.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return el nivel declarado
	 */
	@Override
	public Nivel getNivelEn( String nombreDisciplina )
	{
		return nivelDeclarado;
	}

	/**
	 * CUANTO PUNTAJE DE RANKING TIENE
	 *
	 * Cero, pues el ranking lo producen los partidos de las academias del club y
	 * el estudiante no esta en ninguna.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return siempre cero
	 */
	@Override
	public double getPuntajeEn( String nombreDisciplina )
	{
		return 0.0;
	}

	@Override
	public boolean esEmpleadoDelClub( )
	{
		return false;
	}

	public String getCodigoEstudiante( )
	{
		return codigoEstudiante;
	}

	public void setCodigoEstudiante( String codigoEstudiante )
	{
		this.codigoEstudiante = codigoEstudiante;
	}

	public String getPrograma( )
	{
		return programa;
	}

	public void setPrograma( String programa )
	{
		this.programa = programa;
	}

	public Nivel getNivelDeclarado( )
	{
		return nivelDeclarado;
	}

	public void setNivelDeclarado( Nivel nivelDeclarado )
	{
		this.nivelDeclarado = nivelDeclarado;
	}

	@Override
	public String getRol( )
	{
		return "Estudiante";
	}
}
