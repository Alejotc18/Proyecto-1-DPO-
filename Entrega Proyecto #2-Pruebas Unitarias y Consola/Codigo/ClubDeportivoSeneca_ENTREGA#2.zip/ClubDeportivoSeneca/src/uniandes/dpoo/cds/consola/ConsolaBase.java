package uniandes.dpoo.cds.consola;

import java.io.File;

import uniandes.dpoo.cds.logica.Club;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.persistencia.PersistenciaException;
import uniandes.dpoo.cds.persistencia.RepositorioArchivosPlanos;
import uniandes.dpoo.cds.persistencia.RepositorioClub;
import uniandes.dpoo.cds.persistencia.RepositorioSerializado;

/**
 * BASE DE LOS PROGRAMAS DE CONSOLA, PATRON TEMPLATE METHOD
 *
 * Los tres programas del proyecto hacen exactamente lo mismo por fuera: cargan
 * el club, piden usuario y contrasena, revisan que el que entro si sea del rol
 * que ese programa atiende, dan vueltas mostrando el menu hasta que el usuario
 * se quiera salir, y de ultimas guardan.
 *
 * Lo unico que cambia entre los tres es que dice el menu y que hace cada opcion.
 * Entonces el metodo arrancar esta aqui, es final, y deja tres huecos que cada
 * programa llena: el titulo, el rol que se admite, el menu y la atencion de la
 * opcion.
 *
 * Es el mismo patron de Venta y de Torneo, nada mas que aplicado a la interfaz.
 *
 * la parte del codigo que puede hacerlo estallar es: el guardado del final. Esta
 * dentro de un finally a proposito, entonces aunque una opcion se caiga por la
 * mitad el trabajo que ya se habia hecho no se pierde.
 */
public abstract class ConsolaBase
{
	protected Club club;

	protected Persona usuario;

	protected EntradaConsola entrada;

	protected RepositorioClub repositorio;

	public static final String CARPETA_DATOS = "data";

	public static final String ARCHIVO_ESTADO = "data/club.ser";

	/**
	 * ARMAR EL PROGRAMA Y ESCOGER DE DONDE SALEN LOS DATOS
	 *
	 * AQUI SE VE PARA QUE SIRVE EL PATRON DAO
	 * El club tiene dos repositorios: uno de archivos de texto y uno de
	 * serializacion. Los dos cumplen la misma interfaz, entonces el programa
	 * puede escoger cual usar sin cambiarle una linea al modelo.
	 *
	 * Y los usamos los dos a proposito. La primera vez que alguien corre
	 * cualquiera de los tres programas todavia no existe el archivo serializado,
	 * entonces se arranca de los archivos de texto, que son los que nosotros
	 * podemos abrir y editar a mano para armar los datos de prueba. De ahi en
	 * adelante se guarda y se carga con serializacion.
	 *
	 * la parte del codigo que puede hacerlo estallar es: si guardaramos siempre
	 * en texto, las inscripciones a torneos, los encuentros y los bonos se
	 * perderian al cerrar el programa, porque esos no estan en los archivos de
	 * texto. Entonces uno se inscribe desde la consola del jugador y cuando el
	 * administrador abre la suya el torneo aparece vacio. Con la serializacion se
	 * guarda el club entero y los tres programas si se ven el trabajo entre
	 * ellos.
	 */
	public ConsolaBase( )
	{
		this.entrada = new EntradaConsola( );
		if( new File( ARCHIVO_ESTADO ).exists( ) )
		{
			this.repositorio = new RepositorioSerializado( ARCHIVO_ESTADO );
		}
		else
		{
			this.repositorio = new RepositorioArchivosPlanos( CARPETA_DATOS );
		}
	}

	// HUECOS QUE LLENA CADA PROGRAMA

	/**
	 * COMO SE LLAMA EL PROGRAMA
	 *
	 * @return el titulo que se muestra al arrancar
	 */
	protected abstract String getTitulo( );

	/**
	 * QUE ROL PUEDE ENTRAR AQUI
	 *
	 * @param persona la persona que acaba de autenticarse
	 * @return true si esa persona puede usar este programa
	 */
	protected abstract boolean admiteUsuario( Persona persona );

	/**
	 * QUE DICE EL MENU
	 *
	 * @return las opciones del menu, sin contar la de salir
	 */
	protected abstract String[] getOpciones( );

	/**
	 * ATENDER UNA OPCION
	 *
	 * @param opcion el numero que escogio el usuario
	 * @throws Exception si la operacion no se pudo hacer
	 */
	protected abstract void atender( int opcion ) throws Exception;

	/**
	 * ARRANCAR EL PROGRAMA, ESTE ES EL METODO PLANTILLA
	 *
	 * Lleva el procedimiento completo y en orden, y esta marcado como final para
	 * que ningun programa se salte la carga, la autenticacion o el guardado.
	 */
	public final void arrancar( )
	{
		System.out.println( "\n===============================================" );
		System.out.println( "  " + getTitulo( ) );
		System.out.println( "===============================================\n" );

		if( !cargarClub( ) )
		{
			return;
		}
		if( !autenticar( ) )
		{
			return;
		}

		try
		{
			darVueltasEnElMenu( );
		}
		finally
		{
			guardarClub( );
			entrada.cerrar( );
		}
	}

	/**
	 * CARGAR EL CLUB DESDE LOS ARCHIVOS
	 *
	 * @return true si el club se pudo cargar
	 */
	private boolean cargarClub( )
	{
		try
		{
			club = repositorio.cargar( );
			System.out.println( "Club cargado: " + club.getNombre( ) + " (" + club.getPersonas( ).size( ) + " personas, " + club.getTorneos( ).size( ) + " torneos)\n" );
			return true;
		}
		catch( PersistenciaException excepcion )
		{
			System.out.println( "No fue posible cargar los datos del club: " + excepcion.getMessage( ) );
			System.out.println( "Revise que la carpeta '" + CARPETA_DATOS + "' exista y tenga los archivos." );
			return false;
		}
	}

	/**
	 * GUARDAR EL CLUB EN LOS DOS FORMATOS
	 *
	 * El serializado se guarda de primeras porque es el que lleva todo y es el
	 * que los programas se vuelven a leer entre ellos. El de texto se guarda
	 * despues y solo lleva lo que se puede escribir en una linea, pero nos sirve
	 * para abrir los datos y revisarlos a mano.
	 *
	 * Si el de texto falla no pasa nada grave, pues el estado completo ya quedo
	 * guardado, entonces se avisa y se sigue.
	 */
	private void guardarClub( )
	{
		try
		{
			new RepositorioSerializado( ARCHIVO_ESTADO ).guardar( club );
			System.out.println( "\nDatos guardados. Hasta luego." );
		}
		catch( PersistenciaException excepcion )
		{
			System.out.println( "\nNo fue posible guardar el estado del club: " + excepcion.getMessage( ) );
			return;
		}

		try
		{
			new RepositorioArchivosPlanos( CARPETA_DATOS ).guardar( club );
		}
		catch( PersistenciaException excepcion )
		{
			System.out.println( "Aviso: el estado si quedo guardado, pero los archivos de texto no se pudieron actualizar" );
		}
	}

	/**
	 * PEDIR USUARIO Y CONTRASENA
	 *
	 * Da tres intentos y despues cierra, pues dejar intentar infinitas veces no
	 * tiene sentido.
	 *
	 * @return true si alguien del rol correcto logro entrar
	 */
	private boolean autenticar( )
	{
		for( int intento = 1; intento <= 3; intento++ )
		{
			String login = entrada.leerTexto( "Usuario" );
			String password = entrada.leerTexto( "Contrasena" );
			Persona persona = club.autenticar( login, password );

			if( persona == null )
			{
				System.out.println( "   Usuario o contrasena incorrectos (intento " + intento + " de 3)\n" );
			}
			else if( !admiteUsuario( persona ) )
			{
				System.out.println( "   " + persona.getNombreCompleto( ) + " es " + persona.getRol( ) + " y este programa no es para ese rol\n" );
			}
			else
			{
				usuario = persona;
				System.out.println( "\nBienvenido/a, " + persona.getNombreCompleto( ) + " (" + persona.getRol( ) + ")" );
				return true;
			}
		}
		System.out.println( "Se acabaron los intentos." );
		return false;
	}

	/**
	 * MOSTRAR EL MENU HASTA QUE EL USUARIO SE QUIERA IR
	 *
	 * Cada opcion se atiende dentro de un try, entonces si una regla del club no
	 * se cumple el programa muestra el mensaje y sigue, en vez de caerse y
	 * perderle el trabajo al usuario.
	 */
	private void darVueltasEnElMenu( )
	{
		String[] opciones = getOpciones( );
		boolean seguir = true;

		while( seguir )
		{
			System.out.println( "\n-----------------------------------------------" );
			for( int i = 0; i < opciones.length; i++ )
			{
				System.out.println( "  " + ( i + 1 ) + ". " + opciones[ i ] );
			}
			System.out.println( "  0. Salir" );
			System.out.println( "-----------------------------------------------" );

			int opcion = entrada.leerOpcion( 0, opciones.length );
			if( opcion == 0 )
			{
				seguir = false;
			}
			else
			{
				try
				{
					System.out.println( );
					atender( opcion );
				}
				catch( Exception excepcion )
				{
					System.out.println( "\n   NO SE PUDO: " + excepcion.getMessage( ) );
				}
				entrada.pausa( );
			}
		}
	}
}
