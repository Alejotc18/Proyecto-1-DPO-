package uniandes.dpoo.cds.modelo.torneos;

import java.io.Serializable;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.personas.Competidor;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * PARTICIPANTE DE UN TORNEO
 *
 * Es lo que ocupa un cupo del torneo.
 *
 * DECISION DE DISENO D3
 * Un cupo es un participante y ya, sin importar cuanta gente lleve adentro. O
 * sea un jugador solo ocupa un cupo, una pareja de dobles ocupa un cupo entre
 * los dos, y un equipo de futbol con quince jugadores tambien ocupa un cupo
 * nomas.
 *
 * Esta clase es abstracta justamente por eso: el torneo no quiere saber si esta
 * hablando con una persona, con una pareja o con un equipo, solo quiere contar
 * cupos, pedir nombres y comparar niveles. Entonces aqui dejamos lo que las tres
 * formas tienen en comun y cada subclase resuelve lo suyo.
 *
 * Si no lo hubieramos hecho asi entonces el torneo tendria que guardar tres
 * listas separadas y repetir la cuenta de cupos tres veces, y la regla de que la
 * pareja sale completa del torneo nos tocaria escribirla a mano con ifs.
 */
public abstract class Participante implements Serializable
{
	private static final long serialVersionUID = 1L;

	/**
	 * COMO SE LLAMA ESTE PARTICIPANTE
	 *
	 * Es para los listados y el historial del torneo, pues un jugador se muestra
	 * con su nombre, una pareja con los dos nombres y un equipo con el nombre del
	 * equipo.
	 *
	 * @return el nombre con el que se muestra el participante
	 */
	public abstract String getNombre( );

	/**
	 * QUIENES LO FORMAN
	 *
	 * El torneo recreativo usa esto para repartir los bonos, pues cada integrante
	 * del ganador recibe el suyo. Entonces si gana una pareja salen dos bonos y
	 * si gana un equipo sale uno por jugador.
	 *
	 * @return las personas que componen el participante
	 */
	public abstract List<Persona> getIntegrantes( );

	/**
	 * EN QUE NIVEL COMPITE
	 *
	 * Los torneos individuales y de dobles van por nivel, entonces el
	 * participante tiene que poder decir el suyo para que el torneo compare. Un
	 * equipo no tiene nivel y devuelve null, pues los de conjunto van por
	 * categoria de edad.
	 *
	 * @param nombreDisciplina la disciplina del torneo
	 * @return el nivel del participante, o null si no aplica
	 */
	public abstract Nivel getNivelEn( String nombreDisciplina );

	/**
	 * EN QUE CATEGORIA COMPITE
	 *
	 * Al contrario del nivel, esto solo lo contestan los equipos y los demas
	 * devuelven null.
	 *
	 * @return la categoria del participante, o null si no aplica
	 */
	public abstract Categoria getCategoria( );

	/**
	 * CUANTO PUNTAJE TIENE PARA LA FILA DE LOS PREFERENCIALES
	 *
	 * Esta es la decision D5 y cada subclase la resuelve distinto: el jugador
	 * solo usa su ranking de la academia, la pareja usa el del mejor de los dos,
	 * y el equipo usa los partidos internos que lleva ganados.
	 *
	 * @param nombreDisciplina la disciplina del torneo
	 * @return el puntaje con el que se ordena para los cupos preferenciales
	 */
	public abstract double getPuntajeEn( String nombreDisciplina );

	/**
	 * EN QUE MODALIDAD PUEDE JUGAR
	 *
	 * Sirve para no dejar que un equipo se meta a un torneo individual ni que un
	 * jugador solo se meta a uno de conjunto.
	 *
	 * @return la modalidad a la que corresponde este participante
	 */
	public abstract Modalidad getModalidad( );

	/**
	 * REVISAR SI ESTA EN CONDICIONES DE COMPETIR
	 *
	 * Cada subclase mira lo suyo: el equipo revisa que tenga el minimo de
	 * jugadores que exige su deporte, que es la decision D13, y los individuales
	 * revisan que la gente este activa.
	 *
	 * @throws ClubException si el participante no esta en condiciones de competir
	 */
	public abstract void validarPuedeCompetir( ) throws ClubException;

	/**
	 * REVISAR SI UNA PERSONA ESTA ADENTRO
	 *
	 * Con esto el torneo averigua si alguien ya esta inscrito, sin importar si
	 * entro solo, en pareja o con su equipo. Y es justo lo que hace que la pareja
	 * salga completa cuando uno de los dos se desinscribe, pues la busqueda
	 * encuentra el cupo entero y no medio cupo.
	 *
	 * @param persona la persona que se esta buscando
	 * @return true si la persona hace parte de este participante
	 */
	public boolean incluye( Persona persona )
	{
		for( Persona integrante : getIntegrantes( ) )
		{
			if( integrante.getDocumento( ).equals( persona.getDocumento( ) ) )
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * REVISAR SI HAY UN EMPLEADO ADENTRO
	 *
	 * La decision D8 dice que el premio en efectivo no se le entrega a un
	 * empleado. Como el dinero no se puede partir, con que uno solo de los
	 * integrantes trabaje en el club entonces ese participante no recibe efectivo
	 * y el premio pasa al siguiente de la tabla.
	 *
	 * @return true si al menos un integrante es empleado del club
	 */
	public boolean tieneEmpleados( )
	{
		for( Persona integrante : getIntegrantes( ) )
		{
			if( integrante instanceof Competidor && ( ( Competidor ) integrante ).esEmpleadoDelClub( ) )
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public String toString( )
	{
		return getNombre( ) + " (" + getModalidad( ).getNombre( ) + ")";
	}
}
