package uniandes.dpoo.cds.modelo.torneos;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.personas.Competidor;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * PARTICIPANTE PAREJA
 *
 * Es cuando dos personas ocupan un solo cupo, o sea los torneos de dobles.
 *
 * Esta es la clase que hace que la regla de la pareja funcione sola. Como el
 * cupo es de la pareja y no de cada uno, entonces cuando uno de los dos se
 * desinscribe se va el cupo completo y el compañero tambien sale, sin que haya
 * que escribir nada especial: el torneo busca el participante que incluye a esa
 * persona y lo saca entero.
 */
public class ParticipantePareja extends Participante
{
	private static final long serialVersionUID = 1L;

	private Persona primero;

	private Persona segundo;

	/**
	 * CREAR LA PAREJA
	 *
	 * Revisa tres cosas: que los dos sepan competir, que no sean la misma
	 * persona metida dos veces, y nada mas. Lo del nivel lo mira el torneo.
	 *
	 * @param primero el primer integrante
	 * @param segundo el segundo integrante
	 * @throws OperacionNoPermitidaException si alguno no compite en torneos o si los dos son la misma persona
	 */
	public ParticipantePareja( Persona primero, Persona segundo ) throws OperacionNoPermitidaException
	{
		if( !( primero instanceof Competidor ) || !( segundo instanceof Competidor ) )
		{
			throw new OperacionNoPermitidaException( "Los dos integrantes de la pareja tienen que ser roles que compitan en torneos" );
		}
		if( primero.getDocumento( ).equals( segundo.getDocumento( ) ) )
		{
			throw new OperacionNoPermitidaException( "Una pareja de dobles no puede ser la misma persona dos veces" );
		}
		this.primero = primero;
		this.segundo = segundo;
	}

	@Override
	public String getNombre( )
	{
		return primero.getNombreCompleto( ) + " y " + segundo.getNombreCompleto( );
	}

	@Override
	public List<Persona> getIntegrantes( )
	{
		List<Persona> integrantes = new ArrayList<Persona>( );
		integrantes.add( primero );
		integrantes.add( segundo );
		return integrantes;
	}

	/**
	 * EN QUE NIVEL JUEGA LA PAREJA
	 *
	 * Para que la pareja tenga nivel los dos tienen que estar en el mismo, pues
	 * si uno es Intermedio y el otro Avanzado entonces no hay un nivel de la
	 * pareja y devolvemos null. El torneo ve ese null y rechaza la inscripcion
	 * por nivel, que es lo que queremos.
	 *
	 * @param nombreDisciplina la disciplina del torneo
	 * @return el nivel comun de los dos, o null si no coinciden
	 */
	@Override
	public Nivel getNivelEn( String nombreDisciplina )
	{
		Nivel nivelPrimero = ( ( Competidor ) primero ).getNivelEn( nombreDisciplina );
		Nivel nivelSegundo = ( ( Competidor ) segundo ).getNivelEn( nombreDisciplina );
		if( nivelPrimero == null || nivelSegundo == null )
		{
			return null;
		}
		if( nivelPrimero != nivelSegundo )
		{
			return null;
		}
		return nivelPrimero;
	}

	@Override
	public Categoria getCategoria( )
	{
		return null;
	}

	/**
	 * CUANTO PUNTAJE TIENE LA PAREJA
	 *
	 * DECISION DE DISENO D5
	 * Cuenta el mejor de los dos. Entonces si uno va de segundo en el ranking y
	 * el otro de noveno, la pareja entra con el puesto del segundo y le alcanza
	 * para cupo preferencial.
	 *
	 * @param nombreDisciplina la disciplina del torneo
	 * @return el mayor de los dos puntajes
	 */
	@Override
	public double getPuntajeEn( String nombreDisciplina )
	{
		double puntajePrimero = ( ( Competidor ) primero ).getPuntajeEn( nombreDisciplina );
		double puntajeSegundo = ( ( Competidor ) segundo ).getPuntajeEn( nombreDisciplina );
		return Math.max( puntajePrimero, puntajeSegundo );
	}

	@Override
	public Modalidad getModalidad( )
	{
		return Modalidad.DOBLES;
	}

	@Override
	public void validarPuedeCompetir( ) throws ClubException
	{
	}

	public Persona getPrimero( )
	{
		return primero;
	}

	public Persona getSegundo( )
	{
		return segundo;
	}
}
