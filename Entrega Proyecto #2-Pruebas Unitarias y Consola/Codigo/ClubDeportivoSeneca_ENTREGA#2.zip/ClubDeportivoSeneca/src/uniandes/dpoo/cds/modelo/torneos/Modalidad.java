package uniandes.dpoo.cds.modelo.torneos;

/**
 * MODALIDAD DEL TORNEO
 *
 * Dice en que formato se juega el torneo: por equipos, uno contra uno, o en
 * parejas.
 *
 * nota: esto es un enum, que no lo vimos en clase. Un enum es una lista cerrada
 * de valores, o sea el club tiene exactamente estas tres modalidades y no se
 * pueden inventar mas.
 *
 * Lo usamos pues de la modalidad depende quien puede inscribirse y cuanta gente
 * ocupa un cupo. En conjunto se inscribe un equipo completo, en individual se
 * inscribe una persona sola y en dobles se inscribe una pareja, pero en los tres
 * casos eso cuenta como UN cupo nomas, que es la decision D3. Si fuera texto
 * entonces alguien escribe "Dobles" con mayuscula y otro "dobles" y ya se dano
 * la comparacion.
 */
public enum Modalidad
{
	CONJUNTO( "Conjunto", 1 ),
	INDIVIDUAL( "Individual", 1 ),
	DOBLES( "Dobles", 2 );

	private String nombre;

	private int personasPorCupo;

	private Modalidad( String nombre, int personasPorCupo )
	{
		this.nombre = nombre;
		this.personasPorCupo = personasPorCupo;
	}

	/**
	 * REVISAR SI LA MODALIDAD ES DE UNA PERSONA SOLA
	 *
	 * Sirve pues un empleado solo puede meterse a torneos individuales, entonces
	 * hay que poder preguntarlo sin andar comparando con cada valor.
	 *
	 * @return true si en esta modalidad compite una sola persona
	 */
	public boolean esIndividual( )
	{
		return this == INDIVIDUAL;
	}

	/**
	 * REVISAR SI LA MODALIDAD ES POR EQUIPOS
	 *
	 * @return true si en esta modalidad lo que se inscribe es un equipo
	 */
	public boolean esDeEquipos( )
	{
		return this == CONJUNTO;
	}

	/**
	 * BUSCAR UNA MODALIDAD POR SU NOMBRE
	 *
	 * Sirve para cuando leemos el archivo de torneos, pues ahi la modalidad
	 * viene escrita como texto y toca pasarla al valor del enum.
	 *
	 * @param nombre el nombre de la modalidad
	 * @return la modalidad correspondiente, o null si no existe
	 */
	public static Modalidad porNombre( String nombre )
	{
		for( Modalidad modalidad : values( ) )
		{
			if( modalidad.nombre.equalsIgnoreCase( nombre ) )
			{
				return modalidad;
			}
		}
		return null;
	}

	public String getNombre( )
	{
		return nombre;
	}

	/**
	 * CUANTA GENTE OCUPA UN CUPO
	 *
	 * En dobles son dos personas por cupo y en los otros dos casos es una, o sea
	 * el equipo tambien cuenta como uno aunque lleve quince jugadores.
	 *
	 * @return el numero de personas que caben en un cupo de esta modalidad
	 */
	public int getPersonasPorCupo( )
	{
		return personasPorCupo;
	}

	@Override
	public String toString( )
	{
		return nombre;
	}
}
