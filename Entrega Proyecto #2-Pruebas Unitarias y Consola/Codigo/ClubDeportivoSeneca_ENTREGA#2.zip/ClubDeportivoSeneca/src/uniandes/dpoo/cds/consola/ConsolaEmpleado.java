package uniandes.dpoo.cds.consola;

import java.time.LocalDate;
import java.time.LocalTime;

import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.entrenamiento.Convocatoria;
import uniandes.dpoo.cds.modelo.entrenamiento.SesionEntrenamiento;
import uniandes.dpoo.cds.modelo.entrenamiento.SolicitudCambioTurno;
import uniandes.dpoo.cds.modelo.entrenamiento.Turno;
import uniandes.dpoo.cds.modelo.personas.Afiliado;
import uniandes.dpoo.cds.modelo.personas.Empleado;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.modelo.tienda.Bono;
import uniandes.dpoo.cds.modelo.torneos.EstadoTorneo;
import uniandes.dpoo.cds.modelo.torneos.InscripcionTorneo;
import uniandes.dpoo.cds.modelo.torneos.Torneo;

/**
 * PROGRAMA DE CONSOLA DEL EMPLEADO
 *
 * Es el programa de los entrenadores y los fisioterapeutas.
 *
 * Tiene dos partes. La del trabajo, que es ver los turnos de un dia, pedir un
 * cambio de turno y, si es entrenador, registrar la asistencia de una sesion. Y
 * la de jugar, pues el enunciado deja que los empleados se metan a los torneos
 * individuales con dos reglas propias: no pagan inscripcion y no se pueden
 * inscribir si ese dia les toca turno.
 */
public class ConsolaEmpleado extends ConsolaBase
{
	@Override
	protected String getTitulo( )
	{
		return "CLUB DEPORTIVO SENECA - CONSOLA DEL EMPLEADO";
	}

	@Override
	protected boolean admiteUsuario( Persona persona )
	{
		return persona instanceof Empleado;
	}

	@Override
	protected String[] getOpciones( )
	{
		return new String[] {
				"Ver mis turnos de un dia",
				"Pedir un cambio de turno",
				"Ver el estado de mis solicitudes",
				"Registrar la asistencia de una sesion (solo entrenadores)",
				"Ver los torneos abiertos",
				"Inscribirme en un torneo individual",
				"Salirme de un torneo",
				"Ver mis bonos",
				"Declarar mi nivel de juego" };
	}

	@Override
	protected void atender( int opcion ) throws Exception
	{
		if( opcion == 1 )
		{
			verMisTurnos( );
		}
		else if( opcion == 2 )
		{
			pedirCambioDeTurno( );
		}
		else if( opcion == 3 )
		{
			verMisSolicitudes( );
		}
		else if( opcion == 4 )
		{
			registrarAsistencia( );
		}
		else if( opcion == 5 )
		{
			verTorneosAbiertos( );
		}
		else if( opcion == 6 )
		{
			inscribirmeEnTorneo( );
		}
		else if( opcion == 7 )
		{
			salirmeDeUnTorneo( );
		}
		else if( opcion == 8 )
		{
			verMisBonos( );
		}
		else if( opcion == 9 )
		{
			declararNivel( );
		}
	}

	private Empleado getEmpleado( )
	{
		return ( Empleado ) usuario;
	}

	/**
	 * VER LOS TURNOS DE UN DIA
	 *
	 * El empleado escribe una fecha normal de calendario y el sistema la traduce
	 * al dia de la semana y a la semana con la que el club guarda los turnos. Esa
	 * traduccion es la decision D10 y es la misma que despues no deja que se
	 * inscriba a un torneo el dia que le toca trabajar.
	 */
	private void verMisTurnos( )
	{
		LocalDate fecha = entrada.leerFecha( "Que dia quiere consultar" );

		System.out.println( "\n   " + fecha + " cae " + Turno.diaSemanaDe( fecha ) + " de la semana " + Turno.semanaDe( fecha ) );
		if( getEmpleado( ).getTurnosEn( fecha ).isEmpty( ) )
		{
			System.out.println( "   Ese dia no tiene turno asignado" );
			return;
		}
		for( Turno turno : getEmpleado( ).getTurnosEn( fecha ) )
		{
			System.out.println( "   " + turno );
		}
	}

	private void pedirCambioDeTurno( ) throws Exception
	{
		System.out.println( "Sus turnos:" );
		for( Turno turno : getEmpleado( ).getTurnos( ) )
		{
			if( turno.isVigente( ) )
			{
				System.out.println( "   " + turno );
			}
		}

		String codigo = entrada.leerTexto( "\nCodigo del turno que quiere cambiar" );
		Turno turno = buscarTurno( codigo );
		if( turno == null )
		{
			throw new Exception( "No tiene ningun turno vigente con el codigo " + codigo );
		}

		String motivo = entrada.leerTexto( "Motivo del cambio" );
		System.out.println( "\n   El club atiende de " + club.getHoraApertura( ) + " a " + club.getHoraCierre( ) );
		String nuevoDia = entrada.leerTexto( "A que dia lo quiere mover (Lunes, Martes, ...)" );
		LocalTime inicio = entrada.leerHora( "Hora de inicio del turno nuevo" );
		LocalTime fin = entrada.leerHora( "Hora de fin del turno nuevo" );

		SolicitudCambioTurno solicitud = club.solicitarCambioTurno( "SOL-" + System.currentTimeMillis( ), getEmpleado( ), turno, LocalDate.now( ), motivo, nuevoDia, inicio, fin );

		System.out.println( "\n   Solicitud radicada con el codigo " + solicitud.getCodigo( ) );
		System.out.println( "   Queda pendiente hasta que el administrador la revise" );
	}

	private Turno buscarTurno( String codigo )
	{
		for( Turno turno : getEmpleado( ).getTurnos( ) )
		{
			if( turno.isVigente( ) && turno.getCodigo( ).equalsIgnoreCase( codigo ) )
			{
				return turno;
			}
		}
		return null;
	}

	private void verMisSolicitudes( )
	{
		System.out.println( "Sus solicitudes:" );
		int encontradas = 0;
		for( SolicitudCambioTurno solicitud : club.getSolicitudes( ) )
		{
			if( solicitud.getSolicitante( ).equals( getEmpleado( ) ) )
			{
				System.out.println( "   " + solicitud );
				if( !solicitud.estaPendiente( ) )
				{
					System.out.println( "        " + solicitud.getObservacionDecision( ) );
				}
				encontradas = encontradas + 1;
			}
		}
		if( encontradas == 0 )
		{
			System.out.println( "   (ninguna)" );
		}
	}

	/**
	 * REGISTRAR LA ASISTENCIA DE UNA SESION
	 *
	 * Solo lo pueden hacer los entrenadores, y solo cuando la sesion ya
	 * finalizo. Esa segunda regla es un ajuste del Proyecto 2: en la Entrega 1
	 * la historia decia que la sesion tenia que haber terminado pero el codigo
	 * no lo estaba revisando.
	 *
	 * @throws Exception si quien lo intenta no es entrenador o si la sesion no sirve
	 */
	private void registrarAsistencia( ) throws Exception
	{
		if( !( usuario instanceof Entrenador ) )
		{
			throw new Exception( "Solo los entrenadores registran asistencia" );
		}
		Entrenador entrenador = ( Entrenador ) usuario;

		System.out.println( "Sus sesiones:" );
		for( SesionEntrenamiento sesion : entrenador.getSesiones( ) )
		{
			System.out.println( "   " + sesion );
		}

		String codigo = entrada.leerTexto( "\nCodigo de la sesion" );
		SesionEntrenamiento sesion = buscarSesion( entrenador, codigo );
		if( sesion == null )
		{
			throw new Exception( "No tiene ninguna sesion con el codigo " + codigo );
		}
		if( !sesion.isFinalizada( ) && entrada.confirmar( "La sesion todavia no esta finalizada. Finalizarla ahora" ) )
		{
			sesion.finalizar( );
		}

		System.out.println( "\nConvocados:" );
		for( Convocatoria convocatoria : sesion.getConvocatorias( ) )
		{
			System.out.println( "   " + convocatoria.getJugador( ).getDocumento( ) + " | " + convocatoria );
		}

		String documento = entrada.leerTexto( "\nDocumento del jugador" );
		Persona persona = club.buscarPersona( documento );
		if( !( persona instanceof Afiliado ) )
		{
			throw new Exception( "El documento " + documento + " no es de un afiliado del club" );
		}

		Convocatoria convocatoria = sesion.buscarConvocatoria( ( Afiliado ) persona );
		System.out.println( "\nAsistencia:  1. Asistio   2. Falto   3. Llego tarde" );
		int opcion = entrada.leerOpcion( 1, 3 );
		String estado = Convocatoria.ASISTIO;
		if( opcion == 2 )
		{
			estado = Convocatoria.FALTO;
		}
		else if( opcion == 3 )
		{
			estado = Convocatoria.LLEGO_TARDE;
		}

		convocatoria.registrarAsistencia( estado );

		System.out.println( "\n   Asistencia guardada: " + convocatoria );
	}

	private SesionEntrenamiento buscarSesion( Entrenador entrenador, String codigo )
	{
		for( SesionEntrenamiento sesion : entrenador.getSesiones( ) )
		{
			if( sesion.getCodigo( ).equalsIgnoreCase( codigo ) )
			{
				return sesion;
			}
		}
		return null;
	}

	private void verTorneosAbiertos( )
	{
		System.out.println( "Torneos con inscripciones abiertas:" );
		for( Torneo torneo : club.consultarTorneos( EstadoTorneo.INSCRIPCIONES_ABIERTAS ) )
		{
			String aviso = "";
			if( !torneo.getModalidad( ).esIndividual( ) )
			{
				aviso = "   (de " + torneo.getModalidad( ).getNombre( ) + ", los empleados solo entran a los individuales)";
			}
			else if( getEmpleado( ).tieneTurnoEn( torneo.getFecha( ) ) )
			{
				aviso = "   (ese dia usted tiene turno)";
			}
			System.out.println( "   " + torneo + " | " + torneo.getFecha( ) + aviso );
		}
	}

	/**
	 * INSCRIBIRME EN UN TORNEO INDIVIDUAL
	 *
	 * Las dos reglas del empleado las revisa la fachada: que no tenga turno ese
	 * dia y que el torneo no sea de conjunto. Aqui solo se muestra el resultado.
	 *
	 * @throws Exception si alguna de las reglas no se cumple
	 */
	private void inscribirmeEnTorneo( ) throws Exception
	{
		if( getEmpleado( ).getNivelEn( "" ) == null )
		{
			throw new Exception( "Primero declare su nivel de juego con la ultima opcion del menu" );
		}

		verTorneosAbiertos( );
		String codigo = entrada.leerTexto( "\nCodigo del torneo" );
		Torneo torneo = club.buscarTorneo( codigo );
		if( torneo == null )
		{
			throw new Exception( "No existe ningun torneo con el codigo " + codigo );
		}

		InscripcionTorneo inscripcion = club.inscribirEnTorneo( torneo, getEmpleado( ), LocalDate.now( ) );

		System.out.println( "\n   Inscripcion lista en " + torneo.getNombre( ) );
		System.out.println( "   Valor a pagar: " + String.format( "%.2f", inscripcion.getValorPagado( ) ) + " (los empleados no pagan inscripcion)" );
		if( torneo instanceof uniandes.dpoo.cds.modelo.torneos.TorneoCompetitivo )
		{
			System.out.println( "   Aviso: si gana este torneo competitivo, el premio en efectivo pasa al mejor ubicado que no sea empleado" );
		}
		else
		{
			System.out.println( "   Si gana este torneo recreativo si recibe su bono de descuento" );
		}
	}

	private void salirmeDeUnTorneo( ) throws Exception
	{
		String codigo = entrada.leerTexto( "Codigo del torneo del que se quiere salir" );
		Torneo torneo = club.buscarTorneo( codigo );
		if( torneo == null )
		{
			throw new Exception( "No existe ningun torneo con el codigo " + codigo );
		}

		club.desinscribirDeTorneo( torneo, getEmpleado( ) );

		System.out.println( "\n   Listo, ya no esta inscrito en " + torneo.getNombre( ) );
	}

	private void verMisBonos( )
	{
		System.out.println( "Sus bonos:" );
		if( club.getBonosDe( usuario ).isEmpty( ) )
		{
			System.out.println( "   (todavia no ha ganado ninguno)" );
			return;
		}
		for( Bono bono : club.getBonosDe( usuario ) )
		{
			System.out.println( "   " + bono );
		}
	}

	/**
	 * DECLARAR EL NIVEL DE JUEGO
	 *
	 * El empleado no esta inscrito en ninguna academia del club, entonces no
	 * tiene un nivel que salga del ranking. Lo declara el mismo y con ese nivel
	 * se compara cuando se quiere meter a un torneo.
	 */
	private void declararNivel( )
	{
		System.out.println( "Nivel:  1. Principiante   2. Intermedio   3. Avanzado" );
		int opcion = entrada.leerOpcion( 1, 3 );
		Nivel nivel = Nivel.PRINCIPIANTE;
		if( opcion == 2 )
		{
			nivel = Nivel.INTERMEDIO;
		}
		else if( opcion == 3 )
		{
			nivel = Nivel.AVANZADO;
		}

		getEmpleado( ).setNivelDeclarado( nivel );

		System.out.println( "\n   Listo, usted compite en nivel " + nivel.getNombre( ) );
		System.out.println( "   Recuerde que el cupo preferencial es para los mejores del ranking de las academias, entonces usted entra por cupo regular" );
	}

	/**
	 * ARRANCAR EL PROGRAMA DEL EMPLEADO
	 *
	 * @param args no se usan
	 */
	public static void main( String[] args )
	{
		new ConsolaEmpleado( ).arrancar( );
	}
}
