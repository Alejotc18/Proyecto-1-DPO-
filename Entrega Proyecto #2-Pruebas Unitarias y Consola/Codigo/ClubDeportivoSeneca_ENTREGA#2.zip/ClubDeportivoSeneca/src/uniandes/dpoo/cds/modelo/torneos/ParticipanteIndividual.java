package uniandes.dpoo.cds.modelo.torneos;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.personas.Competidor;
import uniandes.dpoo.cds.modelo.personas.Persona;

/**
 * PARTICIPANTE INDIVIDUAL
 *
 * Es cuando una sola persona ocupa el cupo, o sea los torneos de uno contra uno.
 *
 * Adentro guarda la persona como Persona y no como una clase mas puntual, pues
 * aqui puede entrar un afiliado del club, un estudiante de la universidad, un
 * externo o un empleado, y los cuatro son Persona. Lo que si exige es que sepa
 * competir, o sea que implemente la interfaz Competidor, porque si no el torneo
 * no le podria preguntar su nivel ni su puntaje.
 */
public class ParticipanteIndividual extends Participante
{
	private static final long serialVersionUID = 1L;

	private Persona jugador;

	/**
	 * CREAR EL PARTICIPANTE
	 *
	 * la parte del codigo que puede hacerlo estallar es: este instanceof del
	 * principio. Es el unico que hay en todo el manejo de torneos y esta aqui a
	 * proposito, pues es el filtro de la entrada: el administrador del club es
	 * una Persona pero no es Competidor, entonces si alguien intenta meterlo a
	 * un torneo la cosa se cae aqui y no quince pasos despues cuando el torneo
	 * le pregunte el nivel y le llegue un null.
	 *
	 * @param jugador la persona que se inscribe
	 * @throws OperacionNoPermitidaException si esa persona no puede competir en torneos
	 */
	public ParticipanteIndividual( Persona jugador ) throws OperacionNoPermitidaException
	{
		if( !( jugador instanceof Competidor ) )
		{
			throw new OperacionNoPermitidaException( jugador.getNombreCompleto( ) + " es " + jugador.getRol( ) + " y ese rol no compite en torneos" );
		}
		this.jugador = jugador;
	}

	/**
	 * VER AL JUGADOR COMO COMPETIDOR
	 *
	 * El constructor ya reviso que si lo sea, entonces aqui el cast es seguro.
	 *
	 * @return el jugador visto como competidor
	 */
	private Competidor getCompetidor( )
	{
		return ( Competidor ) jugador;
	}

	@Override
	public String getNombre( )
	{
		return jugador.getNombreCompleto( );
	}

	@Override
	public List<Persona> getIntegrantes( )
	{
		List<Persona> integrantes = new ArrayList<Persona>( );
		integrantes.add( jugador );
		return integrantes;
	}

	@Override
	public Nivel getNivelEn( String nombreDisciplina )
	{
		return getCompetidor( ).getNivelEn( nombreDisciplina );
	}

	@Override
	public Categoria getCategoria( )
	{
		return null;
	}

	@Override
	public double getPuntajeEn( String nombreDisciplina )
	{
		return getCompetidor( ).getPuntajeEn( nombreDisciplina );
	}

	@Override
	public Modalidad getModalidad( )
	{
		return Modalidad.INDIVIDUAL;
	}

	/**
	 * REVISAR SI ESTA EN CONDICIONES DE COMPETIR
	 *
	 * Un jugador solo no tiene nada que revisar aqui y por eso el metodo queda
	 * vacio. Pues lo del nivel y lo del cupo no lo puede saber el participante,
	 * eso depende del torneo al que se este metiendo y entonces lo revisa el
	 * torneo. El que si tiene algo propio que revisar es el equipo, que mira su
	 * minimo de jugadores, y por eso el metodo existe aca arriba.
	 */
	@Override
	public void validarPuedeCompetir( ) throws ClubException
	{
	}

	public Persona getJugador( )
	{
		return jugador;
	}
}
