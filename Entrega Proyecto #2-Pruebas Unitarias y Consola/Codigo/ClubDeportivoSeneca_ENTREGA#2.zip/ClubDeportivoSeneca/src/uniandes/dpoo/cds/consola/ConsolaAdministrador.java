package uniandes.dpoo.cds.consola;

import java.time.LocalDate;

import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.entrenamiento.SolicitudCambioTurno;
import uniandes.dpoo.cds.modelo.personas.Administrador;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.modelo.torneos.Encuentro;
import uniandes.dpoo.cds.modelo.torneos.EstadoTorneo;
import uniandes.dpoo.cds.modelo.torneos.InscripcionTorneo;
import uniandes.dpoo.cds.modelo.torneos.Modalidad;
import uniandes.dpoo.cds.modelo.torneos.Participante;
import uniandes.dpoo.cds.modelo.torneos.Torneo;
import uniandes.dpoo.cds.modelo.torneos.TorneoCompetitivo;
import uniandes.dpoo.cds.modelo.torneos.TorneoRecreativo;

/**
 * PROGRAMA DE CONSOLA DEL ADMINISTRADOR
 *
 * Es el programa con el que el administrador del club monta los torneos y los
 * lleva de principio a fin: los crea, les cambia los cupos, los cancela, libera
 * los preferenciales que sobraron, los arranca, va registrando los resultados y
 * al final los cierra entregando el premio.
 *
 * Ademas atiende las solicitudes de cambio de turno de los empleados, que es la
 * historia que veniamos trayendo desde la Entrega 1.
 *
 * Fijese que este programa no calcula nada: todo se lo pide a la fachada Club.
 * Eso es a proposito, pues las reglas del club viven en el modelo y la consola
 * es solo la ventanita por donde se le habla.
 */
public class ConsolaAdministrador extends ConsolaBase
{
	@Override
	protected String getTitulo( )
	{
		return "CLUB DEPORTIVO SENECA - CONSOLA DEL ADMINISTRADOR";
	}

	@Override
	protected boolean admiteUsuario( Persona persona )
	{
		return persona instanceof Administrador;
	}

	@Override
	protected String[] getOpciones( )
	{
		return new String[] {
				"Crear un torneo",
				"Ver los torneos",
				"Modificar los cupos de un torneo",
				"Cancelar un torneo",
				"Liberar los cupos preferenciales que sobraron",
				"Iniciar un torneo",
				"Registrar el resultado de un encuentro",
				"Finalizar un torneo y entregar el premio",
				"Ver el historial de un torneo",
				"Atender una solicitud de cambio de turno",
				"Ver el ranking de una disciplina" };
	}

	@Override
	protected void atender( int opcion ) throws Exception
	{
		if( opcion == 1 )
		{
			crearTorneo( );
		}
		else if( opcion == 2 )
		{
			verTorneos( );
		}
		else if( opcion == 3 )
		{
			modificarCupos( );
		}
		else if( opcion == 4 )
		{
			cancelarTorneo( );
		}
		else if( opcion == 5 )
		{
			liberarPreferenciales( );
		}
		else if( opcion == 6 )
		{
			iniciarTorneo( );
		}
		else if( opcion == 7 )
		{
			registrarResultado( );
		}
		else if( opcion == 8 )
		{
			finalizarTorneo( );
		}
		else if( opcion == 9 )
		{
			verHistorial( );
		}
		else if( opcion == 10 )
		{
			atenderSolicitud( );
		}
		else if( opcion == 11 )
		{
			verRanking( );
		}
	}

	/**
	 * CREAR UN TORNEO
	 *
	 * Le pregunta primero la modalidad porque de eso depende todo lo demas: si es
	 * de conjunto entonces pide categoria y no nivel, y si es individual o de
	 * dobles pide nivel y no categoria.
	 *
	 * @throws Exception si el torneo no se puede crear
	 */
	private void crearTorneo( ) throws Exception
	{
		String codigo = entrada.leerTexto( "Codigo del torneo" );
		String nombre = entrada.leerTexto( "Nombre del torneo" );

		System.out.println( "\nModalidad:  1. Individual   2. Dobles   3. Conjunto" );
		int opcionModalidad = entrada.leerOpcion( 1, 3 );
		Modalidad modalidad = Modalidad.INDIVIDUAL;
		if( opcionModalidad == 2 )
		{
			modalidad = Modalidad.DOBLES;
		}
		else if( opcionModalidad == 3 )
		{
			modalidad = Modalidad.CONJUNTO;
		}

		String disciplina = entrada.leerTexto( "Disciplina o deporte (Tenis, Padel, Tenis de mesa, Futbol, Baloncesto, Voleibol)" );

		Nivel nivel = null;
		Categoria categoria = null;
		if( modalidad.esDeEquipos( ) )
		{
			categoria = pedirCategoria( );
		}
		else
		{
			nivel = pedirNivel( );
		}

		LocalDate fecha = entrada.leerFecha( "Fecha del torneo" );
		int cupos = entrada.leerEntero( "Cuantos cupos" );

		System.out.println( "\nTipo:  1. Competitivo (cobra inscripcion y da plata)   2. Recreativo (gratis y da bono)" );
		Torneo torneo = null;
		if( entrada.leerOpcion( 1, 2 ) == 1 )
		{
			double tarifa = entrada.leerDecimal( "Tarifa de inscripcion" );
			double porcentaje = entrada.leerPorcentaje( "Porcentaje de lo recaudado que se lleva el campeon" );
			torneo = new TorneoCompetitivo( codigo, nombre, modalidad, disciplina, nivel, categoria, fecha, cupos, tarifa, porcentaje );
		}
		else
		{
			double porcentaje = entrada.leerPorcentaje( "Porcentaje de descuento del bono" );
			torneo = new TorneoRecreativo( codigo, nombre, modalidad, disciplina, nivel, categoria, fecha, cupos, porcentaje );
		}

		club.crearTorneo( torneo );

		System.out.println( "\n   Torneo creado: " + torneo );
		System.out.println( "   Cupos preferenciales: " + torneo.getCuposPreferenciales( ) + " | regulares: " + torneo.getCuposRegulares( ) );
	}

	private Nivel pedirNivel( )
	{
		System.out.println( "\nNivel:  1. Principiante   2. Intermedio   3. Avanzado" );
		int opcion = entrada.leerOpcion( 1, 3 );
		if( opcion == 1 )
		{
			return Nivel.PRINCIPIANTE;
		}
		if( opcion == 2 )
		{
			return Nivel.INTERMEDIO;
		}
		return Nivel.AVANZADO;
	}

	private Categoria pedirCategoria( )
	{
		System.out.println( "\nCategoria:  1. Sub-13   2. Sub-15   3. Sub-17   4. Mayores" );
		int opcion = entrada.leerOpcion( 1, 4 );
		if( opcion == 1 )
		{
			return Categoria.SUB_13;
		}
		if( opcion == 2 )
		{
			return Categoria.SUB_15;
		}
		if( opcion == 3 )
		{
			return Categoria.SUB_17;
		}
		return Categoria.MAYORES;
	}

	private void verTorneos( )
	{
		System.out.println( "Filtrar:  1. Todos   2. Inscripciones abiertas   3. En curso   4. Finalizados   5. Cancelados" );
		int opcion = entrada.leerOpcion( 1, 5 );
		EstadoTorneo filtro = null;
		if( opcion == 2 )
		{
			filtro = EstadoTorneo.INSCRIPCIONES_ABIERTAS;
		}
		else if( opcion == 3 )
		{
			filtro = EstadoTorneo.EN_CURSO;
		}
		else if( opcion == 4 )
		{
			filtro = EstadoTorneo.FINALIZADO;
		}
		else if( opcion == 5 )
		{
			filtro = EstadoTorneo.CANCELADO;
		}

		System.out.println( );
		for( Torneo torneo : club.consultarTorneos( filtro ) )
		{
			System.out.println( "   " + torneo );
		}
	}

	/**
	 * PEDIR UN TORNEO POR SU CODIGO
	 *
	 * Si el codigo no existe revienta con un mensaje claro, pues es mejor avisar
	 * de una que seguir con un null rodando por ahi.
	 *
	 * @return el torneo que escogio el usuario
	 * @throws Exception si no existe ningun torneo con ese codigo
	 */
	private Torneo pedirTorneo( ) throws Exception
	{
		for( Torneo torneo : club.getTorneos( ).values( ) )
		{
			System.out.println( "   " + torneo );
		}
		String codigo = entrada.leerTexto( "\nCodigo del torneo" );
		Torneo torneo = club.buscarTorneo( codigo );
		if( torneo == null )
		{
			throw new Exception( "No existe ningun torneo con el codigo " + codigo );
		}
		return torneo;
	}

	private void modificarCupos( ) throws Exception
	{
		Torneo torneo = pedirTorneo( );
		int nuevos = entrada.leerEntero( "Nuevo total de cupos" );

		club.modificarCuposTorneo( torneo, nuevos );

		System.out.println( "\n   Ahora tiene " + torneo.getCuposPreferenciales( ) + " cupos preferenciales y " + torneo.getCuposRegulares( ) + " regulares" );
	}

	private void cancelarTorneo( ) throws Exception
	{
		Torneo torneo = pedirTorneo( );
		if( !entrada.confirmar( "Cancelar " + torneo.getNombre( ) + " suelta a los " + torneo.getInscripciones( ).size( ) + " inscritos. Seguro" ) )
		{
			System.out.println( "   No se cancelo nada" );
			return;
		}

		club.cancelarTorneo( torneo );

		System.out.println( "\n   Torneo cancelado" );
	}

	private void liberarPreferenciales( ) throws Exception
	{
		Torneo torneo = pedirTorneo( );

		int liberados = club.liberarCuposPreferenciales( torneo );

		System.out.println( "\n   Se pasaron " + liberados + " cupos preferenciales a regulares" );
		System.out.println( "   Quedan " + torneo.getCuposPreferenciales( ) + " preferenciales y " + torneo.getCuposRegulares( ) + " regulares" );
	}

	private void iniciarTorneo( ) throws Exception
	{
		Torneo torneo = pedirTorneo( );

		club.iniciarTorneo( torneo );

		System.out.println( "\n   Torneo iniciado con " + torneo.getInscripciones( ).size( ) + " participantes" );
		System.out.println( "   Encuentros de la primera ronda:" );
		for( Encuentro encuentro : torneo.getEncuentrosDeRonda( 1 ) )
		{
			System.out.println( "      " + encuentro );
		}
	}

	private void registrarResultado( ) throws Exception
	{
		Torneo torneo = pedirTorneo( );

		System.out.println( "\n   Encuentros pendientes:" );
		for( Encuentro encuentro : torneo.getEncuentros( ) )
		{
			if( !encuentro.isJugado( ) )
			{
				System.out.println( "      " + encuentro );
			}
		}

		String codigo = entrada.leerTexto( "\nCodigo del encuentro" );
		Encuentro escogido = buscarEncuentro( torneo, codigo );
		if( escogido == null )
		{
			throw new Exception( "No existe ningun encuentro con el codigo " + codigo + " en este torneo" );
		}

		int marcadorA = entrada.leerEntero( "Tantos de " + escogido.getParticipanteA( ).getNombre( ) );
		int marcadorB = entrada.leerEntero( "Tantos de " + escogido.getParticipanteB( ).getNombre( ) );

		club.registrarResultadoEncuentro( torneo, escogido, marcadorA, marcadorB );

		System.out.println( "\n   Gano " + escogido.getGanador( ).getNombre( ) );
		if( torneo.contarEncuentrosPendientes( ) == 0 )
		{
			System.out.println( "   Ya no quedan encuentros pendientes, el torneo se puede finalizar" );
		}
	}

	private Encuentro buscarEncuentro( Torneo torneo, String codigo )
	{
		for( Encuentro encuentro : torneo.getEncuentros( ) )
		{
			if( encuentro.getCodigo( ).equalsIgnoreCase( codigo ) )
			{
				return encuentro;
			}
		}
		return null;
	}

	private void finalizarTorneo( ) throws Exception
	{
		Torneo torneo = pedirTorneo( );

		Participante campeon = club.finalizarTorneo( torneo );

		System.out.println( "\n   Torneo finalizado. Campeon: " + campeon.getNombre( ) );
		if( torneo instanceof TorneoCompetitivo )
		{
			TorneoCompetitivo competitivo = ( TorneoCompetitivo ) torneo;
			System.out.println( "   Recaudado: " + String.format( "%.2f", competitivo.getTotalRecaudado( ) ) );
			System.out.println( "   Premio entregado: " + String.format( "%.2f", competitivo.getPremioEntregado( ) ) );
			if( competitivo.getGanadorDelPremio( ) != null && competitivo.getGanadorDelPremio( ) != campeon )
			{
				System.out.println( "   El campeon es empleado del club, entonces el efectivo fue para " + competitivo.getGanadorDelPremio( ).getNombre( ) );
			}
		}
		else if( torneo instanceof TorneoRecreativo )
		{
			TorneoRecreativo recreativo = ( TorneoRecreativo ) torneo;
			System.out.println( "   Bonos entregados: " + recreativo.getBonosEntregados( ).size( ) );
		}
	}

	private void verHistorial( ) throws Exception
	{
		Torneo torneo = pedirTorneo( );

		System.out.println( );
		System.out.println( torneo.getHistorial( ) );
		System.out.println( "   Inscritos:" );
		for( InscripcionTorneo inscripcion : torneo.getInscripciones( ) )
		{
			System.out.println( "      " + inscripcion );
		}
	}

	private void atenderSolicitud( ) throws Exception
	{
		System.out.println( "Solicitudes pendientes:" );
		int pendientes = 0;
		for( SolicitudCambioTurno solicitud : club.getSolicitudes( ) )
		{
			if( solicitud.estaPendiente( ) )
			{
				System.out.println( "   " + solicitud + " | pide pasar a " + solicitud.getNuevoDiaSemana( ) + " de " + solicitud.getNuevaHoraInicio( ) + " a " + solicitud.getNuevaHoraFin( ) );
				pendientes = pendientes + 1;
			}
		}
		if( pendientes == 0 )
		{
			System.out.println( "   (ninguna)" );
			return;
		}

		String codigo = entrada.leerTexto( "\nCodigo de la solicitud" );
		SolicitudCambioTurno escogida = buscarSolicitud( codigo );
		if( escogida == null )
		{
			throw new Exception( "No existe ninguna solicitud pendiente con el codigo " + codigo );
		}

		if( entrada.confirmar( "Aprobar la solicitud" ) )
		{
			club.aprobarCambioTurno( escogida, ( Administrador ) usuario, LocalDate.now( ) );
			System.out.println( "\n   Solicitud aprobada. El turno quedo el " + escogida.getTurno( ).getDiaSemana( ) + " de " + escogida.getTurno( ).getHoraInicio( ) + " a " + escogida.getTurno( ).getHoraFin( ) );
		}
		else
		{
			String observacion = entrada.leerTexto( "Motivo del rechazo" );
			club.rechazarCambioTurno( escogida, ( Administrador ) usuario, LocalDate.now( ), observacion );
			System.out.println( "\n   Solicitud rechazada" );
		}
	}

	private SolicitudCambioTurno buscarSolicitud( String codigo )
	{
		for( SolicitudCambioTurno solicitud : club.getSolicitudes( ) )
		{
			if( solicitud.estaPendiente( ) && solicitud.getCodigo( ).equalsIgnoreCase( codigo ) )
			{
				return solicitud;
			}
		}
		return null;
	}

	private void verRanking( )
	{
		String disciplina = entrada.leerTexto( "Disciplina" );
		int puesto = 1;
		System.out.println( );
		for( uniandes.dpoo.cds.modelo.academias.InscripcionAcademia inscripcion : club.getRankingDisciplina( disciplina, null ) )
		{
			System.out.println( "   " + puesto + ". " + inscripcion );
			puesto = puesto + 1;
		}
		if( puesto == 1 )
		{
			System.out.println( "   (nadie inscrito en " + disciplina + ")" );
		}
	}

	/**
	 * ARRANCAR EL PROGRAMA DEL ADMINISTRADOR
	 *
	 * @param args no se usan
	 */
	public static void main( String[] args )
	{
		new ConsolaAdministrador( ).arrancar( );
	}
}
