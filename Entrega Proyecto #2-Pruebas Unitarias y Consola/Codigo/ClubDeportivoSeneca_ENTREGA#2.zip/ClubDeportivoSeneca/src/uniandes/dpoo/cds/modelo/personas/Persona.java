package uniandes.dpoo.cds.modelo.personas;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.tienda.Bono;

/**
 * PERSONA, LA RAIZ DE TODOS LOS USUARIOS
 *
 * Aqui esta todo lo que cualquier persona del club tiene si o si, pues el
 * documento, el nombre, el login y la contrasena los necesita todo el mundo
 * entonces los ponemos una sola vez aca arriba y las subclases los heredan.
 *
 * Es abstracta porque en el club nadie esta registrado solo como "persona": o
 * es afiliado, o es empleado, o es el administrador y asi.
 */
public abstract class Persona implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String documento;

	private String nombre;

	private String apellido;

	private LocalDate fechaNacimiento;

	private String correo;

	private String telefono;

	private String login;

	private String password;

	// CAMBIO DEL PROYECTO 2
	// Los bonos de los torneos recreativos quedan aqui arriba en Persona y no en
	// Afiliado, pues a los torneos entran afiliados, estudiantes, externos y
	// empleados, y cualquiera de ellos puede ganar y llevarse su bono. Si los
	// pusieramos en Afiliado entonces un estudiante que gana no tendria donde
	// guardarlo.
	private List<Bono> bonos;

	public Persona( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password )
	{
		this.bonos = new ArrayList<Bono>( );
		this.documento = documento;
		this.nombre = nombre;
		this.apellido = apellido;
		this.fechaNacimiento = fechaNacimiento;
		this.correo = correo;
		this.telefono = telefono;
		this.login = login;
		this.password = password;
	}

	/**
	 * CALCULAR LA EDAD
	 *
	 * La edad no la guardamos como atributo porque cambia sola con el tiempo,
	 * entonces nos tocaria estarla actualizando cada ano y eso es un problema.
	 * Mejor la sacamos de la fecha de nacimiento, que esa si nunca cambia.
	 *
	 * nota: aqui usamos java.time, que no lo vimos en clase. LocalDate es una
	 * fecha normal de calendario y ya, sin horas ni nada. LocalDate.now() da la
	 * fecha de hoy. Period.between() mide cuanto hay entre dos fechas y con
	 * getYears() le pedimos solo los anos completos, que es la edad. Lo usamos
	 * pues para no tener que partir un texto tipo "2006-05-14" en pedacitos y
	 * restar a mano, que es donde uno se equivoca.
	 *
	 * @return la edad en anos cumplidos
	 */
	public int getEdad( )
	{
		if( fechaNacimiento == null )
		{
			return 0;
		}
		return Period.between( fechaNacimiento, LocalDate.now( ) ).getYears( );
	}

	/**
	 * REVISAR USUARIO Y CONTRASENA
	 *
	 * Compara lo que escribio el usuario contra lo que tiene guardado la persona,
	 * entonces si las dos cosas coinciden lo deja entrar y si no, no.
	 *
	 * @param login el login que se quiere verificar
	 * @param password la contrasena que se quiere verificar
	 * @return true si ambas credenciales coinciden
	 */
	public boolean autenticar( String login, String password )
	{
		return this.login.equals( login ) && this.password.equals( password );
	}

	/**
	 * QUE ROL TIENE LA PERSONA
	 *
	 * Cada subclase contesta lo suyo, pues el Entrenador dice "Entrenador" y el
	 * Administrador dice "Administrador" y asi. Esto es polimorfismo: uno le
	 * pregunta lo mismo a todas y cada una responde distinto.
	 *
	 * Lo hicimos asi entonces para no tener que andar preguntando con instanceof
	 * de que clase es cada objeto, que eso queda feo y se llena de ifs.
	 *
	 * @return el nombre del rol
	 */
	public abstract String getRol( );

	/**
	 * GUARDAR UN BONO QUE SE GANO
	 *
	 * @param bono el bono que le entrego un torneo recreativo
	 */
	public void agregarBono( Bono bono )
	{
		bonos.add( bono );
	}

	/**
	 * BUSCAR UN BONO POR SU CODIGO
	 *
	 * Si no es de esta persona devuelve null, entonces nadie puede usar el bono
	 * de otro aunque sepa el codigo.
	 *
	 * @param codigo el codigo del bono
	 * @return el bono, o null si esta persona no lo tiene
	 */
	public Bono buscarBono( String codigo )
	{
		for( Bono bono : bonos )
		{
			if( bono.getCodigo( ).equals( codigo ) )
			{
				return bono;
			}
		}
		return null;
	}

	/**
	 * LISTAR LOS BONOS QUE TODAVIA SIRVEN
	 *
	 * Sirve pues la historia de usuario pide ver los bonos con su estado, y para
	 * redimir solo valen los que no se han usado.
	 *
	 * @return los bonos que no han sido usados
	 */
	public List<Bono> getBonosDisponibles( )
	{
		List<Bono> disponibles = new ArrayList<Bono>( );
		for( Bono bono : bonos )
		{
			if( !bono.isUsado( ) )
			{
				disponibles.add( bono );
			}
		}
		return disponibles;
	}

	public List<Bono> getBonos( )
	{
		return bonos;
	}

	public String getNombreCompleto( )
	{
		return nombre + " " + apellido;
	}

	public String getDocumento( )
	{
		return documento;
	}

	public void setDocumento( String documento )
	{
		this.documento = documento;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public String getApellido( )
	{
		return apellido;
	}

	public void setApellido( String apellido )
	{
		this.apellido = apellido;
	}

	public LocalDate getFechaNacimiento( )
	{
		return fechaNacimiento;
	}

	public void setFechaNacimiento( LocalDate fechaNacimiento )
	{
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getCorreo( )
	{
		return correo;
	}

	public void setCorreo( String correo )
	{
		this.correo = correo;
	}

	public String getTelefono( )
	{
		return telefono;
	}

	public void setTelefono( String telefono )
	{
		this.telefono = telefono;
	}

	public String getLogin( )
	{
		return login;
	}

	public void setLogin( String login )
	{
		this.login = login;
	}

	public String getPassword( )
	{
		return password;
	}

	public void setPassword( String password )
	{
		this.password = password;
	}

	@Override
	public String toString( )
	{
		return getRol( ) + " " + getNombreCompleto( ) + " (" + documento + ")";
	}
}
