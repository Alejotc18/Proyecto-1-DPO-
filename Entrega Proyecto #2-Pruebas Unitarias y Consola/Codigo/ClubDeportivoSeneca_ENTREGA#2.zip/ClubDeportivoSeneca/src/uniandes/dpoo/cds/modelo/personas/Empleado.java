package uniandes.dpoo.cds.modelo.personas;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.entrenamiento.Turno;
import uniandes.dpoo.cds.modelo.tienda.CodigoDescuento;

/**
 * EMPLEADO, O SEA ALGUIEN QUE TRABAJA EN EL CLUB
 *
 * Es abstracta porque todo empleado es entrenador o fisioterapeuta.
 *
 * Los separamos pues el club pide minimos distintos de cada uno, o sea dos
 * entrenadores y un fisioterapeuta, entonces si los dejamos todos como
 * "empleado" no podriamos contar por aparte y la validacion no saldria.
 *
 * CAMBIO DEL PROYECTO 2
 * Ahora tambien implementa Competidor, pues el enunciado deja que los empleados
 * se metan a los torneos individuales. Eso les trae dos reglas propias: no pagan
 * inscripcion y, si ganan un competitivo, el premio en efectivo pasa al
 * siguiente de la tabla que no sea empleado, que es la decision D8.
 */
public abstract class Empleado extends Persona implements Competidor
{
	private static final long serialVersionUID = 1L;

	private String codigoEmpleado;

	private LocalDate fechaContratacion;

	private boolean activo;

	private CodigoDescuento codigoDescuento;

	private List<Turno> turnos;

	// Es el nivel con el que el empleado se mete a los torneos individuales. No
	// sale de ninguna academia porque el empleado no es socio, entonces lo
	// declara el administrador cuando lo deja competir.
	private Nivel nivelDeclarado;

	public Empleado( String documento, String nombre, String apellido, LocalDate fechaNacimiento, String correo, String telefono, String login, String password, String codigoEmpleado, LocalDate fechaContratacion )
	{
		super( documento, nombre, apellido, fechaNacimiento, correo, telefono, login, password );
		this.codigoEmpleado = codigoEmpleado;
		this.fechaContratacion = fechaContratacion;
		this.activo = true;
		this.turnos = new ArrayList<Turno>( );

		// CAMBIO DEL PROYECTO 2
		// El codigo de descuento se arma aqui mismo. Antes solo se lo ponia el
		// repositorio al leer el archivo, entonces un empleado creado desde un
		// programa o desde una prueba quedaba sin codigo y al intentar usarlo
		// reventaba diciendo que el codigo no estaba activo. Y es que todo
		// empleado tiene codigo de descuento por el solo hecho de ser empleado,
		// entonces el lugar donde se crea es este y no el repositorio.
		this.codigoDescuento = new CodigoDescuento( "DESC-" + codigoEmpleado, this );
	}

	/**
	 * REVISAR SI TIENE UNA SOLICITUD SIN RESPONDER
	 *
	 * La regla del club es que uno no puede tener dos solicitudes de cambio de
	 * turno pendientes al tiempo, entonces hay que revisar esto antes de dejarlo
	 * pedir otra.
	 *
	 * @return true si existe al menos una solicitud pendiente
	 */
	public boolean tieneSolicitudPendiente( )
	{
		for( Turno turno : turnos )
		{
			if( turno.tieneSolicitudPendiente( ) )
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * CONTAR LOS TURNOS DE UN DIA
	 *
	 * Sirve pues para saber cuanta gente hay cubriendo ese dia, que es lo que
	 * despues usa el club para revisar la cobertura minima.
	 *
	 * @param diaSemana el dia que se quiere revisar
	 * @param semana el identificador de la semana
	 * @return la cantidad de turnos vigentes
	 */
	public int contarTurnos( String diaSemana, String semana )
	{
		int total = 0;
		for( Turno turno : turnos )
		{
			if( turno.isVigente( ) && turno.getDiaSemana( ).equals( diaSemana ) && turno.getSemana( ).equals( semana ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	/**
	 * REVISAR SI ESTA DE TURNO ESE DIA
	 *
	 * CAMBIO DEL PROYECTO 2, DECISION DE DISENO D10
	 * Es la regla que no deja que un empleado se inscriba a un torneo si ese dia
	 * le toca trabajar. Cada turno sabe traducir la fecha a dia y semana y
	 * responder si le corresponde, entonces aqui solo hay que recorrerlos.
	 *
	 * @param fecha la fecha que se quiere revisar
	 * @return true si tiene al menos un turno vigente ese dia
	 */
	public boolean tieneTurnoEn( LocalDate fecha )
	{
		for( Turno turno : turnos )
		{
			if( turno.cubre( fecha ) )
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * LISTAR LOS TURNOS DE UN DIA
	 *
	 * Es la historia del banco de la Entrega 1 donde el empleado quiere ver que
	 * le toca un dia puntual, y ahora se puede consultar con una fecha normal y
	 * no teniendo que saberse el identificador de la semana.
	 *
	 * @param fecha la fecha que se quiere consultar
	 * @return los turnos vigentes de ese dia
	 */
	public List<Turno> getTurnosEn( LocalDate fecha )
	{
		List<Turno> delDia = new ArrayList<Turno>( );
		for( Turno turno : turnos )
		{
			if( turno.cubre( fecha ) )
			{
				delDia.add( turno );
			}
		}
		return delDia;
	}

	/**
	 * EN QUE NIVEL COMPITE
	 *
	 * Es el nivel que le declararon, igual para cualquier disciplina, pues el
	 * empleado no tiene inscripciones a las academias del club.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return el nivel declarado
	 */
	@Override
	public Nivel getNivelEn( String nombreDisciplina )
	{
		return nivelDeclarado;
	}

	/**
	 * CUANTO PUNTAJE DE RANKING TIENE
	 *
	 * Cero, pues el ranking es de los afiliados de las academias. Entonces el
	 * empleado nunca entra por cupo preferencial.
	 *
	 * @param nombreDisciplina el nombre de la disciplina
	 * @return siempre cero
	 */
	@Override
	public double getPuntajeEn( String nombreDisciplina )
	{
		return 0.0;
	}

	@Override
	public boolean esEmpleadoDelClub( )
	{
		return true;
	}

	public Nivel getNivelDeclarado( )
	{
		return nivelDeclarado;
	}

	public void setNivelDeclarado( Nivel nivelDeclarado )
	{
		this.nivelDeclarado = nivelDeclarado;
	}

	public void agregarTurno( Turno turno )
	{
		turnos.add( turno );
	}

	public String getCodigoEmpleado( )
	{
		return codigoEmpleado;
	}

	public void setCodigoEmpleado( String codigoEmpleado )
	{
		this.codigoEmpleado = codigoEmpleado;
	}

	public LocalDate getFechaContratacion( )
	{
		return fechaContratacion;
	}

	public void setFechaContratacion( LocalDate fechaContratacion )
	{
		this.fechaContratacion = fechaContratacion;
	}

	public boolean isActivo( )
	{
		return activo;
	}

	public void setActivo( boolean activo )
	{
		this.activo = activo;
	}

	public CodigoDescuento getCodigoDescuento( )
	{
		return codigoDescuento;
	}

	public void setCodigoDescuento( CodigoDescuento codigoDescuento )
	{
		this.codigoDescuento = codigoDescuento;
	}

	public List<Turno> getTurnos( )
	{
		return turnos;
	}
}
