package uniandes.dpoo.cds.logica;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import uniandes.dpoo.cds.excepciones.ClubException;
import uniandes.dpoo.cds.excepciones.CoberturaMinimaException;
import uniandes.dpoo.cds.excepciones.OperacionNoPermitidaException;
import uniandes.dpoo.cds.excepciones.ReservaNoDisponibleException;
import uniandes.dpoo.cds.modelo.academias.InscripcionAcademia;
import uniandes.dpoo.cds.modelo.academias.Instalacion;
import uniandes.dpoo.cds.modelo.academias.Nivel;
import uniandes.dpoo.cds.modelo.academias.Reserva;
import uniandes.dpoo.cds.modelo.competencias.Competencia;
import uniandes.dpoo.cds.modelo.deportes.Categoria;
import uniandes.dpoo.cds.modelo.deportes.Equipo;
import uniandes.dpoo.cds.modelo.deportes.EstadisticaFutbol;
import uniandes.dpoo.cds.modelo.deportes.Estadistica;
import uniandes.dpoo.cds.modelo.deportes.Partido;
import uniandes.dpoo.cds.modelo.deportes.PartidoInterno;
import uniandes.dpoo.cds.modelo.deportes.PartidoPractica;
import uniandes.dpoo.cds.modelo.deportes.Sancion;
import uniandes.dpoo.cds.modelo.entrenamiento.SesionEntrenamiento;
import uniandes.dpoo.cds.modelo.entrenamiento.SolicitudCambioTurno;
import uniandes.dpoo.cds.modelo.entrenamiento.Turno;
import uniandes.dpoo.cds.modelo.personas.Administrador;
import uniandes.dpoo.cds.modelo.personas.Afiliado;
import uniandes.dpoo.cds.modelo.personas.AfiliadoConjunto;
import uniandes.dpoo.cds.modelo.personas.AfiliadoIndividual;
import uniandes.dpoo.cds.modelo.personas.Empleado;
import uniandes.dpoo.cds.modelo.personas.Entrenador;
import uniandes.dpoo.cds.modelo.personas.Fisioterapeuta;
import uniandes.dpoo.cds.modelo.personas.Persona;
import uniandes.dpoo.cds.modelo.tienda.Bono;
import uniandes.dpoo.cds.modelo.tienda.Producto;
import uniandes.dpoo.cds.modelo.tienda.SugerenciaProducto;
import uniandes.dpoo.cds.modelo.tienda.Venta;
import uniandes.dpoo.cds.modelo.torneos.Encuentro;
import uniandes.dpoo.cds.modelo.torneos.EstadoTorneo;
import uniandes.dpoo.cds.modelo.torneos.InscripcionTorneo;
import uniandes.dpoo.cds.modelo.torneos.Participante;
import uniandes.dpoo.cds.modelo.torneos.ParticipanteEquipo;
import uniandes.dpoo.cds.modelo.torneos.ParticipanteIndividual;
import uniandes.dpoo.cds.modelo.torneos.ParticipantePareja;
import uniandes.dpoo.cds.modelo.torneos.Torneo;
import uniandes.dpoo.cds.reglas.ReglasDisciplina;

/**
 * CLUB, PATRON FACHADA
 *
 * Esta es la puerta de entrada a todo el sistema.
 *
 * La idea es que los programas de consola no anden metiendo la mano en las
 * listas ni armando objetos por su cuenta, sino que le pidan operaciones
 * completas a esta clase. Entonces ella coordina a los objetos del modelo y
 * aplica las reglas que tocan a varias clases al tiempo.
 *
 * Las reglas que pertenecen a un solo objeto estan en ese objeto, entonces aqui
 * estan las que cruzan varias clases y asi. Por ejemplo que un equipo tenga
 * cupo lo sabe el equipo, pero la cobertura minima de personal no la sabe nadie
 * solo, porque toca mirar los turnos de todos los empleados.
 *
 * DECISION DE DISENO
 * Pensamos hacerla Singleton y lo descartamos por dos razones. La primera es
 * que obligaria a que exista un solo club en toda la ejecucion, y eso enreda
 * las pruebas de la siguiente entrega, pues cada prueba necesita arrancar de
 * cero. La segunda es que el Singleton esconde la dependencia: cualquier clase
 * podria llamar a Club.getInstancia() sin que eso se vea en su firma ni en el
 * diagrama. Entonces mejor cada programa crea su propio club y se lo pasa a
 * quien lo necesite.
 */
public class Club implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String nombre;

	private String institucion;

	private LocalTime horaApertura;

	private LocalTime horaCierre;

	private int minimoEntrenadores;

	private int minimoFisioterapeutas;

	private int maximoInstalacionesSimultaneas;

	// nota: todo esto de Map lo sugirio Claude como forma de implementarlo para
	// que el codigo no estalle, nosotros no lo vimos en clase. Lo dejamos porque
	// si funciona y porque la alternativa era peor.
	//
	// Un Map guarda pares de clave y valor. Aqui la clave es el documento de la
	// persona o el codigo del equipo, y el valor es el objeto. Entonces buscar a
	// alguien es personas.get("1020304050") y llega de una.
	//
	// Con una lista normal tocaria recorrerla entera comparando documentos cada
	// vez que uno busca a alguien, y ademas no habria nada que impida meter dos
	// personas con el mismo documento. Con el Map eso no pasa pues la clave es
	// unica y asi.
	//
	// Usamos LinkedHashMap, que es un Map que se acuerda del orden en que uno
	// metio las cosas. Pues asi los reportes salen siempre igual y no cambiando
	// de orden cada vez que se corre el programa.
	private Map<String, Persona> personas;

	private Map<String, Equipo> equipos;

	private Map<String, Competencia> competencias;

	private Map<String, Instalacion> instalaciones;

	private Map<String, Producto> productos;

	// CAMBIO DEL PROYECTO 2
	// Los torneos van en un Map igual que los equipos y los productos, porque la
	// operacion que mas se hace con ellos es buscarlos por codigo, y asi el
	// codigo repetido queda imposible por construccion.
	private Map<String, Torneo> torneos;

	private List<Reserva> reservas;

	private List<Partido> partidos;

	private List<SesionEntrenamiento> sesiones;

	private List<Turno> turnos;

	private List<SolicitudCambioTurno> solicitudes;

	private List<Venta> ventas;

	private List<SugerenciaProducto> sugerencias;

	public static final int MINIMO_ENTRENADORES = 2;

	public static final int MINIMO_FISIOTERAPEUTAS = 1;

	public Club( String nombre, String institucion, LocalTime horaApertura, LocalTime horaCierre, int maximoInstalacionesSimultaneas )
	{
		this.nombre = nombre;
		this.institucion = institucion;
		this.horaApertura = horaApertura;
		this.horaCierre = horaCierre;
		this.minimoEntrenadores = MINIMO_ENTRENADORES;
		this.minimoFisioterapeutas = MINIMO_FISIOTERAPEUTAS;
		this.maximoInstalacionesSimultaneas = maximoInstalacionesSimultaneas;
		this.personas = new LinkedHashMap<String, Persona>( );
		this.equipos = new LinkedHashMap<String, Equipo>( );
		this.competencias = new LinkedHashMap<String, Competencia>( );
		this.instalaciones = new LinkedHashMap<String, Instalacion>( );
		this.productos = new LinkedHashMap<String, Producto>( );
		this.torneos = new LinkedHashMap<String, Torneo>( );
		this.reservas = new ArrayList<Reserva>( );
		this.partidos = new ArrayList<Partido>( );
		this.sesiones = new ArrayList<SesionEntrenamiento>( );
		this.turnos = new ArrayList<Turno>( );
		this.solicitudes = new ArrayList<SolicitudCambioTurno>( );
		this.ventas = new ArrayList<Venta>( );
		this.sugerencias = new ArrayList<SugerenciaProducto>( );
	}

	// USUARIOS Y AUTENTICACION

	/**
	 * REGISTRAR UNA PERSONA NUEVA
	 *
	 * Antes de meterla revisa que no haya otra con el mismo documento ni con el
	 * mismo login, pues si dejaramos repetidos despues no se sabria a quien
	 * corresponde cada cosa y asi.
	 *
	 * @param persona la persona que se quiere registrar
	 * @throws OperacionNoPermitidaException si el documento o el login ya estan en uso
	 */
	public void registrarPersona( Persona persona ) throws OperacionNoPermitidaException
	{
		if( personas.containsKey( persona.getDocumento( ) ) )
		{
			throw new OperacionNoPermitidaException( "Ya existe una persona registrada con el documento " + persona.getDocumento( ) );
		}
		if( buscarPorLogin( persona.getLogin( ) ) != null )
		{
			throw new OperacionNoPermitidaException( "El login '" + persona.getLogin( ) + "' ya esta en uso" );
		}
		personas.put( persona.getDocumento( ), persona );
	}

	/**
	 * ENTRAR AL SISTEMA
	 *
	 * Recorre las personas y le pregunta a cada una si esas credenciales son las
	 * suyas. Si ninguna dice que si entonces devuelve null.
	 *
	 * @param login el login que se quiere autenticar
	 * @param password la contrasena
	 * @return la persona autenticada, o null si las credenciales no son validas
	 */
	public Persona autenticar( String login, String password )
	{
		for( Persona persona : personas.values( ) )
		{
			if( persona.autenticar( login, password ) )
			{
				return persona;
			}
		}
		return null;
	}

	public Persona buscarPorLogin( String login )
	{
		for( Persona persona : personas.values( ) )
		{
			if( persona.getLogin( ).equals( login ) )
			{
				return persona;
			}
		}
		return null;
	}

	public Persona buscarPersona( String documento )
	{
		return personas.get( documento );
	}

	// DEPORTES DE CONJUNTO

	/**
	 * REGISTRAR UN PARTIDO INTERNO
	 *
	 * Hace cuatro cosas en este orden: revisa que el partido si se pueda jugar,
	 * guarda el marcador, le descuenta un partido a las sanciones que ya estaban
	 * vigentes, y crea las sanciones nuevas que salieron de las tarjetas de hoy.
	 *
	 * la parte del codigo que puede hacerlo estallar es: el orden de los pasos
	 * tres y cuatro. Si se crean las sanciones nuevas ANTES de descontar las
	 * viejas, entonces una tarjeta que el man saco hoy quedaria pagada con el
	 * partido de hoy, que es el que acaba de jugar, y se iria libre. Por eso
	 * esta operacion esta aqui en la fachada y no suelta en cada programa, pues
	 * asi nadie se puede equivocar de orden.
	 *
	 * la parte del codigo que puede hacerlo estallar es: coordina las reglas de varios objetos y es el nucleo del
	 * programa de prueba 3.
	 *
	 * @param partido el partido que se va a registrar
	 * @param marcadorLocal los tantos del equipo local
	 * @param marcadorVisitante los tantos del equipo visitante
	 * @throws ClubException si el partido no puede disputarse
	 */
	public void registrarPartidoInterno( PartidoInterno partido, int marcadorLocal, int marcadorVisitante ) throws ClubException
	{
		partido.validarPuedeJugarse( );
		partido.registrarMarcador( marcadorLocal, marcadorVisitante );

		partido.getEquipoLocal( ).descontarSanciones( );
		partido.getEquipoVisitante( ).descontarSanciones( );

		generarSanciones( partido );

		// CAMBIO DEL PROYECTO 2, DECISION DE DISENO D5
		// De aqui sale el ranking de equipos que antes no existia. El marcador lo
		// ve la fachada, entonces es ella la que le suma la victoria al que gano y
		// con ese contador despues se ordenan los cupos preferenciales de los
		// torneos de conjunto.
		if( marcadorLocal > marcadorVisitante )
		{
			partido.getEquipoLocal( ).registrarVictoria( );
		}
		else if( marcadorVisitante > marcadorLocal )
		{
			partido.getEquipoVisitante( ).registrarVictoria( );
		}

		if( !partidos.contains( partido ) )
		{
			partidos.add( partido );
		}
	}

	/**
	 * CREAR LAS SANCIONES DEL PARTIDO
	 *
	 * Revisa las estadisticas una por una y donde haya tarjetas crea la sancion.
	 *
	 * Solo las de futbol pueden generar suspensiones, pues es el unico deporte
	 * del club donde hay tarjetas y asi.
	 *
	 * @param partido el partido cuyas estadisticas se van a revisar
	 */
	private void generarSanciones( PartidoInterno partido )
	{
		for( Estadistica estadistica : partido.getEstadisticas( ) )
		{
			if( estadistica instanceof EstadisticaFutbol )
			{
				EstadisticaFutbol estadisticaFutbol = ( EstadisticaFutbol ) estadistica;
				if( estadisticaFutbol.generaSuspension( ) )
				{
					Afiliado jugador = estadistica.getJugador( );
					if( jugador instanceof AfiliadoConjunto )
					{
						AfiliadoConjunto jugadorConjunto = ( AfiliadoConjunto ) jugador;
						Equipo equipo = buscarEquipoDelJugador( jugadorConjunto, partido );
						Sancion sancion = new Sancion( jugadorConjunto, equipo, estadisticaFutbol.getMotivoSuspension( ), partido.getFecha( ), 1 );
						jugadorConjunto.agregarSancion( sancion );
					}
				}
			}
		}
	}

	/**
	 * BUSCAR EN QUE EQUIPO JUGO
	 *
	 * Sirve para saber a cual de los dos equipos hay que pegarle la sancion,
	 * pues el jugador puede estar en varios equipos del club.
	 *
	 * @param jugador el jugador que se esta buscando
	 * @param partido el partido que se esta registrando
	 * @return el equipo al que pertenece el jugador
	 */
	private Equipo buscarEquipoDelJugador( AfiliadoConjunto jugador, PartidoInterno partido )
	{
		if( jugador.buscarInscripcion( partido.getEquipoLocal( ) ) != null )
		{
			return partido.getEquipoLocal( );
		}
		return partido.getEquipoVisitante( );
	}

	public void agregarEquipo( Equipo equipo )
	{
		equipos.put( equipo.getCodigo( ), equipo );
	}

	public Equipo buscarEquipo( String codigo )
	{
		return equipos.get( codigo );
	}

	// ACADEMIAS INDIVIDUALES

	/**
	 * CREAR UNA RESERVA
	 *
	 * Revisa las tres reglas del enunciado: que la cantidad de jugadores si le
	 * sirva a la disciplina y quepa en la cancha, que la cancha este libre en ese
	 * horario, y que no se hayan gastado ya todas las canchas que esa disciplina
	 * puede tener al tiempo.
	 *
	 * La tercera es la que tiene que estar aqui y no en Instalacion, pues toca
	 * mirar las reservas de TODAS las canchas de esa disciplina y una instalacion
	 * sola no sabe nada de las otras y asi.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es la historia de usuario HU-03 completa.
	 *
	 * @param codigo el codigo de la nueva reserva
	 * @param afiliado el afiliado que reserva
	 * @param instalacion la instalacion solicitada
	 * @param fecha la fecha de la reserva
	 * @param inicio la hora de inicio
	 * @param fin la hora de finalizacion
	 * @param numeroJugadores cuantos van a jugar
	 * @param modalidad sencillos o dobles
	 * @return la reserva creada
	 * @throws ReservaNoDisponibleException si la instalacion esta ocupada o no hay cupo
	 * @throws OperacionNoPermitidaException si el numero de jugadores no es valido
	 */
	public Reserva crearReserva( String codigo, AfiliadoIndividual afiliado, Instalacion instalacion, LocalDate fecha, LocalTime inicio, LocalTime fin, int numeroJugadores, String modalidad ) throws ReservaNoDisponibleException, OperacionNoPermitidaException
	{
		ReglasDisciplina reglas = instalacion.getReglas( );

		if( afiliado.buscarInscripcion( reglas.getNombre( ) ) == null )
		{
			throw new OperacionNoPermitidaException( "El afiliado " + afiliado.getNombreCompleto( ) + " no esta inscrito en la academia de " + reglas.getNombre( ) );
		}
		if( !reglas.esNumeroJugadoresValido( numeroJugadores ) )
		{
			throw new OperacionNoPermitidaException( "La disciplina " + reglas.getNombre( ) + " no admite partidos de " + numeroJugadores + " jugadores" );
		}
		if( numeroJugadores > instalacion.getCapacidadMaxima( ) )
		{
			throw new OperacionNoPermitidaException( "La instalacion " + instalacion.getNombre( ) + " admite maximo " + instalacion.getCapacidadMaxima( ) + " jugadores" );
		}
		if( !instalacion.estaLibre( fecha, inicio, fin ) )
		{
			throw new ReservaNoDisponibleException( "La instalacion " + instalacion.getNombre( ) + " ya esta reservada en ese bloque horario" );
		}
		if( contarReservasSimultaneas( reglas.getNombre( ), fecha, inicio, fin ) >= maximoInstalacionesSimultaneas )
		{
			throw new ReservaNoDisponibleException( "Ya se alcanzo el maximo de " + maximoInstalacionesSimultaneas + " instalaciones simultaneas para " + reglas.getNombre( ) );
		}

		Reserva reserva = new Reserva( codigo, afiliado, instalacion, fecha, inicio, fin, numeroJugadores, modalidad );
		instalacion.agregarReserva( reserva );
		reservas.add( reserva );
		return reserva;
	}

	/**
	 * CONTAR CUANTAS CANCHAS ESTAN OCUPADAS AL TIEMPO
	 *
	 * Recorre todas las reservas confirmadas de esa disciplina y cuenta las que
	 * se pisan con el horario que se esta pidiendo.
	 *
	 * @param nombreDisciplina la disciplina que se esta revisando
	 * @param fecha la fecha del bloque
	 * @param inicio la hora de inicio
	 * @param fin la hora de finalizacion
	 * @return la cantidad de reservas confirmadas que se cruzan con ese bloque
	 */
	public int contarReservasSimultaneas( String nombreDisciplina, LocalDate fecha, LocalTime inicio, LocalTime fin )
	{
		int total = 0;
		for( Reserva reserva : reservas )
		{
			if( !reserva.estaConfirmada( ) || !reserva.getFecha( ).equals( fecha ) )
			{
				continue;
			}
			if( !reserva.getInstalacion( ).getReglas( ).getNombre( ).equals( nombreDisciplina ) )
			{
				continue;
			}
			boolean seCruzan = inicio.isBefore( reserva.getHoraFin( ) ) && reserva.getHoraInicio( ).isBefore( fin );
			if( seCruzan )
			{
				total = total + 1;
			}
		}
		return total;
	}

	/**
	 * REGISTRAR UN PARTIDO DE PRACTICA
	 *
	 * Lo valida, guarda el resultado, arma las estadisticas de cada uno y
	 * actualiza los rankings. Entonces es un solo llamado y aqui adentro pasan
	 * las cuatro cosas en orden.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es el nucleo del programa de prueba 5.
	 *
	 * @param partido el partido de practica
	 * @param marcadorLocal los tantos del primer lado
	 * @param marcadorVisitante los tantos del segundo lado
	 * @throws ClubException si los niveles o la modalidad no son compatibles
	 */
	public void registrarPartidoPractica( PartidoPractica partido, int marcadorLocal, int marcadorVisitante ) throws ClubException
	{
		partido.validarPuedeJugarse( );
		partido.registrarMarcador( marcadorLocal, marcadorVisitante );
		partido.generarEstadisticas( );
		partido.actualizarRankings( );
		partidos.add( partido );
	}

	/**
	 * INSCRIBIR A ALGUIEN EN UNA ACADEMIA
	 *
	 * Revisa que no este ya inscrito en esa misma disciplina, pues no tendria
	 * sentido tener dos inscripciones de tenis con niveles distintos.
	 *
	 * @param afiliado el afiliado que se inscribe
	 * @param reglas las reglas de la disciplina
	 * @param nivel el nivel asignado
	 * @param fecha la fecha de la inscripcion
	 * @return la inscripcion creada
	 * @throws OperacionNoPermitidaException si ya estaba inscrito en esa disciplina
	 */
	public InscripcionAcademia inscribirEnAcademia( AfiliadoIndividual afiliado, ReglasDisciplina reglas, Nivel nivel, LocalDate fecha ) throws OperacionNoPermitidaException
	{
		if( afiliado.buscarInscripcion( reglas.getNombre( ) ) != null )
		{
			throw new OperacionNoPermitidaException( "El afiliado " + afiliado.getNombreCompleto( ) + " ya esta inscrito en " + reglas.getNombre( ) );
		}
		InscripcionAcademia inscripcion = new InscripcionAcademia( afiliado, reglas, nivel, fecha );
		afiliado.agregarInscripcion( inscripcion );
		return inscripcion;
	}

	// TURNOS DEL PERSONAL

	/**
	 * RADICAR UNA SOLICITUD DE CAMBIO DE TURNO
	 *
	 * Revisa tres cosas antes de dejarlo: que el turno si sea de ese empleado,
	 * que no tenga ya otra solicitud sin responder, y que el turno nuevo que esta
	 * pidiendo quepa en el horario de atencion del club.
	 *
	 * CAMBIO DEL PROYECTO 2
	 * La revision del horario y los parametros del turno nuevo son nuevos. Antes
	 * la solicitud solo decia "quiero cambiar este turno" sin decir a donde, y la
	 * historia de usuario del banco de la Entrega 1 si pedia indicar el nuevo
	 * turno dentro del horario de atencion.
	 *
	 * @param codigo el codigo de la solicitud
	 * @param empleado el empleado que la radica
	 * @param turno el turno que quiere cambiar
	 * @param fecha la fecha de la solicitud
	 * @param motivo la razon del cambio
	 * @param nuevoDiaSemana el dia al que quiere mover el turno
	 * @param nuevaHoraInicio la hora de inicio del turno nuevo
	 * @param nuevaHoraFin la hora de fin del turno nuevo
	 * @return la solicitud creada
	 * @throws OperacionNoPermitidaException si el turno no es suyo, ya tiene una solicitud pendiente o el turno nuevo se sale del horario de atencion
	 */
	public SolicitudCambioTurno solicitarCambioTurno( String codigo, Empleado empleado, Turno turno, LocalDate fecha, String motivo, String nuevoDiaSemana, LocalTime nuevaHoraInicio, LocalTime nuevaHoraFin ) throws OperacionNoPermitidaException
	{
		if( !turno.getEmpleado( ).equals( empleado ) )
		{
			throw new OperacionNoPermitidaException( "El turno " + turno.getCodigo( ) + " no pertenece a " + empleado.getNombreCompleto( ) );
		}
		if( empleado.tieneSolicitudPendiente( ) )
		{
			throw new OperacionNoPermitidaException( "El empleado " + empleado.getNombreCompleto( ) + " ya tiene una solicitud pendiente y debe esperar su resolucion" );
		}
		validarHorarioDeAtencion( nuevaHoraInicio, nuevaHoraFin );

		SolicitudCambioTurno solicitud = new SolicitudCambioTurno( codigo, empleado, turno, fecha, motivo, nuevoDiaSemana, nuevaHoraInicio, nuevaHoraFin );
		turno.agregarSolicitud( solicitud );
		solicitudes.add( solicitud );
		return solicitud;
	}

	/**
	 * REVISAR QUE UNAS HORAS QUEPAN EN EL HORARIO DEL CLUB
	 *
	 * El club abre y cierra a una hora, entonces un turno no puede arrancar antes
	 * de que abra ni terminar despues de que cierre. Esta revision esta en la
	 * fachada y no en Turno porque el horario de atencion es del club y un turno
	 * solo no tiene como saberlo.
	 *
	 * @param inicio la hora de inicio propuesta
	 * @param fin la hora de fin propuesta
	 * @throws OperacionNoPermitidaException si las horas no son validas o se salen del horario de atencion
	 */
	public void validarHorarioDeAtencion( LocalTime inicio, LocalTime fin ) throws OperacionNoPermitidaException
	{
		if( inicio == null || fin == null )
		{
			throw new OperacionNoPermitidaException( "El turno nuevo tiene que traer hora de inicio y hora de fin" );
		}
		if( !inicio.isBefore( fin ) )
		{
			throw new OperacionNoPermitidaException( "La hora de inicio " + inicio + " tiene que ser anterior a la hora de fin " + fin );
		}
		if( inicio.isBefore( horaApertura ) || fin.isAfter( horaCierre ) )
		{
			throw new OperacionNoPermitidaException( "El club atiende de " + horaApertura + " a " + horaCierre + " y el turno pedido va de " + inicio + " a " + fin );
		}
	}

	/**
	 * RECHAZAR UNA SOLICITUD DE CAMBIO DE TURNO
	 *
	 * CAMBIO DEL PROYECTO 2
	 * Esto antes no estaba en la fachada. El rechazo existia en
	 * SolicitudCambioTurno, pero los programas de consola tenian que llamarlo
	 * directo, o sea se saltaban la fachada para una operacion que el
	 * administrador si hace. Entonces ahora pasa por aqui como la aprobacion.
	 *
	 * @param solicitud la solicitud que se rechaza
	 * @param administrador el administrador que decide
	 * @param fecha la fecha de la decision
	 * @param observacion la razon del rechazo
	 * @throws OperacionNoPermitidaException si la solicitud ya fue resuelta
	 */
	public void rechazarCambioTurno( SolicitudCambioTurno solicitud, Administrador administrador, LocalDate fecha, String observacion ) throws OperacionNoPermitidaException
	{
		if( !solicitud.estaPendiente( ) )
		{
			throw new OperacionNoPermitidaException( "La solicitud " + solicitud.getCodigo( ) + " ya fue resuelta" );
		}
		solicitud.rechazar( administrador, fecha, observacion );
	}

	/**
	 * APROBAR UNA SOLICITUD DE CAMBIO DE TURNO
	 *
	 * Esta es la operacion mas enredada de todo el sistema.
	 *
	 * Lo que hace es simular el cambio antes de aplicarlo: cuenta cuanta gente
	 * quedaria ese dia si ese turno dejara de contar. Si con eso se rompe el
	 * minimo entonces rechaza la solicitud y el turno se queda como estaba.
	 *
	 * la parte del codigo que puede hacerlo estallar es: hacer esto al reves. Si
	 * uno aplica el cambio primero y despues cuenta, entonces ya rompio la
	 * cobertura y le toca devolverse, y si algo falla en la mitad el club queda
	 * descubierto sin que nadie se entere. Por eso se simula primero y se aplica
	 * de ultimas.
	 *
	 * la parte del codigo que puede hacerlo estallar es: es la historia de usuario HU-01 y la regla mas delicada del
	 * sistema, porque depende del estado de todos los turnos y no de uno solo.
	 *
	 * @param solicitud la solicitud que se quiere resolver
	 * @param administrador el administrador que decide
	 * @param fecha la fecha de la decision
	 * @throws CoberturaMinimaException si al aplicar el cambio el club queda descubierto
	 * @throws OperacionNoPermitidaException si la solicitud ya fue resuelta
	 */
	public void aprobarCambioTurno( SolicitudCambioTurno solicitud, Administrador administrador, LocalDate fecha ) throws CoberturaMinimaException, OperacionNoPermitidaException
	{
		if( !solicitud.estaPendiente( ) )
		{
			throw new OperacionNoPermitidaException( "La solicitud " + solicitud.getCodigo( ) + " ya fue resuelta" );
		}

		Turno turno = solicitud.getTurno( );
		Empleado solicitante = solicitud.getSolicitante( );
		String dia = turno.getDiaSemana( );
		String semana = turno.getSemana( );

		int entrenadores = contarPersonalCubriendo( Entrenador.class, dia, semana, turno );
		int fisioterapeutas = contarPersonalCubriendo( Fisioterapeuta.class, dia, semana, turno );

		// CAMBIO DEL PROYECTO 2
		// Antes, cuando el cambio rompia la cobertura, aqui mismo se rechazaba la
		// solicitud y despues se lanzaba la excepcion. Lo quitamos: ahora solo
		// revienta y la solicitud se queda Pendiente. Pues una cosa es que el
		// administrador no la pueda aprobar hoy y otra muy distinta es cerrarsela
		// al empleado, que todavia puede conseguir quien le cubra y volver a
		// intentar. Si el administrador si la quiere negar, para eso existe
		// rechazarCambioTurno, que es una decision suya y no un efecto secundario.
		if( solicitante instanceof Entrenador && entrenadores < minimoEntrenadores )
		{
			throw new CoberturaMinimaException( "Aprobar la solicitud dejaria " + entrenadores + " entrenadores el " + dia + " y el club exige " + minimoEntrenadores );
		}
		if( solicitante instanceof Fisioterapeuta && fisioterapeutas < minimoFisioterapeutas )
		{
			throw new CoberturaMinimaException( "Aprobar la solicitud dejaria " + fisioterapeutas + " fisioterapeutas el " + dia + " y el club exige " + minimoFisioterapeutas );
		}

		// CAMBIO DEL PROYECTO 2
		// Antes aqui se hacia turno.setVigente( false ), o sea el turno se
		// desaparecia y el empleado quedaba sin turno. La historia de usuario lo
		// que pide es que el turno quede actualizado en el dia y las horas nuevas,
		// y eso ahora lo hace la solicitud al aprobarse, que es la que sabe para
		// donde iba el cambio.
		solicitud.aprobar( administrador, fecha );
	}

	/**
	 * CONTAR EL PERSONAL QUE QUEDARIA
	 *
	 * Este es el metodo que hace la simulacion: cuenta los empleados de un tipo
	 * que cubren ese dia, saltandose el turno que se esta pensando quitar.
	 *
	 * Cuenta por tipo y no en total, pues el club pide minimo dos entrenadores y
	 * minimo un fisioterapeuta, entonces no sirve de nada saber que hay tres
	 * empleados si los tres son entrenadores y asi.
	 *
	 * @param tipo la clase de empleado que se quiere contar
	 * @param dia el dia de la semana
	 * @param semana el identificador de la semana
	 * @param turnoExcluido el turno que se esta simulando retirar
	 * @return la cantidad de empleados que quedarian
	 */
	private int contarPersonalCubriendo( Class<?> tipo, String dia, String semana, Turno turnoExcluido )
	{
		int total = 0;
		for( Turno turno : turnos )
		{
			if( !turno.isVigente( ) || turno.equals( turnoExcluido ) )
			{
				continue;
			}
			if( !turno.getDiaSemana( ).equals( dia ) || !turno.getSemana( ).equals( semana ) )
			{
				continue;
			}
			if( tipo.isInstance( turno.getEmpleado( ) ) && turno.getEmpleado( ).isActivo( ) )
			{
				total = total + 1;
			}
		}
		return total;
	}

	// TORNEOS

	/**
	 * CREAR UN TORNEO
	 *
	 * El torneo ya llega armado y validado por dentro, pues su constructor
	 * revisa los cupos, la tarifa y los porcentajes. Lo que revisa la fachada son
	 * las dos cosas que el torneo solo no puede saber: que su codigo no este
	 * repetido, porque eso depende de los otros torneos del club, y que la fecha
	 * sea futura, porque eso depende del dia de hoy.
	 *
	 * DECISION DE DISENO D12
	 * No revisamos que no haya otro torneo el mismo dia, pues el club si permite
	 * varios torneos al mismo tiempo.
	 *
	 * @param torneo el torneo que se quiere registrar
	 * @throws OperacionNoPermitidaException si el codigo ya existe o si la fecha ya paso
	 */
	public void crearTorneo( Torneo torneo ) throws OperacionNoPermitidaException
	{
		if( torneos.containsKey( torneo.getCodigo( ) ) )
		{
			throw new OperacionNoPermitidaException( "Ya existe un torneo con el codigo " + torneo.getCodigo( ) );
		}
		if( torneo.getFecha( ) == null || !torneo.getFecha( ).isAfter( LocalDate.now( ) ) )
		{
			throw new OperacionNoPermitidaException( "El torneo " + torneo.getCodigo( ) + " tiene fecha " + torneo.getFecha( ) + " y los torneos se programan para una fecha futura" );
		}
		torneos.put( torneo.getCodigo( ), torneo );
	}

	/**
	 * METER UN TORNEO SIN REVISAR NADA
	 *
	 * Esto es para el repositorio, o sea para cuando se recargan los torneos
	 * desde el archivo. No revisa la fecha futura a proposito, pues un torneo que
	 * ya se jugo tiene fecha pasada y de otra forma no se podria volver a cargar
	 * el historico. Los programas usan crearTorneo, que si revisa.
	 *
	 * @param torneo el torneo que se esta recargando
	 */
	public void agregarTorneo( Torneo torneo )
	{
		torneos.put( torneo.getCodigo( ), torneo );
	}

	public Torneo buscarTorneo( String codigo )
	{
		return torneos.get( codigo );
	}

	/**
	 * LISTAR LOS TORNEOS
	 *
	 * Si le pasan un estado devuelve solo los de ese estado, y si le pasan null
	 * devuelve todos. Lo hicimos con un solo metodo y no con dos porque la
	 * historia de usuario es la misma consulta, con filtro o sin filtro.
	 *
	 * @param estado el estado por el que se quiere filtrar, o null para traer todos
	 * @return los torneos que cumplen el filtro
	 */
	public List<Torneo> consultarTorneos( EstadoTorneo estado )
	{
		List<Torneo> encontrados = new ArrayList<Torneo>( );
		for( Torneo torneo : torneos.values( ) )
		{
			if( estado == null || torneo.getEstado( ) == estado )
			{
				encontrados.add( torneo );
			}
		}
		return encontrados;
	}

	/**
	 * CAMBIARLE LOS CUPOS A UN TORNEO
	 *
	 * @param torneo el torneo que se modifica
	 * @param nuevosCupos el nuevo total de cupos
	 * @throws OperacionNoPermitidaException si el torneo ya arranco o si los cupos no alcanzan para los inscritos
	 */
	public void modificarCuposTorneo( Torneo torneo, int nuevosCupos ) throws OperacionNoPermitidaException
	{
		torneo.modificarCupos( nuevosCupos );
	}

	/**
	 * CANCELAR UN TORNEO
	 *
	 * @param torneo el torneo que se cancela
	 * @throws OperacionNoPermitidaException si el torneo ya arranco o ya termino
	 */
	public void cancelarTorneo( Torneo torneo ) throws OperacionNoPermitidaException
	{
		torneo.cancelar( );
	}

	/**
	 * LIBERAR LOS CUPOS PREFERENCIALES QUE SOBRARON
	 *
	 * @param torneo el torneo al que se le liberan los cupos
	 * @return cuantos cupos pasaron de preferenciales a regulares
	 */
	public int liberarCuposPreferenciales( Torneo torneo )
	{
		return torneo.liberarCuposPreferenciales( );
	}

	/**
	 * ARRANCAR UN TORNEO
	 *
	 * @param torneo el torneo que se inicia
	 * @throws OperacionNoPermitidaException si el torneo no esta abierto o no hay con quien jugar
	 */
	public void iniciarTorneo( Torneo torneo ) throws OperacionNoPermitidaException
	{
		torneo.iniciar( );
	}

	/**
	 * GUARDAR EL RESULTADO DE UN ENCUENTRO
	 *
	 * @param torneo el torneo al que pertenece el encuentro
	 * @param encuentro el encuentro que se esta registrando
	 * @param marcadorA los tantos del primer participante
	 * @param marcadorB los tantos del segundo participante
	 * @throws OperacionNoPermitidaException si el torneo no esta En curso o el resultado no es valido
	 */
	public void registrarResultadoEncuentro( Torneo torneo, Encuentro encuentro, int marcadorA, int marcadorB ) throws OperacionNoPermitidaException
	{
		torneo.registrarResultado( encuentro, marcadorA, marcadorB );
	}

	/**
	 * TERMINAR UN TORNEO Y ENTREGAR EL PREMIO
	 *
	 * @param torneo el torneo que se finaliza
	 * @return el participante que gano
	 * @throws ClubException si quedan encuentros pendientes o el torneo no esta En curso
	 */
	public Participante finalizarTorneo( Torneo torneo ) throws ClubException
	{
		return torneo.finalizar( );
	}

	/**
	 * INSCRIBIR A UNA PERSONA EN UN TORNEO INDIVIDUAL
	 *
	 * Esta es la operacion de torneos mas enredada y por eso esta en la fachada.
	 *
	 * Hace tres cosas que el torneo solo no podria: revisa que si es empleado no
	 * tenga turno ese dia, averigua si tiene derecho a cupo preferencial mirando
	 * el ranking de todo el club, y de ultimas le pide al torneo que lo inscriba.
	 *
	 * la parte del codigo que puede hacerlo estallar es: el orden. La revision
	 * del turno va de primeras porque es la que no tiene nada que ver con el
	 * torneo, y la del cupo preferencial va antes de inscribir porque el torneo
	 * necesita que ya le digan si el cupo es preferencial o regular. Si lo
	 * hicieramos al reves el torneo tendria que conocer el ranking de todos los
	 * afiliados y ya no seria un torneo, seria otra fachada.
	 *
	 * @param torneo el torneo al que se quiere entrar
	 * @param persona la persona que se inscribe
	 * @param fecha la fecha de la inscripcion
	 * @return la inscripcion creada
	 * @throws ClubException si alguna de las reglas de inscripcion no se cumple
	 */
	public InscripcionTorneo inscribirEnTorneo( Torneo torneo, Persona persona, LocalDate fecha ) throws ClubException
	{
		validarEmpleadoSinTurno( persona, torneo.getFecha( ) );
		ParticipanteIndividual participante = new ParticipanteIndividual( persona );
		boolean preferencial = esElegibleCupoPreferencial( torneo, participante );
		return torneo.inscribir( participante, fecha, preferencial );
	}

	/**
	 * INSCRIBIR UNA PAREJA EN UN TORNEO DE DOBLES
	 *
	 * La pareja ocupa un cupo entre los dos, y si tiene derecho a cupo
	 * preferencial es porque uno de los dos esta entre los mejores del ranking.
	 *
	 * @param torneo el torneo de dobles
	 * @param primero el primer integrante
	 * @param segundo el segundo integrante
	 * @param fecha la fecha de la inscripcion
	 * @return la inscripcion creada
	 * @throws ClubException si alguna de las reglas de inscripcion no se cumple
	 */
	public InscripcionTorneo inscribirParejaEnTorneo( Torneo torneo, Persona primero, Persona segundo, LocalDate fecha ) throws ClubException
	{
		validarEmpleadoSinTurno( primero, torneo.getFecha( ) );
		validarEmpleadoSinTurno( segundo, torneo.getFecha( ) );
		ParticipantePareja participante = new ParticipantePareja( primero, segundo );
		boolean preferencial = esElegibleCupoPreferencial( torneo, participante );
		return torneo.inscribir( participante, fecha, preferencial );
	}

	/**
	 * INSCRIBIR UN EQUIPO EN UN TORNEO DE CONJUNTO
	 *
	 * @param torneo el torneo de conjunto
	 * @param equipo el equipo que se inscribe
	 * @param fecha la fecha de la inscripcion
	 * @return la inscripcion creada
	 * @throws ClubException si el equipo esta incompleto o alguna otra regla no se cumple
	 */
	public InscripcionTorneo inscribirEquipoEnTorneo( Torneo torneo, Equipo equipo, LocalDate fecha ) throws ClubException
	{
		ParticipanteEquipo participante = new ParticipanteEquipo( equipo );
		boolean preferencial = esElegibleCupoPreferencial( torneo, participante );
		return torneo.inscribir( participante, fecha, preferencial );
	}

	/**
	 * SACAR A ALGUIEN DE UN TORNEO
	 *
	 * @param torneo el torneo del que se quiere salir
	 * @param persona la persona que se sale
	 * @throws OperacionNoPermitidaException si el torneo ya arranco o la persona no estaba inscrita
	 */
	public void desinscribirDeTorneo( Torneo torneo, Persona persona ) throws OperacionNoPermitidaException
	{
		torneo.desinscribir( persona );
	}

	/**
	 * REVISAR QUE UN EMPLEADO NO TENGA TURNO ESE DIA
	 *
	 * DECISION DE DISENO D10
	 * Si el que se inscribe no es empleado entonces esto no aplica y el metodo no
	 * hace nada.
	 *
	 * @param persona la persona que se inscribe
	 * @param fechaTorneo la fecha en la que se juega el torneo
	 * @throws OperacionNoPermitidaException si es empleado y tiene turno ese dia
	 */
	private void validarEmpleadoSinTurno( Persona persona, LocalDate fechaTorneo ) throws OperacionNoPermitidaException
	{
		if( !( persona instanceof Empleado ) )
		{
			return;
		}
		Empleado empleado = ( Empleado ) persona;
		if( empleado.tieneTurnoEn( fechaTorneo ) )
		{
			throw new OperacionNoPermitidaException( empleado.getNombreCompleto( ) + " tiene turno asignado el " + fechaTorneo + " y no se puede inscribir al torneo" );
		}
	}

	/**
	 * AVERIGUAR SI TIENE DERECHO A CUPO PREFERENCIAL
	 *
	 * DECISION DE DISENO D5
	 * Es elegible el que esta entre los K primeros de su nivel o de su categoria,
	 * donde K es el numero de cupos preferenciales del torneo. Entonces un torneo
	 * con 2 cupos preferenciales se los reserva a los 2 primeros del ranking.
	 *
	 * El que no tiene puntaje, o sea los estudiantes, los externos y los
	 * empleados, nunca es elegible y entra por cupo regular. Pues el cupo
	 * preferencial premia el ranking del club y ellos no estan en ninguna
	 * academia.
	 *
	 * Esta cuenta tiene que estar en la fachada porque hay que mirar el ranking
	 * de TODOS los afiliados del nivel, y ni el torneo ni el participante conocen
	 * esa lista.
	 *
	 * @param torneo el torneo al que se quiere entrar
	 * @param participante el que se quiere inscribir
	 * @return true si le corresponde cupo preferencial
	 */
	public boolean esElegibleCupoPreferencial( Torneo torneo, Participante participante )
	{
		double puntaje = participante.getPuntajeEn( torneo.getDisciplina( ) );
		int cuposPreferenciales = torneo.getCuposPreferenciales( );
		if( puntaje <= 0 || cuposPreferenciales <= 0 )
		{
			return false;
		}

		List<Double> referencia = getPuntajesDeReferencia( torneo );
		if( referencia.size( ) <= cuposPreferenciales )
		{
			return true;
		}
		return puntaje >= referencia.get( cuposPreferenciales - 1 );
	}

	/**
	 * ARMAR LA FILA DEL RANKING CONTRA LA QUE SE COMPARA
	 *
	 * En los torneos individuales y de dobles son los puntajes de los afiliados
	 * inscritos en esa disciplina y en ese nivel. En los de conjunto son los
	 * partidos ganados por los equipos de ese deporte y esa categoria. Los dos
	 * quedan ordenados de mayor a menor.
	 *
	 * @param torneo el torneo que se esta evaluando
	 * @return los puntajes de referencia ordenados de mayor a menor
	 */
	private List<Double> getPuntajesDeReferencia( Torneo torneo )
	{
		List<Double> puntajes = new ArrayList<Double>( );
		if( torneo.getModalidad( ).esDeEquipos( ) )
		{
			for( Equipo equipo : getEquiposDe( torneo.getDisciplina( ), torneo.getCategoria( ) ) )
			{
				puntajes.add( Double.valueOf( equipo.getPartidosGanados( ) ) );
			}
		}
		else
		{
			for( InscripcionAcademia inscripcion : getInscripcionesDe( torneo.getDisciplina( ), torneo.getNivel( ) ) )
			{
				puntajes.add( Double.valueOf( inscripcion.getPuntajeRanking( ) ) );
			}
		}

		for( int i = 0; i < puntajes.size( ); i++ )
		{
			for( int j = i + 1; j < puntajes.size( ); j++ )
			{
				if( puntajes.get( j ).doubleValue( ) > puntajes.get( i ).doubleValue( ) )
				{
					Double temporal = puntajes.get( i );
					puntajes.set( i, puntajes.get( j ) );
					puntajes.set( j, temporal );
				}
			}
		}
		return puntajes;
	}

	/**
	 * BUSCAR LAS INSCRIPCIONES DE UNA DISCIPLINA Y UN NIVEL
	 *
	 * @param nombreDisciplina la disciplina que interesa
	 * @param nivel el nivel que interesa, o null para traer todos los niveles
	 * @return las inscripciones activas que cumplen el filtro
	 */
	public List<InscripcionAcademia> getInscripcionesDe( String nombreDisciplina, Nivel nivel )
	{
		List<InscripcionAcademia> encontradas = new ArrayList<InscripcionAcademia>( );
		for( Persona persona : personas.values( ) )
		{
			if( !( persona instanceof AfiliadoIndividual ) )
			{
				continue;
			}
			AfiliadoIndividual afiliado = ( AfiliadoIndividual ) persona;
			for( InscripcionAcademia inscripcion : afiliado.getInscripciones( ) )
			{
				boolean mismaDisciplina = inscripcion.getReglas( ).getNombre( ).equals( nombreDisciplina );
				boolean mismoNivel = nivel == null || inscripcion.getNivel( ) == nivel;
				if( inscripcion.isActiva( ) && mismaDisciplina && mismoNivel )
				{
					encontradas.add( inscripcion );
				}
			}
		}
		return encontradas;
	}

	/**
	 * BUSCAR LOS EQUIPOS DE UN DEPORTE Y UNA CATEGORIA
	 *
	 * @param nombreDeporte el deporte que interesa
	 * @param categoria la categoria que interesa, o null para traer todas
	 * @return los equipos activos que cumplen el filtro
	 */
	public List<Equipo> getEquiposDe( String nombreDeporte, Categoria categoria )
	{
		List<Equipo> encontrados = new ArrayList<Equipo>( );
		for( Equipo equipo : equipos.values( ) )
		{
			boolean mismoDeporte = equipo.getReglas( ).getNombre( ).equals( nombreDeporte );
			boolean mismaCategoria = categoria == null || equipo.getCategoria( ) == categoria;
			if( equipo.isActivo( ) && mismoDeporte && mismaCategoria )
			{
				encontrados.add( equipo );
			}
		}
		return encontrados;
	}

	/**
	 * ARMAR EL RANKING DE UNA DISCIPLINA
	 *
	 * Ordena a los afiliados de ese nivel por su puntaje, de mejor a peor. Es la
	 * fila con la que se reparten los cupos preferenciales y tambien sirve para
	 * mostrarsela al jugador.
	 *
	 * @param nombreDisciplina la disciplina que interesa
	 * @param nivel el nivel que interesa, o null para traer todos los niveles
	 * @return las inscripciones ordenadas de mayor a menor puntaje
	 */
	public List<InscripcionAcademia> getRankingDisciplina( String nombreDisciplina, Nivel nivel )
	{
		List<InscripcionAcademia> ranking = getInscripcionesDe( nombreDisciplina, nivel );
		for( int i = 0; i < ranking.size( ); i++ )
		{
			for( int j = i + 1; j < ranking.size( ); j++ )
			{
				if( ranking.get( j ).getPuntajeRanking( ) > ranking.get( i ).getPuntajeRanking( ) )
				{
					InscripcionAcademia temporal = ranking.get( i );
					ranking.set( i, ranking.get( j ) );
					ranking.set( j, temporal );
				}
			}
		}
		return ranking;
	}

	/**
	 * ARMAR EL RANKING DE EQUIPOS
	 *
	 * DECISION DE DISENO D5
	 * Los ordena por partidos internos ganados, que es el criterio que armamos
	 * para los equipos porque el club no tenia ranking de equipos.
	 *
	 * @param nombreDeporte el deporte que interesa
	 * @param categoria la categoria que interesa, o null para traer todas
	 * @return los equipos ordenados de mas a menos partidos ganados
	 */
	public List<Equipo> getRankingEquipos( String nombreDeporte, Categoria categoria )
	{
		List<Equipo> ranking = getEquiposDe( nombreDeporte, categoria );
		for( int i = 0; i < ranking.size( ); i++ )
		{
			for( int j = i + 1; j < ranking.size( ); j++ )
			{
				if( ranking.get( j ).getPartidosGanados( ) > ranking.get( i ).getPartidosGanados( ) )
				{
					Equipo temporal = ranking.get( i );
					ranking.set( i, ranking.get( j ) );
					ranking.set( j, temporal );
				}
			}
		}
		return ranking;
	}

	// BONOS DE LOS TORNEOS RECREATIVOS

	/**
	 * LISTAR LOS BONOS DE UNA PERSONA
	 *
	 * Trae todos con su estado, o sea los disponibles y los que ya se usaron,
	 * pues la historia de usuario pide ver el estado de cada uno.
	 *
	 * @param persona el dueno de los bonos
	 * @return los bonos de esa persona
	 */
	public List<Bono> getBonosDe( Persona persona )
	{
		return persona.getBonos( );
	}

	/**
	 * REDIMIR UN BONO EN UNA COMPRA
	 *
	 * La venta es la que revisa que el bono sirva, que sea del comprador y que no
	 * haya otro descuento, pues todo eso es informacion de la venta misma.
	 * Entonces la fachada lo que hace es dejar la operacion en un solo lado para
	 * que los programas de consola no tengan que armarla ellos.
	 *
	 * @param venta la venta en la que se quiere usar el bono
	 * @param bono el bono que se quiere redimir
	 * @throws OperacionNoPermitidaException si el bono no se puede usar en esa venta
	 */
	public void redimirBonoEnVenta( Venta venta, Bono bono ) throws OperacionNoPermitidaException
	{
		venta.redimirBono( bono );
	}

	// REPORTES

	/**
	 * SUMAR LAS VENTAS DE UN PERIODO
	 *
	 * nota: aqui se usa java.time otra vez. Las fechas son LocalDate y para
	 * saber si una venta cae dentro del rango se usan isBefore e isAfter, que
	 * son los metodos que dicen cual fecha va primero. Como queremos incluir los
	 * dos extremos, lo que se pregunta es que la fecha NO sea anterior al desde
	 * y NO sea posterior al hasta.
	 *
	 * @param rubro el rubro contable (tienda o cafeteria)
	 * @param desde la fecha inicial, inclusive
	 * @param hasta la fecha final, inclusive
	 * @return el total vendido en ese rubro y periodo
	 */
	public double getTotalVentas( String rubro, LocalDate desde, LocalDate hasta )
	{
		double total = 0.0;
		for( Venta venta : ventas )
		{
			boolean enRango = !venta.getFecha( ).isBefore( desde ) && !venta.getFecha( ).isAfter( hasta );
			if( enRango && venta.getRubro( ).equals( rubro ) )
			{
				total = total + venta.getTotal( );
			}
		}
		return total;
	}

	/**
	 * ARMAR LA TABLA DE LOS MEJORES
	 *
	 * Usa el valor principal de cada estadistica, entonces el mismo metodo sirve
	 * para sacar el goleador del futbol y el lider de aces del voleibol sin
	 * cambiarle nada. Eso es polimorfismo trabajando y asi.
	 *
	 * @param cantidad cuantos afiliados se quieren en la lista
	 * @return los afiliados ordenados de mayor a menor valor principal
	 */
	public List<Afiliado> getMejoresAfiliados( int cantidad )
	{
		List<Afiliado> afiliados = new ArrayList<Afiliado>( );
		for( Persona persona : personas.values( ) )
		{
			if( persona instanceof Afiliado )
			{
				afiliados.add( ( Afiliado ) persona );
			}
		}
		for( int i = 0; i < afiliados.size( ); i++ )
		{
			for( int j = i + 1; j < afiliados.size( ); j++ )
			{
				if( afiliados.get( j ).getTotalValorPrincipal( ) > afiliados.get( i ).getTotalValorPrincipal( ) )
				{
					Afiliado temporal = afiliados.get( i );
					afiliados.set( i, afiliados.get( j ) );
					afiliados.set( j, temporal );
				}
			}
		}
		if( afiliados.size( ) > cantidad )
		{
			return new ArrayList<Afiliado>( afiliados.subList( 0, cantidad ) );
		}
		return afiliados;
	}

	// ACCESO A LAS COLECCIONES

	public void agregarInstalacion( Instalacion instalacion )
	{
		instalaciones.put( instalacion.getCodigo( ), instalacion );
	}

	public Instalacion buscarInstalacion( String codigo )
	{
		return instalaciones.get( codigo );
	}

	public void agregarProducto( Producto producto )
	{
		productos.put( producto.getCodigo( ), producto );
	}

	public Producto buscarProducto( String codigo )
	{
		return productos.get( codigo );
	}

	public void agregarCompetencia( Competencia competencia )
	{
		competencias.put( competencia.getCodigo( ), competencia );
	}

	public Competencia buscarCompetencia( String codigo )
	{
		return competencias.get( codigo );
	}

	public void agregarTurno( Turno turno )
	{
		turnos.add( turno );
		turno.getEmpleado( ).agregarTurno( turno );
	}

	public void agregarSesion( SesionEntrenamiento sesion )
	{
		sesiones.add( sesion );
		sesion.getEntrenador( ).agregarSesion( sesion );
	}

	public void agregarVenta( Venta venta )
	{
		ventas.add( venta );
	}

	public void agregarSugerencia( SugerenciaProducto sugerencia )
	{
		sugerencias.add( sugerencia );
	}

	public void agregarPartido( Partido partido )
	{
		partidos.add( partido );
	}

	public Map<String, Persona> getPersonas( )
	{
		return personas;
	}

	public Map<String, Equipo> getEquipos( )
	{
		return equipos;
	}

	public Map<String, Competencia> getCompetencias( )
	{
		return competencias;
	}

	public Map<String, Instalacion> getInstalaciones( )
	{
		return instalaciones;
	}

	public Map<String, Producto> getProductos( )
	{
		return productos;
	}

	public Map<String, Torneo> getTorneos( )
	{
		return torneos;
	}

	public List<Reserva> getReservas( )
	{
		return reservas;
	}

	public List<Partido> getPartidos( )
	{
		return partidos;
	}

	public List<SesionEntrenamiento> getSesiones( )
	{
		return sesiones;
	}

	public List<Turno> getTurnos( )
	{
		return turnos;
	}

	public List<SolicitudCambioTurno> getSolicitudes( )
	{
		return solicitudes;
	}

	public List<Venta> getVentas( )
	{
		return ventas;
	}

	public List<SugerenciaProducto> getSugerencias( )
	{
		return sugerencias;
	}

	public String getNombre( )
	{
		return nombre;
	}

	public void setNombre( String nombre )
	{
		this.nombre = nombre;
	}

	public String getInstitucion( )
	{
		return institucion;
	}

	public void setInstitucion( String institucion )
	{
		this.institucion = institucion;
	}

	public LocalTime getHoraApertura( )
	{
		return horaApertura;
	}

	public void setHoraApertura( LocalTime horaApertura )
	{
		this.horaApertura = horaApertura;
	}

	public LocalTime getHoraCierre( )
	{
		return horaCierre;
	}

	public void setHoraCierre( LocalTime horaCierre )
	{
		this.horaCierre = horaCierre;
	}

	public int getMinimoEntrenadores( )
	{
		return minimoEntrenadores;
	}

	public void setMinimoEntrenadores( int minimoEntrenadores )
	{
		this.minimoEntrenadores = minimoEntrenadores;
	}

	public int getMinimoFisioterapeutas( )
	{
		return minimoFisioterapeutas;
	}

	public void setMinimoFisioterapeutas( int minimoFisioterapeutas )
	{
		this.minimoFisioterapeutas = minimoFisioterapeutas;
	}

	public int getMaximoInstalacionesSimultaneas( )
	{
		return maximoInstalacionesSimultaneas;
	}

	public void setMaximoInstalacionesSimultaneas( int maximoInstalacionesSimultaneas )
	{
		this.maximoInstalacionesSimultaneas = maximoInstalacionesSimultaneas;
	}

	@Override
	public String toString( )
	{
		return nombre + " (" + institucion + ") | " + personas.size( ) + " personas | " + equipos.size( ) + " equipos | " + productos.size( ) + " productos";
	}
}
