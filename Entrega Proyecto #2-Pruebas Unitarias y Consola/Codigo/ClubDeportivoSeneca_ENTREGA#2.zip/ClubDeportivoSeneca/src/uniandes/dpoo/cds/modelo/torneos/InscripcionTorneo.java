package uniandes.dpoo.cds.modelo.torneos;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * INSCRIPCION A UN TORNEO
 *
 * Conecta a un participante con un torneo.
 *
 * Existe como clase aparte pues hay datos que no son del torneo ni del
 * participante por separado: si entro por cupo preferencial o regular, cuanto
 * pago y en que fecha se inscribio. Eso es de ese participante en ESE torneo, y
 * el mismo jugador puede estar en otro torneo pagando distinto y por cupo
 * regular. Entonces esos datos tienen que vivir en la union de los dos. A esto
 * le dicen clase asociacion y es la misma idea de InscripcionEquipo y de
 * InscripcionAcademia que ya teniamos.
 */
public class InscripcionTorneo implements Serializable
{
	private static final long serialVersionUID = 1L;

	private Torneo torneo;

	private Participante participante;

	private LocalDate fechaInscripcion;

	private boolean preferencial;

	private double valorPagado;

	public InscripcionTorneo( Torneo torneo, Participante participante, LocalDate fechaInscripcion, boolean preferencial, double valorPagado )
	{
		this.torneo = torneo;
		this.participante = participante;
		this.fechaInscripcion = fechaInscripcion;
		this.preferencial = preferencial;
		this.valorPagado = valorPagado;
	}

	/**
	 * PASAR LA INSCRIPCION DE PREFERENCIAL A REGULAR
	 *
	 * No se usa para cambiar de opinion, sino para cuando el administrador
	 * libera los cupos preferenciales que quedaron sin usar, que es la decision
	 * D6. El participante se queda en el torneo, lo unico que cambia es por cual
	 * puerta se cuenta su cupo.
	 */
	public void pasarARegular( )
	{
		this.preferencial = false;
	}

	public Torneo getTorneo( )
	{
		return torneo;
	}

	public void setTorneo( Torneo torneo )
	{
		this.torneo = torneo;
	}

	public Participante getParticipante( )
	{
		return participante;
	}

	public void setParticipante( Participante participante )
	{
		this.participante = participante;
	}

	public LocalDate getFechaInscripcion( )
	{
		return fechaInscripcion;
	}

	public void setFechaInscripcion( LocalDate fechaInscripcion )
	{
		this.fechaInscripcion = fechaInscripcion;
	}

	public boolean isPreferencial( )
	{
		return preferencial;
	}

	public double getValorPagado( )
	{
		return valorPagado;
	}

	public void setValorPagado( double valorPagado )
	{
		this.valorPagado = valorPagado;
	}

	@Override
	public String toString( )
	{
		String tipoCupo = "regular";
		if( preferencial )
		{
			tipoCupo = "preferencial";
		}
		return participante.getNombre( ) + " | cupo " + tipoCupo + " | pago " + String.format( "%.2f", valorPagado );
	}
}
